# Databricks notebook source

# catalog_name = 'qa-adc-marshallrwe-catalog-us-west-2'
# schema_name = 'rwe-history-fsl2'
# mapping_catalog = 'qa-adc-dmz-catalog-us-west-2'
# mapping_schema = 'rwe-link-tables'
# account_table = 'user_link'
# device_table = 'reader_link'


catalog_name = dbutils.widgets.get("catalog_name")
schema_name = dbutils.widgets.get("schema_name")
mapping_catalog = dbutils.widgets.get("mapping_catalog")
mapping_schema = dbutils.widgets.get("mapping_schema")
account_table = dbutils.widgets.get("account_table")
device_table = dbutils.widgets.get("device_table")


# COMMAND ----------

account_map = spark.sql(f"SELECT accountid_sha256, accountid_argon2 from `{mapping_catalog}`.`{mapping_schema}`.`{account_table}`")
device_map = spark.sql(f"SELECT deviceuuid_sha256, deviceuuid_argon2 from `{mapping_catalog}`.`{mapping_schema}`.`{device_table}`")

# COMMAND ----------

tab = spark.sql(f"SHOW TABLES IN `{catalog_name}`.`{schema_name}`")
tables = [row.tableName for row in tab.select('tableName').where(tab.database == f"`{schema_name}`").collect()]

account_map.createOrReplaceTempView("account_map")
device_map.createOrReplaceTempView("device_map")

for table in tables:
    # Add firstProcessedDate columns to each of the tables
    existing_columns = spark.sql(f"DESCRIBE `{catalog_name}`.`{schema_name}`.`{table}`") \
                            .select("col_name") \
                            .rdd.flatMap(lambda x: x) \
                            .collect()
    
    if 'date_' not in existing_columns:
        # Add firstProcessedDate column to the table if it does not exist
        spark.sql(f"ALTER TABLE `{catalog_name}`.`{schema_name}`.`{table}` ADD COLUMN date_ DATE")
    
    if 'uploaddate' not in existing_columns:
        # Add firstProcessedDate column to the table if it does not exist
        spark.sql(f"ALTER TABLE `{catalog_name}`.`{schema_name}`.`{table}` ADD COLUMN uploaddate DATE")


    # Check if the column 'accountid' exists in the table
    acc_columns = spark.sql(f"DESCRIBE `{catalog_name}`.`{schema_name}`.`{table}`").select("col_name").rdd.flatMap(lambda x: x).collect()
    dev_columns = spark.sql(f"DESCRIBE `{catalog_name}`.`{schema_name}`.`{table}`").select("col_name").rdd.flatMap(lambda x: x).collect()
    if 'accountid' in [col.lower() for col in acc_columns]:
        # Go through each table and do the merge
        spark.sql(f"""
            MERGE INTO `{catalog_name}`.`{schema_name}`.`{table}` t
            USING account_map a     
            ON t.accountid = a.accountid_argon2
            WHEN MATCHED THEN
            UPDATE SET 
                t.accountid = a.accountid_sha256,
                t.date_ = current_date()
        """)

    if 'deviceuuid' in [col.lower() for col in dev_columns]:
        spark.sql(f"""
            MERGE INTO `{catalog_name}`.`{schema_name}`.`{table}` t
            USING device_map a     
            ON t.deviceUUID = a.deviceUUID_argon2
            WHEN MATCHED THEN
            UPDATE SET 
                t.deviceUUID = a.deviceUUID_sha256,
                t.date_ = current_date()
        """)


# COMMAND ----------


