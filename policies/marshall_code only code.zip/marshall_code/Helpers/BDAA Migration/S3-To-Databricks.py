# Databricks notebook source
from pyspark.sql.types import LongType, StringType, StructField, StructType, BooleanType, ArrayType, IntegerType, TimestampType, FloatType, DoubleType, DateType
import datetime
from pyspark.sql.functions import lit

source_path = dbutils.widgets.get("source_path")
catalog_name = dbutils.widgets.get("catalog_name")
schema_name = dbutils.widgets.get("schema_name")
date = dbutils.widgets.get("date")
overwrite = dbutils.widgets.get("overwrite")

# date = '2024-07-22'
# source_path = 's3://qa-adc-marshall-rwe-us-west-2/data/history/fsl2/'
# catalog_name = 'qa-adc-marshallrwe-catalog-us-west-2'
# schema_name = 'rwe-history-fsl2'
# overwrite = False

# COMMAND ----------

# #These steps are to remove the extra tables. Need to delete this after
spark.sql(f"DROP TABLE `{catalog_name}`.`{schema_name}`.`account-devices`;")
spark.sql(f"DROP TABLE `{catalog_name}`.`{schema_name}`.`device-settings`;")
spark.sql(f"DROP TABLE `{catalog_name}`.`{schema_name}`.`whitelisted-devices`;")

# COMMAND ----------

# MAGIC %md
# MAGIC # History Schemas

# COMMAND ----------


history_account_devices_schema = StructType([
    StructField("accountid", StringType(), True),
    StructField("deviceuuid", StringType(), True),
    StructField("uploaddate", StringType(), True),
    StructField("date_", DateType(), True)
])


history_device_settings_schema = StructType([
    StructField("accountid", StringType(), True),
    StructField("deviceuuid", StringType(), True),
    StructField("devicenationality", StringType(), True),
    StructField("uploadsequence", StringType(), True),
    StructField("firmwareversion", StringType(), True),
    StructField("systemtype", StringType(), True),
    StructField("readertype", StringType(), True),
    StructField("devicetype", StringType(), True),
    StructField("uploaddate", StringType(), True),
    StructField("date_", StringType(), True)
])

history_food_schema = StructType([
    StructField("accountid", StringType(), True),
    StructField("factoryrecorded", StringType(), True),
    StructField("userrecorded", StringType(), True),
    StructField("deviceuuid", StringType(), True),
    StructField("devicenationality", StringType(), True),
    StructField("uploadsequence", StringType(), True),
    StructField("firmwareversion", StringType(), True),
    StructField("mealname", StringType(), True),
    StructField("valuecarbs", FloatType(), True),
    StructField("uploaddate", StringType(), True),
    StructField("date_", StringType(), True)
])

history_generic_schema = StructType([
    StructField("accountid", StringType(), True),
    StructField("factoryrecorded", StringType(), True),
    StructField("userrecorded", StringType(), True),
    StructField("deviceuuid", StringType(), True),
    StructField("devicenationality", StringType(), True),
    StructField("uploadsequence", StringType(), True),
    StructField("firmwareversion", StringType(), True),
    StructField("type", StringType(), True),
    StructField("localization", StringType(), True),
    StructField("fixedlowglucosealarmisinepisode", BooleanType(), True),
    StructField("fixedlowglucosealarmiscleared", BooleanType(), True),
    StructField("fixedlowglucosealarmispresented", BooleanType(), True),
    StructField("fixedlowglucosealarmisdismissed", BooleanType(), True),
    StructField("lowglucosealarmisinepisode", BooleanType(), True),
    StructField("lowglucosealarmiscleared", BooleanType(), True),
    StructField("lowglucosealarmispresented", BooleanType(), True),
    StructField("lowglucosealarmisdismissed", BooleanType(), True),
    StructField("highglucosealarmisinepisode", BooleanType(), True),
    StructField("highglucosealarmiscleared", BooleanType(), True),
    StructField("highglucosealarmispresented", BooleanType(), True),
    StructField("highglucosealarmisdismissed", BooleanType(), True),
    StructField("signallossalarmisinepisode", BooleanType(), True),
    StructField("signallossalarmiscleared", BooleanType(), True),
    StructField("signallossalarmispresented", BooleanType(), True),
    StructField("signallossalarmisautodismissed", BooleanType(), True),
    StructField("signallossalarmisuserdismissed", BooleanType(), True),
    StructField("lowglucosethresholdinmgdl", StringType(), True),
    StructField("highglucosethresholdinmgdl", StringType(), True),
    StructField("islowglucoseenabled", BooleanType(), True),
    StructField("ishighglucoseenabled", BooleanType(), True),
    StructField("issignallossalarmenabled", BooleanType(), True),
    StructField("isalarmsoundenabled", BooleanType(), True),
    StructField("isalarmnotificationenabled", BooleanType(), True),
    StructField("configurationchangesource", IntegerType(), True),
    StructField("value", StringType(), True),
    StructField("timedelta", StringType(), True),
    StructField("uploaddate", StringType(), True), 
    StructField("sensoruid", StringType(), True),
    StructField("producttype", StringType(), True),
    StructField("date_", StringType(), True)
])

history_insulin_schema = StructType([
    StructField("accountid", StringType(), True), 
    StructField("factoryrecorded", StringType(), True), 
    StructField("userrecorded", StringType(), True), 
    StructField("deviceuuid", StringType(), True), 
    StructField("devicenationality", StringType(), True), 
    StructField("uploadsequence", StringType(), True), 
    StructField("firmwareversion", StringType(), True), 
    StructField("type", StringType(), True),
    StructField("units", DoubleType(), True),
    StructField("insulinonboardinunits", StringType(), True),
    StructField("correctionamountinunits", StringType(), True),
    StructField("mealamountinunits", StringType(), True),
    StructField("useroverrideinunits", StringType(), True), 
    StructField("uploaddate", StringType(), True), 
    StructField("date_", StringType(), True)
])

history_insulin_device_schema = StructType([
    StructField("accountid", StringType(), True),
    StructField("deviceuuid", StringType(), True),
    StructField("devicenationality", StringType(), True),
    StructField("manufacturer", StringType(), True),
    StructField("modelname", StringType(), True),
    StructField("localmodelname", StringType(), True),
    StructField("serialnumber", StringType(), True),
    StructField("hardwarerevision", StringType(), True),
    StructField("firmwarerevision", StringType(), True),
    StructField("softwarerevision", StringType(), True),
    StructField("blesoftwarerevision", StringType(), True),
    StructField("bleprotocolrevision", StringType(), True),
    StructField("devicetime", StringType(), True),
    StructField("defaultinsulintype", StringType(), True),
    StructField("defaultinsulinbrand", StringType(), True),
    StructField("uploadsequence", LongType(), True),
    StructField("uploaddate", StringType(), True),
    StructField("date_", StringType(), True)
])

history_insulin_device_data_schema = StructType([
    StructField("accountid", StringType(), True), 
    StructField("deviceuuid", StringType(), True), 
    StructField("devicenationality", StringType(), True), 
    StructField("relativetimestamp", StringType(), True), 
    StructField("elapsedseconds", StringType(), True), 
    StructField("serialnumber", StringType(), True), 
    StructField("localtimestamp", StringType(), True), 
    StructField("utctimestamp", StringType(), True), 
    StructField("value", StringType(), True), 
    StructField("insulintype", StringType(), True), 
    StructField("insulinbrand", StringType(), True), 
    StructField("primedose", BooleanType(), True), 
    StructField("primealgo", BooleanType(), True), 
    StructField("editeddose", BooleanType(), True), 
    StructField("statusflags", StringType(), True), 
    StructField("uploadsequence", LongType(), True), 
    StructField("uploaddate", StringType(), True),
    StructField("date_", StringType(), True)
])

history_ketone_schema = StructType([
    StructField("accountid", StringType(), True), 
    StructField("factoryrecorded", StringType(), True), 
    StructField("userrecorded", StringType(), True), 
    StructField("deviceuuid", StringType(), True), 
    StructField("devicenationality", StringType(), True), 
    StructField("uploadsequence", StringType(), True), 
    StructField("firmwareversion", StringType(), True), 
    StructField("valuemmol", DoubleType(), True),  
    StructField("uploaddate", StringType(), True), 
    StructField("date_", StringType(), True)
])

history_scheduled_schema = StructType([
    StructField("accountid", StringType(), True), 
    StructField("factoryrecorded", StringType(), True), 
    StructField("userrecorded", StringType(), True), 
    StructField("deviceuuid", StringType(), True), 
    StructField("devicenationality", StringType(), True), 
    StructField("uploadsequence", StringType(), True), 
    StructField("firmwareversion", StringType(), True), 
    StructField("mgdl", DoubleType(), True),
    StructField("firstaftertimechange", BooleanType(), True),
    StructField("devicetype",StringType(), True),
    StructField("sensoruid", StringType(), True), 
    StructField("uploaddate", StringType(), True), 
    StructField("sensoruidcorrected", StringType(), True), 
    StructField("date_", StringType(), True)
])

history_strip_schema =  StructType([
    StructField("accountid", StringType(), True), 
    StructField("factoryrecorded", StringType(), True), 
    StructField("userrecorded", StringType(), True), 
    StructField("deviceuuid", StringType(), True), 
    StructField("devicenationality", StringType(), True), 
    StructField("uploadsequence", StringType(), True), 
    StructField("firmwareversion", StringType(), True), 
    StructField("mgdl", DoubleType(), True), 
    StructField("uploaddate", StringType(), True), 
    StructField("date_", StringType(), True)
])

history_unscheduled_schema = StructType([
    StructField("accountid", StringType(), True), 
    StructField("factoryrecorded", StringType(), True), 
    StructField("userrecorded", StringType(), True), 
    StructField("deviceuuid", StringType(), True), 
    StructField("devicenationality", StringType(), True), 
    StructField("uploadsequence", StringType(), True), 
    StructField("firmwareversion", StringType(), True), 
    StructField("mgdl", DoubleType(), True),
    StructField("actionable", BooleanType(), True),
    StructField("trendarrow", StringType(), True),
    StructField("uploaddate", StringType(), True),
    StructField("date_", StringType(), True)
])
                

history_whitelisted_devices_schema = StructType([
    StructField("reader_uuid", StringType(), True),
    StructField("firmware_version", StringType(), True),
    StructField("date_", StringType(), True),
    StructField("uploaddate", StringType(), True),

])





# COMMAND ----------

# MAGIC %md
# MAGIC # Processed Schemas

# COMMAND ----------

#TBD

# COMMAND ----------

# MAGIC %md
# MAGIC # Processing

# COMMAND ----------

# List all items in the specified S3 folder
if "s3://" in source_path:
    s3_path = source_path
else:
    s3_path = f's3://{source_path}'

if 'history' in s3_path:
    temp_items = dbutils.fs.ls(s3_path)
    items = [item.path + f"date_={date}/" for item in temp_items if 'backup' not in item.path]
elif 'processed' in s3_path:
    path = s3_path + f"date={date}/"
    temp_items = dbutils.fs.ls(path)
    items = [item.path for item in temp_items]

items

# COMMAND ----------

dataframes = {}
for item in items:
    dfname = item.split('/')
    if 'processed' in dfname:
        name = dfname[len(dfname) - 2]
    elif 'history' in dfname:
        name = dfname[len(dfname) - 3]
        name = name.replace('-', '_')
    try:
        if 'history' in dfname:
            df = (spark.read.format("csv")
            .option("header", "true")
            .schema(globals()[f"history_{name}_schema"])
            .load(item))
        else:
            df = (spark.read.format("csv")
            .option("header", "true")
            .option("inferSchema", "false")
            .load(item))
        datenow = str(datetime.datetime.now().date())
        df = df.withColumn("date_", lit(datenow))
        dataframes[name] = df
    except Exception as e:
        print("Error found with", item)
        print(e)
    


# COMMAND ----------

display(dataframes['food'])

# COMMAND ----------


if overwrite == True:
    spark.sql(f"DROP SCHEMA IF EXISTS `{catalog_name}`.`{schema_name}` CASCADE;")
    mode = "overwrite"
else:
    mode = "append"

spark.sql(f"CREATE SCHEMA IF NOT EXISTS `{catalog_name}`.`{schema_name}`")


for table in dataframes:
    try:
        (dataframes[table].write
            .format('delta')
            .mode(mode)
            .saveAsTable(f"`{catalog_name}`.`{schema_name}`.`{table}`"))
    except Exception as e:
        print(table)
        print(e)
        



