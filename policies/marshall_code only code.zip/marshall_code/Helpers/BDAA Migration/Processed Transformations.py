# Databricks notebook source
# source_path = 'qa-adc-marshall-rwe-us-west-2/data/processed/fsl2/2024-05-29/'
# catalog_name = 'qa-adc-marshallrwe-catalog-us-west-2'
# schema_name = 'rwe-test-processed'

source_path = dbutils.widgets.get("source_path")
catalog_name = dbutils.widgets.get("catalog_name")
schema_name = dbutils.widgets.get("schema_name")

# COMMAND ----------

# # List all items in the specified S3 folder
# s3_path = f's3://{source_path}'
# items = dbutils.fs.ls(s3_path)

# # Display the items
# display(items)



# COMMAND ----------

# dataframes = {}
# for item in items:
#     path = item.path
#     dfname = path.split('/')
#     name = dfname[len(dfname) - 2]
#     try:
#         df = spark.read.format("csv") \
#         .option("header", "true") \
#         .option("inferSchema", "false") \
#         .load(path)
#         dataframes[name] = df
#     except Exception:
#         print(path)
    


# COMMAND ----------


# spark.sql(f"CREATE SCHEMA IF NOT EXISTS `{catalog_name}`.`{schema_name}`")

# for table in dataframes:
#     try:
#         (dataframes[table].write
#             .format('delta')
#             .mode("overwrite")
#             .saveAsTable(f"`{catalog_name}`.`{schema_name}`.`{table}`"))
#     except Exception:
#         print(table)




# COMMAND ----------

#Manual table modification
spark.sql(f"ALTER TABLE `{catalog_name}`.`{schema_name}`.`device` RENAME TO `{catalog_name}`.`{schema_name}`.`device_stg`")
spark.sql(f"""CREATE TABLE `{catalog_name}`.`{schema_name}`.`device` AS (
    SELECT 
        device_id, 
        reader_uuid, 
        reader_nationality,  
        first_sched_factory_reading, 
        last_sched_factory_reading,  
        first_sched_user_reading,  
        last_sched_user_reading,  
        sensor_count,
        sched_reading_count as raw_sched_reading_count,   
        unsched_reading_count as raw_unsched_reading_count,   
        nvl(round(unsched_reading_count / (((datediff(minute, first_sched_factory_reading, last_sched_factory_reading)/1440)+1)*1.0), 0),0) as avg_scan_per_wear_day,   
        abandoned_ind,   
        use_insulin_calc_ind,  
        current_firmware_version,   
        data_sufficiency_ind,
        medicare_patient,
        medicare_start_date,
        system_type,
        reader_type
    FROM
        `{catalog_name}`.`{schema_name}`.`device_stg`
)""")

spark.sql(f"DROP TABLE `{catalog_name}`.`{schema_name}`.`device_stg`")

# COMMAND ----------

spark.sql(f"ALTER TABLE `{catalog_name}`.`{schema_name}`.`sensor` RENAME TO `{catalog_name}`.`{schema_name}`.`sensor_stg`")
spark.sql(f"""CREATE TABLE `{catalog_name}`.`{schema_name}`.`sensor` AS (
    SELECT 
        sensor_id, 
        device_id, 
        reader_uuid, 
        sensor_no, 
        first_sched_user_reading, 
        last_sched_user_reading, 
        first_sched_factory_reading, 
        last_sched_factory_reading,
        hours_operational, 
        confirm_status, 
        time_to_next_sensor_start, 
        sched_reading_count, 
        unsched_reading_count, 
        nvl(round(unsched_reading_count / (((datediff(minute, first_sched_factory_reading, last_sched_factory_reading)/1440)+1)*1.0), 0),0) as avg_scan_per_wear_day,
        read_in_target, 
        read_below_target, 
        read_above_target, 
        time_in_target,  
        time_below_target, 
        time_above_target, 
        last_confirmed_sensor_ind, 
        irregular_sensor, 
        reader_nationality, 
        data_sufficiency_ind,
        sensor_uid,
        product_type,
        original_sensor_uid
    FROM
        `{catalog_name}`.`{schema_name}`.`sensor_stg`
)""")

spark.sql(f"DROP TABLE `{catalog_name}`.`{schema_name}`.`sensor_stg`")

# COMMAND ----------

spark.sql(f"ALTER TABLE `{catalog_name}`.`{schema_name}`.`scheduled` RENAME TO `{catalog_name}`.`{schema_name}`.`scheduled_glucose_reading`")

spark.sql(f"ALTER TABLE `{catalog_name}`.`{schema_name}`.`ketone` RENAME TO `{catalog_name}`.`{schema_name}`.`ketone_reading`")

spark.sql(f"ALTER TABLE `{catalog_name}`.`{schema_name}`.`strip` RENAME TO `{catalog_name}`.`{schema_name}`.`strip_glucose_reading`")

spark.sql(f"ALTER TABLE `{catalog_name}`.`{schema_name}`.`unscheduled` RENAME TO `{catalog_name}`.`{schema_name}`.`unscheduled_glucose_reading`")

spark.sql(f"ALTER TABLE `{catalog_name}`.`{schema_name}`.`upload_stat` RENAME TO `{catalog_name}`.`{schema_name}`.`upload_statistics`")

# COMMAND ----------

#Tables still needed
#ref_country
#ref_insulin_status

# COMMAND ----------

spark.sql(f"""CREATE TABLE `{catalog_name}`.`{schema_name}`.SENSOR_WEAR_DAY AS (
    SELECT
        sens_day.sensor_id,
        sens_day.wear_day wear_day,
        sens_day.wd_sched_reading_count wd_sched_reading_count,
        NVL(ug.unsched_reads, 0) wd_unsched_reading_count,
        sens_day.time_in_target,
        sens_day.time_above_target,
        sens_day.time_below_target,
        percentile.ptc10 percentile_10th,
        percentile.ptc25 percentile_25th,
        percentile.ptc50 percentile_50th,
        percentile.ptc75 percentile_75th,
        percentile.ptc90 percentile_90th
    FROM (
        select 
            sensor_id, 
            wear_day, 
            sched_reads as wd_sched_reading_count, 
            NVL(ROUND(read_in_target/(sched_reads * 1.0) ,5)*24,0) as time_in_target,
            NVL(ROUND(read_above_target/(sched_reads * 1.0) ,5)*24,0) as time_above_target,
            NVL(ROUND(read_below_target/(sched_reads * 1.0) ,5)*24,0) as time_below_target
        from (
            select sensor_id, 
            wear_day,
            count(case when CAST(read_in_target_flg AS BOOLEAN) then 1 end) as read_in_target, 
            count(case when CAST(read_below_target_flg AS BOOLEAN) then 1 end) as read_below_target,
            count(case when CAST(read_above_target_flg AS BOOLEAN) then 1 end) as read_above_target,
            count(*) as sched_reads
            from `{catalog_name}`.`{schema_name}`.scheduled_glucose_reading 
        group by sensor_id, wear_day)) sens_day
    JOIN (
        SELECT DISTINCT
            sg.sensor_id,
            sg.wear_day,
            PERCENTILE_CONT (0.1)
              WITHIN GROUP ( ORDER BY sg.value_mgdl ASC)
              OVER (PARTITION BY sg.sensor_id, sg.wear_day) ptc10,
            PERCENTILE_CONT (0.25)
              WITHIN GROUP ( ORDER BY sg.value_mgdl ASC)
              OVER (PARTITION BY sg.sensor_id, sg.wear_day) ptc25,
            PERCENTILE_CONT (0.5)
              WITHIN GROUP ( ORDER BY sg.value_mgdl ASC)
              OVER (PARTITION BY sg.sensor_id, sg.wear_day) ptc50,
            PERCENTILE_CONT (0.75)
              WITHIN GROUP ( ORDER BY sg.value_mgdl ASC)
              OVER (PARTITION BY sg.sensor_id, sg.wear_day) ptc75,
            PERCENTILE_CONT (0.9)
              WITHIN GROUP ( ORDER BY sg.value_mgdl ASC)
              OVER (PARTITION BY sg.sensor_id, sg.wear_day) ptc90
          FROM
            `{catalog_name}`.`{schema_name}`.scheduled_glucose_reading  sg) percentile
ON  percentile.sensor_id = sens_day.sensor_id AND percentile.wear_day = sens_day.wear_day
LEFT OUTER JOIN (select sensor_id, wear_day, count(*) as unsched_reads 
from `{catalog_name}`.`{schema_name}`.unscheduled_glucose_reading group by sensor_id, wear_day) ug
ON ug.sensor_id = sens_day.sensor_id AND ug.wear_day = sens_day.wear_day
)""")

# COMMAND ----------

spark.sql(f"""
    CREATE TABLE `{catalog_name}`.`{schema_name}`.DISTRIBUTION_BY_WEARDAY_SCAN_FREQUENCY AS (
        SELECT  
            d.READER_NATIONALITY, 
            a.SENSOR_START_YEAR,
            a.SENSOR_START_MONTH, 
            a.AVG_SCAN_PER_WEAR_DAY,
            COUNT(s.sensor_id) SENSOR_COUNT, 
            COUNT(DISTINCT(d.DEVICE_ID)) DISTINCT_DEVICE_COUNT
        FROM
          (SELECT
                extract(year from s.FIRST_SCHED_FACTORY_READING) SENSOR_START_YEAR,
                extract(month from s.FIRST_SCHED_FACTORY_READING) SENSOR_START_MONTH,
                AVG_SCAN_PER_WEAR_DAY
            FROM `{catalog_name}`.`{schema_name}`.sensor s
            UNION
            SELECT
                extract(year from d.FIRST_SCHED_FACTORY_READING) SENSOR_START_YEAR,
                extract(month from d.FIRST_SCHED_FACTORY_READING) SENSOR_START_MONTH,
                AVG_SCAN_PER_WEAR_DAY
            FROM `{catalog_name}`.`{schema_name}`.device d) a
        JOIN `{catalog_name}`.`{schema_name}`.SENSOR s 
        ON s.AVG_SCAN_PER_WEAR_DAY = a.AVG_SCAN_PER_WEAR_DAY
        AND extract(month from s.FIRST_SCHED_FACTORY_READING) = a.SENSOR_START_MONTH
        AND extract(year from s.FIRST_SCHED_FACTORY_READING) = a.SENSOR_START_YEAR
        JOIN `{catalog_name}`.`{schema_name}`.device d ON d.DEVICE_ID = s.DEVICE_ID
        WHERE s.irregular_sensor = 0
        GROUP BY d.READER_NATIONALITY, a.SENSOR_START_YEAR, a.SENSOR_START_MONTH, a.AVG_SCAN_PER_WEAR_DAY)
""")



# COMMAND ----------


