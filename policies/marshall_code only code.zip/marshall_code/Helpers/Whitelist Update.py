# Databricks notebook source
from pyspark.sql.functions import col, when

blacklisted = ["3.4.0.7368"]
input_catalog = "`qa-adc-dmz-catalog-us-west-2`"
firmware_catalog = "`qa-adc-marshallrwe-catalog-us-west-2`"
input_schema = "`rwe-input-fsl3`"
firmware_schema = "`rwe-miscellaneous`"

# COMMAND ----------

df = spark.sql(f"""
    SELECT d.firmwareversion as firmware_version, d.systemtype as system_type, f.included_in_reporting 
    FROM {input_catalog}.{input_schema}.device_settings d
    LEFT JOIN {firmware_catalog}.{firmware_schema}.`wl-firmwares` f
    ON f.firmwareversion = d.firmwareversion
    GROUP BY d.firmwareversion, d.systemtype, f.included_in_reporting
    ORDER BY d.firmwareversion ASC
 """)
display(df)

# COMMAND ----------

# Update the included_in_reporting column to 1
updated_df = df.withColumn("included_in_reporting", 
                    when(col("included_in_reporting").isNull(), 1)
                    .when(col("firmware_version").isin(blacklisted), -1)
                    .otherwise(col("included_in_reporting")))

display(updated_df)

# COMMAND ----------

# Write the updated rows back to the wl-firmwares table using merge
updated_df.createOrReplaceTempView("updated_firmwares")

spark.sql(f"""
    MERGE INTO {firmware_catalog}.{firmware_schema}.`wl-firmwares` AS target
    USING updated_firmwares AS source
    ON target.firmwareversion = source.firmwareversion
    WHEN MATCHED THEN
        UPDATE SET *
    WHEN NOT MATCHED THEN
        INSERT *
""")
