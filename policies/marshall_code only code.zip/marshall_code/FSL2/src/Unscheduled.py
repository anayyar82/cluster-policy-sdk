# Databricks notebook source
from pyspark.sql.functions import col, lit, from_unixtime, unix_timestamp, monotonically_increasing_id, hour, date_format, to_timestamp

import dlt
import bronze_schema
import gold_schema

from variables_orig import *
from data_quality import *

# COMMAND ----------

# MAGIC %md # Bronze Table

# COMMAND ----------

#Creating original table
@dlt.table(temporary=temporary)
@dlt.expect_all_or_drop(unscheduled_input_rules)
def unscheduled_input():
    df = (spark.read
            .table(f"`{dmz_catalog}`.`{input_schema}`.`current`")
            .where(col("uploaddate").between(start_date, end_date))
    )

                   
    return df.withColumn("date_", lit(snapshot_date))


@dlt.table(temporary=temporary)
def unscheduled_history():
    query = f"SHOW TABLES IN `{history_catalog}`.`{history_schema}` LIKE 'unscheduled'"
    result = spark.sql(query).collect()
    if result:
        return (spark.read
                .table(f'`{history_catalog}`.`{history_schema}`.`unscheduled`')
        )
    else:
          return spark.createDataFrame([], schema=bronze_schema.unscheduled_schema)  

#@dlt.view()
@dlt.table(temporary=temporary)
def unscheduled_combined():
    return spark.sql("SELECT * from LIVE.unscheduled_input UNION SELECT * from LIVE.unscheduled_history;")

#@dlt.view()
@dlt.table(temporary=temporary)
def unscheduled_dedup():
    df = spark.sql(f"SELECT * from LIVE.unscheduled_combined ORDER BY deviceuuid ASC, factoryrecorded ASC, uploadsequence ASC, date_ ASC;")
    return df.dropDuplicates(subset=['deviceUUID', 'factoryrecorded'])


#@dlt.view()
@dlt.table(temporary=temporary)
def unscheduled_blacklist():
    return spark.sql("select a.* from live.unscheduled_dedup as a LEFT Join live.bronze_blacklist_account as b on a.accountid = b.accountid where b.accountId is null")


@dlt.view(name=unscheduled_table_name + "BRONZE")
def unscheduled_threshold():
    return spark.sql("""SELECT a.* from live.unscheduled_blacklist as a WHERE a.accountid in (
        SELECT accountid from live.accounts_greater_than_threshold where accountid is not null
    )""")



@dlt.table(
  name=unscheduled_table_name + "BRONZE_HISTORY",
  comment="combined unscheduled",
  schema=bronze_schema.unscheduled_schema,
  temporary=temporary)
def unscheduled_update_history():
    df = spark.sql(f"select * from live.{unscheduled_table_name}BRONZE where date_ = '{snapshot_date}' ")
    
    df.write.mode("append").format("delta")\
        .option('nullValue', None)\
        .option("mergeSchema", "false")\
        .saveAsTable(f"`{marshall_catalog}`.`{history_schema}`.`unscheduled`")
    
    return df


# COMMAND ----------

# MAGIC %md # Silver Table

# COMMAND ----------

#@dlt.view()
@dlt.table(temporary=temporary)
def unscheduled_filtered():
    #Formating Time
    time_df = spark.sql(f"select  if  (instr(right(userrecorded,6), '+') > 0 or instr(right(userrecorded,6), '-') > 0 , substr(userrecorded,0,length(userrecorded)-6) , userrecorded) as userrecorded_modified,*  from LIVE.{unscheduled_table_name}BRONZE")

    time_df = time_df.drop("userrecorded") \
                    .withColumnRenamed("userrecorded_modified", "userrecorded") \
                    .withColumn('userrecorded', to_timestamp(col('userRecorded'))) \
                    .withColumn('factoryrecorded', to_timestamp(col('factoryrecorded')))
    return time_df

@dlt.table(
  name=unscheduled_table_name + "SILVER",
  comment="silver unscheduled",
  temporary=temporary)
def unscheduled_silver():
    new_df = spark.sql("SELECT * from LIVE.unscheduled_filtered;")
    new_df = new_df \
                        .withColumn("factoryrechour", hour(new_df.factoryrecorded)) \
                        .withColumn("userrechour", hour(new_df.userrecorded))

    new_df = new_df.withColumnRenamed("deviceuuid", "reader_uuid") \
                    .withColumnRenamed("devicenationality", "country") \
                    .withColumnRenamed("uploadsequence", "upload_id") \
                    .withColumnRenamed("firmwareversion", "firmware")      

    new_df.orderBy(new_df['reader_uuid'].asc(), new_df['factoryrecorded'].asc())
    
    return new_df


# COMMAND ----------

# MAGIC %md # Gold Table

# COMMAND ----------


@dlt.table(temporary=temporary)
def unscheduled_final():
    results_unschd_df = spark.sql(
        """
        select
            device_id,
            sensor_no,
            sensor_id,
            CAST(upload_id as BIGINT),
            irregular_reading,
            ROUND(value_mgdl, 2) as value_mgdl,
            user_recorded,
            user_rec_hour,
            factory_recorded,
            factory_rec_hour,
            wear_day,
            calendar_day,
            first_last_calendar_day_ind,

            CASE
                WHEN last_scan_fac >= factory_recorded THEN CAST(factory_recorded as timestamp)
                WHEN unix_timestamp(factory_recorded, 'yyyy-MM-dd HH:mm:ss') - unix_timestamp(last_scan_fac, 'yyyy-MM-dd HH:mm:ss') < 28800 THEN CAST(last_scan_fac as timestamp)
                ELSE CAST((factory_recorded + INTERVAL '-28800' SECOND) AS timestamp)
            END as last_scan_fac,

            usage_day,
            ownership_day,
            reader_uuid,
            country,
            date_
            from (
                select
                    device.device_id as device_id,
                    sensor.sensor_no as sensor_no,
                    sensor.sensor_id as sensor_id,
                    sensor.first_sched_factory_reading as sens_first_factory_reading,
                    unsched_glucose.upload_id,
                    case 
                        when (int((int(unix_timestamp(unsched_glucose.factoryRecorded, 'yyyy-MM-dd HH:mm:ss')/60) - int(unix_timestamp(sensor.first_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')/60))/(1440)) + 1)  > 14 
                        then TRUE 
                        else FALSE 
                    end as irregular_reading,

                    unsched_glucose.mgdl as value_mgdl,
                    unsched_glucose.userRecorded as user_recorded,
                    unsched_glucose.userRecHour as user_rec_hour,
                    unsched_glucose.factoryrecorded as factory_recorded,
                    unsched_glucose.factoryRecHour as factory_rec_hour,

                    cast(((int(unix_timestamp(unsched_glucose.factoryRecorded, 'yyyy-MM-dd HH:mm:ss')/60) - int(unix_timestamp(sensor.first_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')/60))/(1440)) + 1 as int) as wear_day,
                    
                    datediff(unsched_glucose.factoryRecorded, sensor.first_sched_factory_reading) + 1 as calendar_day,

                    case
                        when day(unsched_glucose.factoryRecorded) = day(sensor.first_sched_factory_reading)
                        then TRUE
                        when day(unsched_glucose.factoryRecorded) = day(sensor.last_sched_factory_reading) 
                        then TRUE
                        else FALSE 
                    end as first_last_calendar_day_ind,


                    NVL(from_unixtime(unix_timestamp((CAST(nvl(lag(unsched_glucose.factoryRecorded, 1) over (partition by device.device_id order by unsched_glucose.factoryRecorded) + INTERVAL '1' SECOND, sensor.first_sched_factory_reading) as TIMESTAMP)), 'yyyy-MM-dd HH:mm:ss'), 'yyyy-MM-dd HH:mm:ss'), sensor.first_sched_factory_reading ) as last_scan_fac,

                    useday.use_day as usage_day,
                    datediff(unsched_glucose.factoryRecorded, device.first_sched_factory_reading) as ownership_day,
                    device.reader_uuid as reader_uuid,
                    unsched_glucose.country,
                    CAST(unsched_glucose.date_ as date)
                from 
                    LIVE.UNSCHEDULED_GLUCOSE_READING_SILVER as unsched_glucose 
                inner join LIVE.DEVICE_SETTINGS_SILVER as device 
                on unsched_glucose.reader_uuid = device.reader_uuid
                left outer join LIVE.useday_filtered as useday 
                on (
                    unsched_glucose.reader_uuid = useday.reader_uuid 
                    and to_date(unsched_glucose.factoryRecorded, 'yyyy-MM-dd HH:mm:ss') = to_date(useday.factoryRecorded, 'yyyy-MM-dd HH:mm:ss')
                )
                inner join LIVE.SENSOR_SILVER as sensor 
                on (
                    device.device_id = sensor.device_id 

                    and unix_timestamp(unsched_glucose.factoryRecorded, 'yyyy-MM-dd HH:mm:ss') between 
                        unix_timestamp(sensor.first_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss') 
                        and 
                        unix_timestamp(sensor.last_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')
                )
                order by device.reader_uuid, sensor.sensor_no, unsched_glucose.factoryrecorded
            )
        """)

    return results_unschd_df.withColumn("unsched_glucose_id", monotonically_increasing_id())
    

# COMMAND ----------

@dlt.table(temporary=temporary)
def ondemand_alarms():
    return spark.sql("""
        select 
            factoryrecorded,
            userrecorded,
            reader_uuid,
            max((case When type ='low' then TRUE else FALSE end)) as ondemand_low_alarm,
            max((case When type ='high' then TRUE else FALSE end)) as ondemand_high_alarm,
            max((case When type ='projectedlow' then TRUE else FALSE end)) as ondemand_projected_low_alarm,
            max((case When type ='projectedhigh' then TRUE else FALSE end)) as ondemand_projected_high_alarm
        from (
            select 
                factoryrecorded,
                userrecorded,
                reader_uuid, 
                type 
            from
                LIVE.GENERIC_SILVER 
            where type in ('low','high','projectedlow','projectedhigh')
        ) as ondemandalarms
        group by factoryrecorded,userrecorded,reader_uuid
    """)


@dlt.table(name=unscheduled_table_name + "GOLD",
  comment="gold unscheduled",
  schema=gold_schema.unscheduled_schema
)
def unscheduled_gold(): 
    df = spark.sql("""
        select 
            unscheduled.* , 
            ondemand_low_alarm, 
            ondemand_high_alarm,
            ondemand_projected_low_alarm,
            ondemand_projected_high_alarm 
        from 
            LIVE.unscheduled_final as unscheduled
        left join LIVE.ondemand_alarms 
        on unscheduled.reader_uuid = ondemand_alarms.reader_uuid 
        and unscheduled.factory_recorded = ondemand_alarms.factoryrecorded
    """)
    return df.withColumnRenamed("date_", "first_processed_date")
