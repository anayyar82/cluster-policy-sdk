# Databricks notebook source
from pyspark.sql.functions import col, lit, from_unixtime, unix_timestamp, monotonically_increasing_id, hour, date_format, to_timestamp

import dlt
import bronze_schema
import gold_schema

from variables_orig import *
from data_quality import *

# COMMAND ----------

# MAGIC %md # Bronze Table

# COMMAND ----------

#Creating original table
@dlt.table(temporary=temporary)
@dlt.expect_all_or_drop(food_input_rules)
def food_input():
    df = (spark.read
            .table(f"`{dmz_catalog}`.`{input_schema}`.`{food_table_name[:-1]}`")
            .where(col("uploaddate").between(start_date, end_date))
    )              
    return df.withColumn("date_", lit(snapshot_date))



@dlt.table(temporary=temporary)
def food_history():
    query = f"SHOW TABLES IN `{history_catalog}`.`{history_schema}` LIKE '{food_table_name[:-1]}'"
    result = spark.sql(query).collect()
    
    if result:
        return (spark.read
                .table(f'`{history_catalog}`.`{history_schema}`.`{food_table_name[:-1]}`')
        )
    else:
        return spark.createDataFrame([], schema=bronze_schema.food_schema)



@dlt.view()
#@dlt.table(temporary=temporary)
def food_combined():
    return spark.sql("SELECT * from LIVE.food_input UNION SELECT * from LIVE.food_history;")


@dlt.view()
#@dlt.table(temporary=temporary)
def food_dedup():
    df = spark.sql(f"SELECT * from LIVE.food_combined ORDER BY deviceuuid ASC, factoryrecorded ASC, uploadsequence ASC, date_ ASC;")
    return df.dropDuplicates(subset=['deviceuuid', 'factoryrecorded'])

#@dlt.view()
@dlt.table(temporary=temporary)
def food_blacklist():
    return spark.sql(f"""
            select 
                a.* 
            from live.food_dedup as a 
            LEFT Join live.bronze_blacklist_account as b 
            on a.accountid = b.accountid 
            where b.accountId is null
""")
    
@dlt.view(name=food_table_name + "BRONZE")
def food_threshold():
    return spark.sql("""SELECT a.* from live.food_blacklist as a WHERE a.accountid in (
        SELECT accountid from live.accounts_greater_than_threshold where accountid is not null
    )""")


#Update Food History

@dlt.table(
  name=food_table_name + "HISTORY_BRONZE",
  comment="combined food",
  schema=bronze_schema.food_schema,
  temporary=temporary)
def food_update_history():
    df=spark.sql(f"select * from live.{food_table_name}BRONZE where date_ = '{snapshot_date}' ")
    
    df.write.mode("append").format("delta")\
        .option('nullValue', None)\
        .option("mergeSchema", "false")\
        .saveAsTable(f"`{marshall_catalog}`.`{history_schema}`.`{food_table_name[:-1]}`")

    
    return df

# COMMAND ----------

# MAGIC %md # Silver Table

# COMMAND ----------

#@dlt.view()
@dlt.table(temporary=temporary)
def food_filtered():
    #Formating Time
    time_df = spark.sql(f"select  if  (instr(right(userrecorded,6), '+') > 0 or instr(right(userrecorded,6), '-') > 0 , substr(userrecorded,0,length(userrecorded)-6) , userrecorded) as userrecorded_modified,* from LIVE.{food_table_name}BRONZE")

    time_df = time_df.drop("userrecorded") \
                    .withColumnRenamed("userrecorded_modified", "userrecorded") \
                    .withColumn('userrecorded', to_timestamp(col('userRecorded'))) \
                    .withColumn('factoryrecorded', to_timestamp(col('factoryrecorded')))
    return time_df

@dlt.table(
  name=food_table_name + "SILVER",
  temporary = temporary)
def food_silver():
    new_df = spark.sql("SELECT * from LIVE.food_filtered;")
    new_df = new_df \
                        .withColumn("factoryrechour", hour(new_df.factoryrecorded)) \
                        .withColumn("userrechour", hour(new_df.userrecorded))


    new_df = new_df.withColumnRenamed("deviceUUID", "reader_uuid") \
                                        .withColumnRenamed("deviceNationality", "country") \
                                        .withColumnRenamed("uploadSequence", "upload_id") \
                                        .withColumnRenamed("firmwareVersion", "firmware")      

    new_df.orderBy(new_df['reader_uuid'].asc(), new_df['factoryrecorded'].asc())
    
    return new_df


# COMMAND ----------

# MAGIC %md # Gold Table

# COMMAND ----------

@dlt.table(
  name=food_table_name + "GOLD",
  comment="gold food",
  schema=gold_schema.food_schema)
def food_gold():
    results_food_df = spark.sql("""
        SELECT 
            d.device_id,
            CASE 
                WHEN unix_timestamp(f.factoryrecorded) BETWEEN unix_timestamp(S.FIRST_SCHED_FACTORY_READING) AND unix_timestamp(S.LAST_SCHED_FACTORY_READING) 
                THEN TRUE
                ELSE FALSE 
                END 
            as active_sensor_ind,
                
            S.sensor_id, 
            S.sensor_no, 
            CAST(f.upload_id as bigint), 
            f.mealname as meal_name, 
            f.valuecarbs as value_carbs, 
            CAST(f.userrecorded as timestamp) as user_recorded, 
            CAST(f.userrechour as smallint) as user_rec_hour, 
            CAST(f.factoryrecorded as timestamp) as factory_recorded,
            CAST(f.factoryrechour as smallint) as factory_rec_hour,
            cast(((int(unix_timestamp(f.factoryrecorded)/60) - int(unix_timestamp(s.first_sched_factory_reading)/60))/1440) + 1 as int) as wear_day,
            datediff(f.factoryrecorded, s.first_sched_factory_reading) + 1 as calendar_day, 
            useday.use_day as usage_day,
            datediff(f.factoryrecorded, d.first_sched_factory_reading) as ownership_day,

            CASE
                    WHEN DAY(f.factoryrecorded) = DAY(S.FIRST_SCHED_FACTORY_READING) 
                    THEN TRUE
                    WHEN DAY(f.factoryrecorded) = DAY(S.LAST_SCHED_FACTORY_READING) 
                    THEN TRUE
                    ELSE FALSE END 
            as first_last_calendar_day_ind, 
            
            f.reader_uuid, 
            f.country,
            cast(f.date_ as DATE)
            FROM 
                LIVE.FOOD_SILVER f 
            INNER JOIN LIVE.DEVICE_SETTINGS_SILVER d 
            ON f.reader_uuid = d.reader_uuid 
            LEFT OUTER JOIN LIVE.SENSOR_SILVER s 
            ON s.DEVICE_ID = d.DEVICE_ID 
            AND (unix_timestamp(f.factoryrecorded) between unix_timestamp(s.first_sched_factory_reading) and unix_timestamp(s.last_sched_factory_reading))
            LEFT OUTER JOIN LIVE.useday_filtered as useday 
            on (f.reader_uuid = useday.reader_uuid and to_date(f.factoryrecorded, 'yyyy-MM-dd HH:mm:ss') = to_date(useday.factoryrecorded, 'yyyy-MM-dd HH:mm:ss'))
        """)
    results_food_df = results_food_df.withColumnRenamed("date_", "first_processed_date")
    return results_food_df.withColumn("food_id", monotonically_increasing_id())
