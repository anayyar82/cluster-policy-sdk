# Databricks notebook source
from pyspark.sql.functions import col, lit, from_unixtime, unix_timestamp, monotonically_increasing_id, hour, date_format, to_timestamp

import dlt
import bronze_schema
import gold_schema

from variables_orig import *
from data_quality import *

# COMMAND ----------

# MAGIC %md # Bronze Table

# COMMAND ----------

#Creating original table
#@dlt.view()
@dlt.table(temporary=temporary)
@dlt.expect_all_or_drop(ketone_input_rules)
def ketone_input():
    df = (spark.read
            .table(f"`{dmz_catalog}`.`{input_schema}`.`{ketone_table_name[:-1]}`")
            .where(col("uploaddate").between(start_date, end_date))
    )              
    return df.withColumn("date_", lit(snapshot_date))

#@dlt.view()
@dlt.table(temporary=temporary)
def ketone_history():
    query = f"SHOW TABLES IN `{history_catalog}`.`{history_schema}` LIKE '{ketone_table_name[:-1]}'"
    result = spark.sql(query).collect()
    if result:
        df = (spark.read
                .table(f'`{history_catalog}`.`{history_schema}`.`{ketone_table_name[:-1]}`')
        )
    else:
        df = spark.createDataFrame([], schema=bronze_schema.ketone_schema)

    return df    



@dlt.view()
#@dlt.table(temporary=temporary)
def ketone_combined():
    return spark.sql("SELECT * from LIVE.ketone_input UNION SELECT * from LIVE.ketone_history;")


@dlt.view()
#@dlt.table(temporary=temporary)
def ketone_dedup():
    df = spark.sql(f"SELECT * from LIVE.ketone_combined ORDER BY deviceuuid ASC, factoryrecorded ASC, uploadsequence ASC, date_ ASC;")
    return df.dropDuplicates(subset=['deviceuuid', 'factoryrecorded'])


@dlt.view()
#@dlt.table(temporary=temporary)
def ketone_blacklist():
    return spark.sql("select a.* from live.ketone_dedup as a LEFT Join live.bronze_blacklist_account as b on a.accountid = b.accountid where b.accountId is null")


@dlt.view(name=ketone_table_name + "BRONZE")
def ketone_threshold():
    return spark.sql("""SELECT a.* from live.ketone_blacklist as a WHERE a.accountid in (
        SELECT accountid from live.accounts_greater_than_threshold where accountid is not null
    )""")


@dlt.table(
  name=ketone_table_name + "BRONZE_HISTORY",
  comment="combined ketone",
  schema=bronze_schema.ketone_schema,
  temporary=temporary)
def ketone_update_history():
    df = spark.sql(f"select * from live.{ketone_table_name}BRONZE where date_ = '{snapshot_date}' ")
    
    df.write.mode("append").format("delta")\
        .option('nullValue', None)\
        .option("mergeSchema", "false")\
        .saveAsTable(f"`{marshall_catalog}`.`{history_schema}`.`{ketone_table_name[:-1]}`")

    
    return df


# COMMAND ----------

# MAGIC %md # Silver Table

# COMMAND ----------

@dlt.view()
#@dlt.table(temporary=temporary)
def ketone_filtered():
    #Formating Time
    time_df = spark.sql(f"select  if  (instr(right(userrecorded,6), '+') > 0 or instr(right(userrecorded,6), '-') > 0 , substr(userrecorded,0,length(userrecorded)-6) , userrecorded) as userrecorded_modified,*  from LIVE.{ketone_table_name}BRONZE")

    time_df = time_df.drop("userrecorded") \
                    .withColumnRenamed("userrecorded_modified", "userrecorded") \
                    .withColumn('userrecorded', to_timestamp(col('userRecorded'))) \
                    .withColumn('factoryrecorded', to_timestamp(col('factoryrecorded')))
    return time_df

@dlt.table(
  name=ketone_table_name + "SILVER",
  comment="silver ketone",
  temporary=temporary)
def food_silver():
    new_df = spark.sql("SELECT * from LIVE.ketone_filtered;")
    new_df = new_df \
                        .withColumn("factoryrechour", hour(new_df.factoryrecorded)) \
                        .withColumn("userrechour", hour(new_df.userrecorded))


    new_df = new_df.withColumnRenamed("deviceuuid", "reader_uuid") \
                    .withColumnRenamed("devicenationality", "country") \
                    .withColumnRenamed("uploadsequence", "upload_id") \
                    .withColumnRenamed("firmwareversion", "firmware")      
    new_df.orderBy(new_df['reader_uuid'].asc(), new_df['factoryrecorded'].asc())
    
    return new_df


# COMMAND ----------

# MAGIC %md # Gold Table

# COMMAND ----------

@dlt.table(
  name=f"{ketone_table_name}READING_GOLD",
  comment="gold ketone",
  schema=gold_schema.ketone_schema)
def ketone_gold():
    results_ketone_df = spark.sql("""
        SELECT 
            d.device_id,
            CASE
                WHEN unix_timestamp(k.factoryrecorded) BETWEEN unix_timestamp(S.FIRST_SCHED_FACTORY_READING) AND unix_timestamp(S.LAST_SCHED_FACTORY_READING) 
                THEN TRUE
                ELSE FALSE 
                END 
            as active_sensor_ind, 
            s.sensor_id, 
            s.sensor_no,
            CAST(k.upload_id as bigint), 
            k.valuemmol as value_mmol, 
            CAST(k.userrecorded as timestamp) as user_recorded, 
            CAST(k.userrechour as smallint) as user_rec_hour, 
            CAST(k.factoryrecorded as timestamp) as factory_recorded,
            CAST(k.Factoryrechour as smallint) AS factory_rec_hour,
            cast(((int(unix_timestamp(k.factoryrecorded, 'yyyy-MM-dd HH:mm:ss')/60) - int(unix_timestamp(s.first_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')/60))/1440) + 1 as int) as wear_day,

            datediff(k.factoryRecorded, s.first_sched_factory_reading) + 1 as calendar_day, 
            useday.use_day as usage_day,
            datediff(k.factoryrecorded, d.first_sched_factory_reading) as ownership_day,

            CASE
                WHEN DAY(k.factoryRecorded) = DAY(S.FIRST_SCHED_FACTORY_READING) 
                THEN TRUE
                WHEN DAY(k.factoryRecorded) = DAY(S.LAST_SCHED_FACTORY_READING) 
                THEN TRUE
                ELSE FALSE
                END 
            as FIRST_LAST_CALENDAR_DAY_IND, 
            k.reader_uuid, 
            k.country,
            CAST(k.date_ as date)
        FROM 
            LIVE.KETONE_SILVER k 
        INNER JOIN LIVE.DEVICE_SETTINGS_SILVER d 
        ON k.reader_uuid = d.reader_uuid
        LEFT OUTER JOIN LIVE.SENSOR_SILVER s 
        ON s.device_id = d.device_id 
        AND unix_timestamp(k.factoryRecorded) BETWEEN unix_timestamp(s.FIRST_SCHED_FACTORY_READING) AND unix_timestamp(s.LAST_SCHED_FACTORY_READING) 
        LEFT OUTER JOIN LIVE.useday_filtered as useday
        on (k.reader_uuid = useday.reader_uuid and to_date(k.factoryRecorded) = to_date(useday.factoryRecorded))
    """)        

    results_ketone_df = results_ketone_df.withColumn("ketone_id", monotonically_increasing_id())
    return results_ketone_df.withColumnRenamed("date_", "first_processed_date")
