# Databricks notebook source
from pyspark.sql.functions import col, lit, from_unixtime, unix_timestamp, monotonically_increasing_id, hour, date_format, to_timestamp

import dlt
import bronze_schema
import gold_schema

from variables_orig import *
from data_quality import *

# COMMAND ----------

# MAGIC %md # Insulin

# COMMAND ----------

# MAGIC %md ## Bronze Table

# COMMAND ----------

#Creating original table
@dlt.table(temporary=temporary)
@dlt.expect_all_or_drop(insulin_input_rules)
def insulin_input():
    df = (spark.read
            .table(f"`{dmz_catalog}`.`{input_schema}`.`{insulin_table_name[:-1]}`")
            .where(col("uploaddate").between(start_date, end_date))
    )              
    return df.withColumn("date_", lit(snapshot_date))

@dlt.table(temporary=temporary)
def insulin_history():
    query = f"SHOW TABLES IN `{history_catalog}`.`{history_schema}` LIKE '{insulin_table_name[:-1]}'"
    result = spark.sql(query).collect()
    if result:
        return (spark.read
                .table(f'`{history_catalog}`.`{history_schema}`.`{insulin_table_name[:-1]}`')
        )
    else:
          return spark.createDataFrame([], schema=bronze_schema.insulin_schema)    


@dlt.view()
#@dlt.table(temporary=temporary)
def insulin_combined():
    return spark.sql("SELECT * from LIVE.insulin_input UNION SELECT * from LIVE.insulin_history;")

@dlt.view()
#@dlt.table(temporary=temporary)
def insulin_dedup():
    df = spark.sql(f"SELECT * from LIVE.insulin_combined ORDER BY deviceuuid ASC, factoryrecorded ASC, uploadsequence ASC, date_ ASC;")
    return df.dropDuplicates(subset=['deviceuuid', 'factoryrecorded', 'type'])

#@dlt.view()
@dlt.table(temporary=temporary)
def insulin_blacklist():
    return spark.sql("select a.* from live.insulin_dedup as a LEFT Join live.bronze_blacklist_account as b on a.accountid = b.accountid where b.accountId is null")

@dlt.view(name=insulin_table_name + "BRONZE")
def insulin_threshold():
    return spark.sql("""SELECT a.* from live.insulin_blacklist as a WHERE a.accountid in (
        SELECT accountid from live.accounts_greater_than_threshold where accountid is not null
    )""")


@dlt.table(
  name=insulin_table_name + "BRONZE_HISTORY",
  comment="insulin bronze",
  schema=bronze_schema.insulin_schema,
  temporary=temporary)
def insulin_update_history():
    df=spark.sql(f"select * from live.{insulin_table_name}BRONZE where date_ = '{snapshot_date}' ")
        
    df.write.mode("append").format("delta")\
        .option('nullValue', None)\
        .option("mergeSchema", "false")\
        .saveAsTable(f"`{marshall_catalog}`.`{history_schema}`.`{insulin_table_name[:-1]}`")

    
    return df


# COMMAND ----------

# MAGIC %md
# MAGIC ##Silver Table

# COMMAND ----------

@dlt.view()
#@dlt.table(temporary=temporary)
def insulin_format_user_time_stamp():
    format_user_timestamp_df = spark.sql("select  if  (instr(right(userrecorded,6), '+') > 0 or instr(right(userrecorded,6), '-') > 0 , substr(userrecorded,0,length(userrecorded)-6) , userrecorded) as userrecorded_modified,*  from  live.INSULIN_BRONZE")

    format_user_timestamp_df = format_user_timestamp_df.drop("userrecorded") \
                            .withColumnRenamed("userrecorded_modified", "userrecorded") \
                            .withColumn('userrecorded', to_timestamp(col('userRecorded'))) \
                            .withColumn('factoryrecorded', to_timestamp(col('factoryrecorded')))
    return format_user_timestamp_df
    
@dlt.view()
#@dlt.table(temporary=temporary)
def insulin_transformed():
    insulin_input_transformed_df =  spark.sql("select  cast( replace(insulinonboardinunits,',','.')  as float) as formatted_insulinonboardinunits, \
                                                    cast(replace(correctionamountinunits,',','.') as float) as formatted_correctionamountinunits,\
                                                    cast(replace(mealamountinunits,',','.')  as float) as formatted_mealamountinunits, \
                                                    cast(replace(useroverrideinunits,',','.') as float) as formatted_useroverrideinunits,  \
                                                        *  from live.insulin_format_user_time_stamp")
    insulin_input_transformed_df = insulin_input_transformed_df.drop("insulinonboardinunits","correctionamountinunits","mealamountinunits","useroverrideinunits") \
                                                                .withColumnRenamed("formatted_insulinonboardinunits", "insulinonboardinunits") \
                                                                .withColumnRenamed("formatted_correctionamountinunits", "correctionamountinunits") \
                                                                .withColumnRenamed("formatted_mealamountinunits", "mealamountinunits") \
                                                                .withColumnRenamed("formatted_useroverrideinunits", "useroverrideinunits")
    return insulin_input_transformed_df


@dlt.table(
  name=insulin_table_name + "SILVER",
  comment="insulin silver",
  temporary=temporary)
def insulin_enriched():
    new_insulin_df = dlt.read('insulin_transformed')

    new_insulin_df = new_insulin_df.withColumn("factoryrechour", hour(new_insulin_df.factoryrecorded))\
                                    .withColumn ("userrechour", hour(new_insulin_df.userrecorded)) 

    
    new_insulin_df = new_insulin_df.withColumnRenamed("deviceuuid", "reader_uuid")\
                                    .withColumnRenamed("devicenationality", "country")\
                                    .withColumnRenamed("uploadsequence", "upload_id") 
    
    new_insulin_df = new_insulin_df.orderBy(new_insulin_df['reader_uuid'].asc(), new_insulin_df['factoryrecorded'].asc())
    return new_insulin_df

# COMMAND ----------

# MAGIC %md
# MAGIC ##Gold Table

# COMMAND ----------

@dlt.table(name=insulin_table_name + "GOLD",
  comment="gold insulin",
  schema=gold_schema.insulin_schema
)
def insulin_gold():
    results_insulin_df = spark.sql("""
                    SELECT 
                    
                    d.device_id,
                    CASE
                        WHEN unix_timestamp(i.factoryRecorded) BETWEEN unix_timestamp(S.FIRST_SCHED_FACTORY_READING) AND unix_timestamp(S.LAST_SCHED_FACTORY_READING) 
                        THEN TRUE
                        ELSE FALSE 
                        END 
                    as active_sensor_ind,

                    s.sensor_id, 
                    S.sensor_no, 
                    CAST(i.upload_id as bigint), 
                    i.type as insulin_type, 
                    i.units as value_units, 
                    CAST(i.userRecorded as timestamp) as user_recorded, 
                    CAST(i.userRecHour as smallint) as user_rec_hour,
                    CAST(i.factoryrecorded as timestamp) as factory_recorded, 
                    CAST(i.FactoryRecHour as smallint) as factory_rec_hour,
                    cast(((int(unix_timestamp(i.factoryRecorded, 'yyyy-MM-dd HH:mm:ss')/60) - int(unix_timestamp(s.first_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')/60))/1440) + 1 as int) as wear_day,

                    datediff(i.factoryRecorded, s.first_sched_factory_reading) + 1 as calendar_day, 
                    useday.use_day as usage_day,
                    datediff(i.factoryRecorded, d.first_sched_factory_reading) as ownership_day,
                    CASE
                        WHEN DAY(i.factoryRecorded) = DAY(s.FIRST_SCHED_FACTORY_READING) 
                        THEN TRUE
                        WHEN DAY(i.factoryRecorded) = DAY(s.LAST_SCHED_FACTORY_READING) 
                        THEN TRUE
                        ELSE FALSE 
                    END as first_last_calendar_day_ind,
                    i.insulinOnboardInUnits as insulin_on_board_in_units, 
                    i.userOverrideInUnits as user_override_amount_in_units, 
                    i.correctionAmountInUnits as correction_amount_in_units, 
                    i.mealAmountInUnits as meal_amount_in_units, 
                    i.reader_uuid, 
                    i.country,
                    CAST(i.date_ as date)
                FROM live.INSULIN_SILVER i 
                INNER JOIN LIVE.DEVICE_SETTINGS_SILVER d 
                ON i.reader_uuid = d.reader_uuid 
                LEFT OUTER JOIN live.SENSOR_SILVER s 
                ON d.DEVICE_ID = s.DEVICE_ID 
                AND unix_timestamp(i.factoryRecorded) between unix_timestamp(s.first_sched_factory_reading) and unix_timestamp(s.last_sched_factory_reading)
                LEFT OUTER JOIN live.useday useday 
                on (i.reader_uuid = useday.reader_uuid and to_date(i.factoryRecorded) = to_date(useday.factoryRecorded))
    """)

    results_insulin_df = results_insulin_df.withColumn("insulin_id", monotonically_increasing_id())
    results_insulin_df =  results_insulin_df.withColumnRenamed("date_", "first_processed_date")
    return results_insulin_df

# COMMAND ----------

# MAGIC %md
# MAGIC # Insulin Device

# COMMAND ----------

# MAGIC %md ## Bronze Table

# COMMAND ----------


@dlt.table(temporary=temporary)
def insulin_device_input():
    df = (spark.read
            .table(f"`{dmz_catalog}`.`{input_schema}`.`{insulin_device_table_name[:-1]}`")
            .where(col("uploaddate").between(start_date, end_date))
    )              
    return df.withColumn("date_", lit(snapshot_date))


@dlt.table(temporary=temporary)
def insulin_device_history():
    query = f"SHOW TABLES IN `{history_catalog}`.`{history_schema}` LIKE '{insulin_device_table_name[:-1]}'"
    result = spark.sql(query).collect()
    if result:
        return (spark.read
                .table(f'`{history_catalog}`.`{history_schema}`.`{insulin_device_table_name[:-1]}`')
        )
    else:
          return spark.createDataFrame([], schema=bronze_schema.insulin_devices_schema)    


@dlt.view()
#@dlt.table(temporary=temporary)
def insulin_device_combined():
    return spark.sql("SELECT * from LIVE.insulin_device_input UNION SELECT * from LIVE.insulin_device_history;")

@dlt.view()
#@dlt.table(temporary=temporary)
def insulin_device_dedup():
    df = spark.sql(f"SELECT * from LIVE.insulin_device_combined ORDER BY accountid ASC, deviceuuid ASC, uploadsequence ASC, date_ ASC;")
    
    #Removed dedup on uploadsequence
    return df.dropDuplicates(subset=['accountid', 'deviceuuid', 'uploadsequence'])

@dlt.view(name=insulin_device_table_name + "BRONZE")
def insulin_device_blacklist():
    return spark.sql("""SELECT a.* from live.insulin_device_dedup as a WHERE a.accountid in (
        SELECT accountid from live.accounts_greater_than_threshold where accountid is not null
    )""")


@dlt.table(
  name=insulin_device_table_name + "BRONZE_HISTORY",
  comment="insulin device bronze",
  temporary=temporary)
def insulin_device_update_history():
    df=spark.sql(f"select * from live.{insulin_device_table_name}BRONZE where date_ = '{snapshot_date}' ")
        
    df.write.mode("append").format("delta")\
        .option('nullValue', None)\
        .option("mergeSchema", "false")\
        .saveAsTable(f"`{marshall_catalog}`.`{history_schema}`.`{insulin_device_table_name[:-1]}`")

    
    return df



# COMMAND ----------

# MAGIC %md ## Silver Table

# COMMAND ----------

@dlt.table(
  name=insulin_device_table_name + "SILVER",
  comment="insulin device silver",
  temporary=temporary)
def insulin_device_silver():
    return spark.sql("""
        SELECT 
            a.accountid,
            a.deviceuuid, 
            a.devicenationality, 
            a.manufacturer, 
            a.modelname, 
            a.localmodelname, 
            a.serialnumber,
            a.hardwarerevision,
            a.firmwarerevision,
            a.softwarerevision,
            a.blesoftwarerevision, 
            a.bleprotocolrevision, 
            a.devicetime,
            a.defaultinsulintype, 
            a.defaultinsulinbrand,
            a.date_  
        FROM 
            live.INSULIN_DEVICE_BRONZE a  
        INNER JOIN  (
            SELECT 
                serialnumber, 
                MAX(uploadsequence) maxuploadseqence 
            FROM 
                live.INSULIN_DEVICE_BRONZE  
            GROUP BY serialnumber 
        ) b 
        ON a.serialnumber = b.serialnumber 
        AND a.uploadSequence = b.maxUploadSeqence  
        order by  a.serialnumber
    """)

# COMMAND ----------

# MAGIC %md ## Gold Table

# COMMAND ----------

# Insulin Device does not have an overlapping device identifier with normal devices.
# Superior seperates the processing, so no join is needed here. 
@dlt.table(
  name=insulin_device_table_name + "GOLD",
  comment="insulin device gold",
  )
def insulin_device_gold():
    df = spark.sql("""
        SELECT   
            l.accountid as account_id, 
            l.devicenationality as country, 
            l.deviceUUID as reader_uuid ,
            l.manufacturer, 
            l.modelname as model_name, 
            l.localmodelname as local_model_name,
            l.serialnumber as serial_number_hashed, 
            l.hardwarerevision as hardware_revision, 
            l.firmwarerevision as firmware_revision,
            l.softwarerevision as software_revision, 
            l.blesoftwarerevision as ble_software_revision,
            l.bleprotocolrevision as ble_protocol_revision, 
            l.devicetime as device_time , 
            l.defaultinsulintype as default_insulin_type,
            l.defaultinsulinbrand as default_insulin_brand,
            l.date_ as date_ 
            --device.device_id  
        FROM 
            live.INSULIN_DEVICE_SILVER l  
        -- #This join is commented out since there was no device overlap.
        -- #This may come back at some point, so it is staying commented out.
        -- inner join LIVE.DEVICE_SETTINGS_SILVER device
        -- on device.reader_uuid = l.deviceUUID
    """)
            
    df = df.withColumn("insulin_device_id", monotonically_increasing_id())
    return df.withColumnRenamed("date_", "first_processed_date")

# COMMAND ----------

# MAGIC %md
# MAGIC # Insulin Device Data     

# COMMAND ----------

# MAGIC %md ## Bronze Table

# COMMAND ----------

@dlt.table(temporary=temporary)
#@dlt.expect_all_or_drop(insulin_device_data_input_rules)
def insulin_device_data_input():
    df = (spark.read
            .table(f"`{dmz_catalog}`.`{input_schema}`.`{insulin_device_data_table_name[:-1]}`")
            .where(col("uploaddate").between(start_date, end_date))
    )              
    return df.withColumn("date_", lit(snapshot_date))


@dlt.table(temporary=temporary)
def insulin_device_data_history():
    query = f"SHOW TABLES IN `{history_catalog}`.`{history_schema}` LIKE '{insulin_device_data_table_name[:-1]}'"
    result = spark.sql(query).collect()
    if result:
        return (spark.read
                .table(f'`{history_catalog}`.`{history_schema}`.`{insulin_device_data_table_name[:-1]}`')
        )
    else:
          return spark.createDataFrame([], schema=bronze_schema.insulin_devices_data_schema)     

@dlt.view()
#@dlt.table(temporary=temporary)
def insulin_device_data_combined():
    return spark.sql("SELECT * from LIVE.insulin_device_data_input UNION SELECT * from LIVE.insulin_device_data_history;")

@dlt.view()
#@dlt.table(temporary=temporary)
def insulin_device_data_dedup():
    df = spark.sql(f"SELECT * from LIVE.insulin_device_data_combined ORDER BY accountid ASC, deviceuuid ASC, uploadsequence ASC, date_ ASC;")
    
    return df.dropDuplicates(subset=['serialnumber', 'utctimestamp'])

@dlt.view(name=insulin_device_data_table_name + "BRONZE")
def insulin_device_data_blacklist():
    return spark.sql("""SELECT a.* from live.insulin_device_data_dedup as a WHERE a.accountid in (
        SELECT accountid from live.accounts_greater_than_threshold where accountid is not null
    )""")


@dlt.table(
  name=insulin_device_data_table_name + "BRONZE_HISTORY",
  comment="insulin device data bronze",
  temporary=temporary)
def insulin_device_data_update_history():
    df=spark.sql(f"select * from live.{insulin_device_data_table_name}BRONZE where date_ = '{snapshot_date}' ")
        
    df.write.mode("append").format("delta")\
        .option('nullValue', None)\
        .option("mergeSchema", "false")\
        .saveAsTable(f"`{marshall_catalog}`.`{history_schema}`.`{insulin_device_data_table_name[:-1]}`")

    
    return df



# COMMAND ----------

# MAGIC %md ## Silver Table

# COMMAND ----------

@dlt.table(
  name=insulin_device_data_table_name + "SILVER",
  comment="insulin device data silver",
  temporary=temporary)
def insulin_device_data_silver():
    #Formating Time
    time_df = spark.sql(f"""
            select  
                if (
                    instr(right(localtimestamp,6), '+') > 0 or instr(right(localtimestamp,6), '-') > 0 , 
                    substr(localtimestamp,0,length(localtimestamp)-6) , 
                    localtimestamp) 
                as local_timestamp_modified,
                *  
            from 
                LIVE.{insulin_device_data_table_name}BRONZE""")

    time_df = time_df.drop("local_timestamp") \
                    .withColumnRenamed("local_timestamp_modified", "local_timestamp") \
                    .withColumn('local_timestamp', col('local_timestamp'))

    return time_df

# COMMAND ----------

# MAGIC %md ## Gold Table

# COMMAND ----------

@dlt.table(
  name=insulin_device_data_table_name + "GOLD",
  comment="insulin device data gold",
  )
def insulin_device_data_gold():
    df= spark.sql("""
        select 
            i.accountid as account_id, 
            i.deviceuuid as reader_uuid,
            i.devicenationality as country,
            i.relativetimestamp as relative_timestamp,
            i.elapsedseconds as elapsed_seconds, 
            i.serialnumber as serial_number_hashed,
            i.local_timestamp as local_timestamp,
            i.utctimestamp as utc_timestamp, 
            i.value,
            i.insulintype as insulin_type,  
            i.insulinbrand as insulin_name,
            i.primedose as prime_dose, 
            i.primealgo as prime_algo,
            i.editeddose as edit_dose, 
            CAST(i.statusflags as BOOLEAN) as status_flags,
            i.date_ as date_,
            insulin_devices.insulin_device_id
        from 
            LIVE.INSULIN_DEVICE_DATA_SILVER as i 
        inner join LIVE.INSULIN_DEVICE_GOLD as insulin_devices 
        on i.serialnumber = insulin_devices.serial_number_hashed
    """)
    df = df.withColumn("insulin_device_data_id", monotonically_increasing_id())
    return df.withColumnRenamed("date_", "first_processed_date")
