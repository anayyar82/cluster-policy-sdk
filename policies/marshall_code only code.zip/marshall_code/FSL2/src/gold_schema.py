from pyspark.sql.types import LongType, StringType, StructField, StructType, BooleanType, IntegerType, TimestampType, FloatType, DoubleType, DecimalType, DateType

account_devices_schema = StructType([
    StructField("account_id", StringType(), True),
    StructField("reader_uuid", StringType(), True),
    StructField("first_processed_date", DateType(), True)
])

account_blacklist_schema = StructType([\
                        StructField("account_id", StringType(), True),
                        StructField("reason", StringType(), True),
                        StructField("date_added", DateType(), True)
])

alarm_settings_schema = StructType([
    StructField("alarm_setting_id",	LongType(),	False),
    StructField("device_id",	LongType(),	False),
    StructField("reader_uuid",	StringType(),	False),
    StructField("country_code",	StringType(),	False),
    StructField("upload_id",	LongType(),	False),
    StructField("user_recorded",	TimestampType(),	False),
    StructField("user_rec_hour",	IntegerType(),	False),
    StructField("factory_recorded",	TimestampType(),	False),
    StructField("factory_rec_hour",	IntegerType(),	True),
    StructField("configuration_change_source",	IntegerType(),	True),
    StructField("high_glucose_threshold_in_mgdl",	DoubleType(),	False),
    StructField("is_alarm_notification_enabled",	BooleanType(),	True),
    StructField("is_alarm_sound_enabled",	BooleanType(),	True),
    StructField("is_high_glucose_enabled",	BooleanType(),	True),
    StructField("is_low_glucose_enabled",	BooleanType(),	True),
    StructField("is_signal_loss_alarm_enabled",	BooleanType(),	True),
    StructField("low_glucose_threshold_in_mgdl",	DoubleType(),	False),
    StructField("first_processed_date", DateType(), True)
])

device_schema = StructType([
    StructField("device_id", LongType(), False),
    StructField("reader_uuid", StringType(), True),
    StructField("reader_nationality", StringType(), True),
    StructField("first_sched_factory_reading", TimestampType(), True),
    StructField("last_sched_factory_reading", TimestampType(), True),
    StructField("first_sched_user_reading", TimestampType(), True),
    StructField("last_sched_user_reading", TimestampType(), True),
    StructField("sensor_count", LongType(), False),
    StructField("raw_sched_reading_count", LongType(), False),
    StructField("raw_unsched_reading_count", LongType(), False),
    StructField("avg_scan_per_wear_day", DoubleType(), False),
    StructField("abandoned_ind", BooleanType(), False),
    StructField("use_insulin_calc_ind", BooleanType(), False),
    StructField("current_firmware_version", StringType(), False),
    StructField("data_sufficiency_ind", BooleanType(), False),
    StructField("medicare_patient", BooleanType(), True),
    StructField("medicare_start_date", TimestampType(), True),
    StructField("system_type", StringType(), True),
    StructField("reader_type", StringType(), True),
    StructField("first_processed_date", DateType(), True)
])

exercise_schema = StructType([
    StructField("exercise_id",	LongType(),	False),
    StructField("device_id",	LongType(),	False),
    StructField("active_sensor_ind",	BooleanType(),	False),
    StructField("sensor_id",	LongType(),	True),
    StructField("sensor_no",	IntegerType(),	True),
    StructField("upload_id",	LongType(),	False),
    StructField("user_recorded",	TimestampType(),	False),
    StructField("user_rec_hour",	IntegerType(),	False),
    StructField("factory_recorded",	TimestampType(), False),
    StructField("factory_rec_hour",	IntegerType(),	True),
    StructField("wear_day",	IntegerType(),	True),
    StructField("calendar_day",	IntegerType(),	True),
    StructField("usage_day",	IntegerType(),	True),
    StructField("ownership_day",	IntegerType(),	True),
    StructField("first_last_calendar_day_ind",	BooleanType(),	False),
    StructField("reader_uuid",	StringType(),	False),
    StructField("country",	StringType(),	True),
    StructField("first_processed_date", DateType(), True)
])

food_schema = StructType([
    StructField("device_id", LongType(), False),
    StructField("active_sensor_ind", BooleanType(), False),
    StructField("sensor_id", LongType(), True),
    StructField("sensor_no", IntegerType(), True),
    StructField("upload_id", LongType(), True),
    StructField("meal_name", StringType(), True),
    StructField("value_carbs", FloatType(), True),
    StructField("user_recorded", TimestampType(), True),
    StructField("user_rec_hour", IntegerType(), True),
    StructField("factory_recorded", TimestampType(), True),
    StructField("factory_rec_hour", IntegerType(), True),
    StructField("wear_day", IntegerType(), True),
    StructField("calendar_day", IntegerType(), True),
    StructField("usage_day", IntegerType(), True),
    StructField("ownership_day", IntegerType(), True),
    StructField("first_last_calendar_day_ind", BooleanType(), False),
    StructField("reader_uuid", StringType(), True),
    StructField("country", StringType(), True),
    StructField("first_processed_date", DateType(), True),
    StructField("food_id", LongType(), False)
])


insulin_schema = StructType([
    StructField("device_id", LongType(), True),
    StructField("active_sensor_ind", BooleanType(), True),
    StructField("sensor_id", LongType(), True),
    StructField("sensor_no", IntegerType(), True),
    StructField("upload_id", LongType(), True),
    StructField("insulin_type", StringType(), True),
    StructField("value_units", DoubleType(), True),
    StructField("user_recorded", TimestampType(), True),
    StructField("user_rec_hour", IntegerType(), True),
    StructField("factory_recorded", TimestampType(), True),
    StructField("factory_rec_hour", IntegerType(), True),
    StructField("wear_day", IntegerType(), True),
    StructField("calendar_day", IntegerType(), True),
    StructField("usage_day", IntegerType(), True),
    StructField("ownership_day", IntegerType(), True),
    StructField("first_last_calendar_day_ind", BooleanType(), True),
    StructField("insulin_on_board_in_units", FloatType(), True),
    StructField("user_override_amount_in_units", FloatType(), True),
    StructField("correction_amount_in_units", FloatType(), True),
    StructField("meal_amount_in_units", FloatType(), True),
    StructField("reader_uuid", StringType(), True),
    StructField("country", StringType(), True),
    StructField("first_processed_date", DateType(), True),
    StructField("insulin_id", LongType(), False)
])

isf_alarms_schema = StructType([
    StructField("alarm_id",	LongType(),	False),
    StructField("device_id",	LongType(),	False),
    StructField("reader_uuid", StringType(),	False),
    StructField("country_code",	StringType(),	False),
    StructField("upload_id",	LongType(),	False),
    StructField("user_recorded",	TimestampType(),	False),
    StructField("user_rec_hour",	IntegerType(),	False),
    StructField("factory_recorded",	TimestampType(),	False),
    StructField("factory_rec_hour",	IntegerType(),	True),
    StructField("fixed_low_is_cleared",	BooleanType(),	True),
    StructField("fixed_low_is_dismissed",	BooleanType(),	True),
    StructField("fixed_low_is_in_episode",	BooleanType(),	True),
    StructField("fixed_low_is_presented",	BooleanType(),	True),
    StructField("high_is_cleared",	BooleanType(),	True),
    StructField("high_is_dismissed",	BooleanType(),	True),
    StructField("high_is_in_episode",	BooleanType(),	True),
    StructField("high_is_presented",	BooleanType(),	True),
    StructField("low_is_cleared",	BooleanType(),	True),
    StructField("low_is_dismissed",	BooleanType(),	True),
    StructField("low_is_in_episode",	BooleanType(),	True),
    StructField("low_is_presented",	BooleanType(),	True),
    StructField("signal_loss_is_cleared",	BooleanType(),	True),
    StructField("signal_loss_is_in_episode",	BooleanType(),	True),
    StructField("signal_loss_is_presented",	BooleanType(),	True),
    StructField("signal_loss_is_auto_dismissed",	BooleanType(),	True),
    StructField("signal_loss_is_user_dismissed",	BooleanType(),	True),
    StructField("first_processed_date", DateType(), True)
])

ketone_schema = StructType([
    StructField("device_id", LongType(), False),
    StructField("active_sensor_ind", BooleanType(), False),
    StructField("sensor_id", LongType(), True),
    StructField("sensor_no", IntegerType(), True),
    StructField("upload_id", LongType(), True),
    StructField("value_mmol", DoubleType(), True),
    StructField("user_recorded", TimestampType(), True),
    StructField("user_rec_hour", IntegerType(), True),
    StructField("factory_recorded", TimestampType(), True),
    StructField("factory_rec_hour", IntegerType(), True),
    StructField("wear_day", IntegerType(), True),
    StructField("calendar_day", IntegerType(), True),
    StructField("usage_day", IntegerType(), True),
    StructField("ownership_day", IntegerType(), True),
    StructField("first_last_calendar_day_ind", BooleanType(), False),
    StructField("reader_uuid", StringType(), True),
    StructField("country", StringType(), True),
    StructField("first_processed_date", DateType(), True),
    StructField("ketone_id", LongType(), False)
])

medication_schema = StructType([
    StructField("medication_id",	LongType(),	False),
    StructField("device_id",	LongType(),	False),
    StructField("active_sensor_ind",	BooleanType(),	False),
    StructField("sensor_id",	LongType(),	True),
    StructField("sensor_no",	IntegerType(),	True),
    StructField("upload_id",	LongType(),	False),
    StructField("user_recorded",	TimestampType(),	False),
    StructField("user_rec_hour",	IntegerType(),	False),
    StructField("factory_recorded",	TimestampType(),	False),
    StructField("factory_rec_hour",	IntegerType(),	True),
    StructField("wear_day",	IntegerType(),	True),
    StructField("calendar_day",	IntegerType(),	True),
    StructField("usage_day",	IntegerType(),	True),
    StructField("ownership_day",	IntegerType(),	True),
    StructField("first_last_calendar_day_ind",	BooleanType(),	False),
    StructField("reader_uuid",	StringType(),	True),
    StructField("country",	StringType(),	True),
    StructField("first_processed_date", DateType(), True)
])

reads_per_user_hour_schema = StructType([
    StructField("reader_nationality",	StringType(),	True),
    StructField("device_id",	LongType(),	False),
    StructField("sensor_no",	IntegerType(),	False),
    StructField("sensor_id",	LongType(),	False),
    StructField("first_sched_factory_reading",	TimestampType(),	False),
    StructField("first_sched_user_reading",	TimestampType(), False),
    StructField("calendar_days",	LongType(),	True),
    StructField("user_hour",	IntegerType(),	False),
    StructField("sched_reading_count",	LongType(),	True),
    StructField("first_processed_date", DateType(), True),
]) 

ref_country_schema = StructType([
    StructField("code",	StringType(),	False),
    StructField("name",	StringType(),	False),
    StructField("included_in_reporting", BooleanType(), True)
])

ref_insulin_schema = StructType([ 
    StructField("status_flag", IntegerType(), True),
    StructField("st_warning_eol", BooleanType(), True),
    StructField("st_sensor_err", BooleanType(), True),
    StructField("st_interruped_dose", BooleanType(), True),
    StructField("st_recoverable_error", BooleanType(), True)
])

scheduled_schema =  StructType([
    StructField("sched_glucose_id",	LongType(),	False),
    StructField("device_id",	LongType(),	False), 
    StructField("sensor_no",	IntegerType(),	False), 
    StructField("sensor_id",	LongType(),	False), 
    StructField("upload_id",	LongType(),	False), 
    StructField("irregular_reading",	BooleanType(),	False), 
    StructField("value_mgdl",	DoubleType(),	False), 
    StructField("user_recorded",	TimestampType(),	False), 
    StructField("user_rec_hour",	IntegerType(),	False), 
    StructField("factory_recorded",	TimestampType(),	False), 
    StructField("factory_rec_hour",	IntegerType(),	False), 
    StructField("wear_day",	IntegerType(),	False), 
    StructField("calendar_day",	IntegerType(),	False), 
    StructField("first_last_calendar_day_ind",	BooleanType(),	False), 
    StructField("first_after_activation",	BooleanType(),	False), 
    StructField("first_after_time_change",	BooleanType(),	False), 
    StructField("usage_day",	IntegerType(),	True), 
    StructField("ownership_day",	IntegerType(),	True), 
    StructField("read_in_target_flg",	BooleanType(),	True), 
    StructField("read_above_target_flg",	BooleanType(),	True), 
    StructField("read_below_target_flg",	BooleanType(),	True), 
    StructField("irregular_sensor", BooleanType(), True), 
    StructField("reader_uuid", StringType(), True),
    StructField("country", StringType(), True),
    StructField("first_processed_date", DateType(), True)
])

sensor_schema = StructType([
    StructField("sensor_id", LongType(), False),
    StructField("device_id", LongType(), False),
    StructField("reader_uuid", StringType(), True),
    StructField("sensor_no", IntegerType(), False),
    StructField("first_sched_user_reading", TimestampType(), True),
    StructField("last_sched_user_reading", TimestampType(), True),
    StructField("first_sched_factory_reading", TimestampType(), True),
    StructField("last_sched_factory_reading", TimestampType(), True),
    StructField("hours_operational", DecimalType(17,5), True),
    StructField("confirm_status", BooleanType(), False),
    StructField("time_to_next_sensor_start", DecimalType(27,6), True),
    StructField("sched_reading_count", LongType(), False),
    StructField("unsched_reading_count", LongType(), True),
    StructField("avg_scan_per_wear_day", DoubleType(), False),
    StructField("read_in_target", LongType(), True),
    StructField("read_below_target", LongType(), True),
    StructField("read_above_target", LongType(), True),
    StructField("time_in_target", DoubleType(), False),
    StructField("time_below_target", DoubleType(), False),
    StructField("time_above_target", DoubleType(), False),
    StructField("last_confirmed_sensor_ind", BooleanType(), False),
    StructField("irregular_sensor", BooleanType(), False),
    StructField("reader_nationality", StringType(), True),
    StructField("data_sufficiency_ind", BooleanType(), False),
    StructField("sensor_uid", StringType(), True),
    StructField("original_sensor_uid", StringType(), True),
    StructField("product_type", StringType(), True),
    StructField("first_processed_date", DateType(), True)
])

sensor_scan_wearday_schema = StructType([
    StructField("reader_nationality",	StringType(),	True),	
    StructField("sensor_start_year",	IntegerType(),	True),	
    StructField("sensor_start_month",	IntegerType(),	True),	
    StructField("avg_scan_per_wear_day",	DoubleType(),	False),	
    StructField("sensor_count",	LongType(),	False),	
    StructField("distinct_device_count",	LongType(),	False),
    StructField("first_processed_date", DateType(), True)
])

sensor_wear_day_schema = StructType([
    StructField("sensor_id", LongType(), False),
    StructField("wear_day", IntegerType(), True),
    StructField("wd_sched_reading_count", LongType(), False),
    StructField("wd_unsched_reading_count", LongType(), False),
    StructField("time_in_target", DecimalType(30,5), False),
    StructField("time_above_target", DecimalType(30,5),False),
    StructField("time_below_target", DecimalType(30,5),False),
    StructField("percentile_10th", DoubleType(),True),
    StructField("percentile_25th", DoubleType(),True),
    StructField("percentile_50th", DoubleType(),True),
    StructField("percentile_75th", DoubleType(),True),
    StructField("percentile_90th", DoubleType(),True),
    StructField("first_processed_date", DateType(), True),
    StructField("sens_wear_day_id", LongType(), False)
])

skin_temperature_schema = StructType([
    StructField("skin_temperature_id",	LongType(),	False),
    StructField("device_id",	LongType(),	False),
    StructField("reader_uuid",	StringType(),	False),
    StructField("country_code",	StringType(),	False),
    StructField("upload_id",	LongType(),	False),
    StructField("user_recorded",	TimestampType(),	False),
    StructField("user_rec_hour",	IntegerType(),	False),
    StructField("factory_recorded",	TimestampType(),	False),
    StructField("factory_rec_hour",	IntegerType(),	True),
    StructField("skin_temperature_celsius",	DoubleType(),	False),
    StructField("first_processed_date", DateType(), True)
])

strip_schema = StructType([
    StructField("device_id", LongType(), False),
    StructField("active_sensor_ind", BooleanType(), False),
    StructField("sensor_no", IntegerType(), True),
    StructField("sensor_id", LongType(), True),
    StructField("upload_id", LongType(), True),
    StructField("value_mgdl", DoubleType(), True),
    StructField("user_recorded", TimestampType(), True),
    StructField("user_rec_hour", IntegerType(), True),
    StructField("factory_recorded", TimestampType(), True),
    StructField("factory_rec_hour", IntegerType(), True),
    StructField("wear_day", IntegerType(), True),
    StructField("calendar_day", IntegerType(), True),
    StructField("usage_day", IntegerType(), True),
    StructField("ownership_day", IntegerType(), True),
    StructField("first_last_calendar_day_ind", BooleanType(), False),
    StructField("reader_uuid", StringType(), True),
    StructField("country", StringType(), True),
    StructField("first_processed_date", DateType(), True),
    StructField("strip_glucose_id", LongType(), False)
])

timechange_schema = StructType([
    StructField("device_id", LongType(), False),
    StructField("reader_uuid", StringType(), True),
    StructField("country_code", StringType(), True),
    StructField("upload_id", LongType(), True),
    StructField("user_recorded", TimestampType(), True),
    StructField("user_rec_hour", IntegerType(), True),
    StructField("factory_recorded", TimestampType(), True),
    StructField("factory_rec_hour", IntegerType(), True),
    StructField("time_delta", IntegerType(), True),
    StructField("first_processed_date", DateType(), True),
    StructField("time_change_id", LongType(), False),
])

unscheduled_schema = StructType([
    StructField("unsched_glucose_id", LongType(), True),
    StructField("device_id", LongType(), True),
    StructField("sensor_no", IntegerType(), True),
    StructField("sensor_id", LongType(), True),
    StructField("upload_id", LongType(), True),
    StructField("irregular_reading", BooleanType(), True),
    StructField("value_mgdl", DoubleType(), True),
    StructField("user_recorded", TimestampType(), True),
    StructField("user_rec_hour", IntegerType(), True),
    StructField("factory_recorded", TimestampType(), True),
    StructField("factory_rec_hour", IntegerType(), True),
    StructField("wear_day", IntegerType(), True),
    StructField("calendar_day", IntegerType(), True),
    StructField("first_last_calendar_day_ind", BooleanType(), True),
    StructField("last_scan_fac", TimestampType(), True),
    StructField("usage_day", IntegerType(), True),
    StructField("ownership_day", IntegerType(), True),
    StructField("reader_uuid", StringType(), True),
    StructField("country", StringType(), True),
    StructField("ondemand_low_alarm", BooleanType(), True),
    StructField("ondemand_high_alarm", BooleanType(), True),
    StructField("ondemand_projected_low_alarm", BooleanType(), True),
    StructField("ondemand_projected_high_alarm", BooleanType(), True),
    StructField("first_processed_date", DateType(), True)
])

upload_schema = StructType([
    StructField("upload_id", LongType(), False),
    StructField("upload_date", DateType(), True),
    StructField("country", StringType(), False),
    StructField("reader_uuid", StringType(), False),
    StructField("firmware_version", StringType(), True),
    StructField("account_id", StringType(), True),
    StructField("first_processed_date", DateType(), False)
])
