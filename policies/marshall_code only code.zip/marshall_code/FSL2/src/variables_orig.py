from databricks.sdk.runtime import spark

#False means it stays, True means it disappears
temporary = not spark.conf.get("temporary_tables").lower() == "false"

dmz_catalog = spark.conf.get("input_catalog")
input_schema = spark.conf.get("input_schema")
marshall_catalog = spark.conf.get("output_catalog")
history_schema = spark.conf.get("history_schema")
misc_schema = spark.conf.get("misc_schema")
snapshot_date = spark.conf.get("to_date")
start_date = spark.conf.get("from_date")
end_date = spark.conf.get("to_date")

#Optional parameters
try:
    target_schema = spark.conf.get("target_schema")
except Exception:
    target_schema = None

try:
    history_catalog = spark.conf.get("history_catalog")
except Exception:
    history_catalog = spark.conf.get("output_catalog")

#base table names
bl_accounts_table_name = 'account_blacklist_'
bl_devices_table_name= ' blacklist_devices_'
scheduled_table_name = 'scheduled_glucose_reading_'
ketone_table_name = 'ketone_'
device_table_name = 'device_settings_'
unscheduled_table_name = 'unscheduled_glucose_reading_'
food_table_name = 'food_'
generic_table_name = 'generic_'
strip_table_name = 'strip_'
sensor_table_name = 'sensor_'
insulin_table_name = 'insulin_'
insulin_device_table_name = 'insulin_device_'
insulin_device_data_table_name = 'insulin_device_data_'
account_devices_table_name = 'account_device_'