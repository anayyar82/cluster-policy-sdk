# Databricks notebook source
from pyspark.sql.types import BooleanType
from pyspark.sql.functions import monotonically_increasing_id
from pyspark.sql.utils import AnalysisException

import dlt
import bronze_schema
import gold_schema

from variables_orig import *
from data_quality import *


# COMMAND ----------

# MAGIC %md
# MAGIC ###Survey
# MAGIC

# COMMAND ----------

surveyinput = spark.conf.get("survey").lower()
survey = eval("surveyinput == 'true'")
temporary_survey = not survey

@dlt.table(name = 'SURVEY_QUESTIONS_GOLD' if not temporary_survey else 'SURVEY_QUESTIONS_EMPTY',
    temporary = temporary_survey)
def load_survey_questions():
    if survey:
        return spark.read.table(f"`{marshall_catalog}`.`{misc_schema}`.`survey-questions`")
    else:
        return spark.createDataFrame([], bronze_schema.survey_questions)

@dlt.table(name = 'SURVEY_RESPONSES_GOLD' if not temporary_survey else 'SURVEY_RESPONSES_EMPTY',
           temporary = temporary_survey)
def load_survey_responses():
    if survey:
        return spark.read.table(f"`{marshall_catalog}`.`{misc_schema}`.`survey-responses`")
    else:
        return spark.createDataFrame([], bronze_schema.survey_responses)

    

# COMMAND ----------

# MAGIC %md
# MAGIC ###Medication

# COMMAND ----------


@dlt.table(name="MEDICATION_GOLD",
  comment="gold medication",
  schema=gold_schema.medication_schema)
def medication():
    m =  spark.sql("""
            select 
                device.device_id,
                
                CASE
                    WHEN unix_timestamp(extended.factoryRecorded, 'yyyy-MM-dd HH:mm:ss') BETWEEN unix_timestamp(sensor.FIRST_SCHED_FACTORY_READING, 'yyyy-MM-dd HH:mm:ss') AND unix_timestamp(sensor.LAST_SCHED_FACTORY_READING, 'yyyy-MM-dd HH:mm:ss') 
                    THEN TRUE
                    ELSE FALSE
                END as active_sensor_ind,

                sensor.sensor_id, 
                sensor.sensor_no,
                CAST(extended.upload_id as bigint), 
                extended.userRecorded as user_recorded, 
                CAST(extended.userRecHour as smallint) as user_rec_hour,
                extended.factoryrecorded as factory_recorded, 
                CAST(extended.factoryRecHour as smallint) as factory_rec_hour,

                cast(((int(unix_timestamp(extended.factoryRecorded, 'yyyy-MM-dd HH:mm:ss')/60) - int(unix_timestamp(sensor.first_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')/60))/1440) + 1 as int) as wear_day,
                datediff(to_date(extended.factoryRecorded, 'yyyy-MM-dd HH:mm:ss'), to_date(sensor.first_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')) + 1 as calendar_day, 
                u.use_day as usage_day,
                datediff(to_date(extended.factoryRecorded, 'yyyy-MM-dd HH:mm:ss'), to_date(device.first_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')) as ownership_day,
                
                case 
                    when day(to_date(extended.factoryRecorded, 'yyyy-MM-dd HH:mm:ss')) = day(to_date(sensor.first_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')) 
                    then TRUE 
                    when day(to_date(extended.factoryRecorded, 'yyyy-MM-dd HH:mm:ss')) = day(to_date(sensor.last_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')) 
                    then TRUE 
                    else FALSE
                end as first_last_calendar_day_ind,

                extended.reader_uuid,
                extended.country,
                cast(device.date_ as date)
            from 
                live.GENERIC_SILVER extended 
            inner join live.DEVICE_SETTINGS_SILVER device 
            on device.reader_uuid = extended.reader_uuid 
            left outer join live.SENSOR_SILVER sensor 
            on sensor.device_id = device.device_id 
            and 
                unix_timestamp(extended.factoryRecorded, 'yyyy-MM-dd HH:mm:ss') between 
                    unix_timestamp(sensor.first_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss') 
                    and 
                    unix_timestamp(sensor.last_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')
            left outer join live.useday_filtered u 
            on (extended.reader_uuid = u.reader_uuid and to_date(extended.factoryRecorded, 'yyyy-MM-dd HH:mm:ss') = to_date(u.factoryRecorded, 'yyyy-MM-dd HH:mm:ss'))
            where extended.type = 'medication'
    """ )

    medication_with_id = m.withColumn("medication_id", monotonically_increasing_id())

    return medication_with_id.withColumnRenamed("date_", "first_processed_date")

# COMMAND ----------

# MAGIC %md
# MAGIC ###Alarm Settings

# COMMAND ----------

@dlt.table(name="ALARM_SETTING_GOLD",
  comment="gold alarm_settings",
  schema=gold_schema.alarm_settings_schema)
def alarm_settings():
    a = spark.sql("""
            select 
                device.device_id, 
                generic_enriched.reader_uuid, 
                generic_enriched.country as country_code,
                CAST(generic_enriched.upload_id as bigint),
                CAST(generic_enriched.userrecorded as timestamp) as user_recorded, 
                CAST(generic_enriched.userrecHour as smallint) as user_rec_hour,
                CAST(generic_enriched.factoryrecorded as timestamp) as factory_recorded, 
                CAST(generic_enriched.factoryrecHour as smallint) as factory_rec_hour,
                configurationChangeSource as configuration_change_source, 
                round(nvl(highglucosethresholdinmgdl,0),0) as high_glucose_threshold_in_mgdl, 
                cast(isalarmnotificationenabled as boolean) as is_alarm_notification_enabled,
                cast(isalarmsoundenabled as boolean) as is_alarm_sound_enabled, 
                cast(ishighglucoseenabled as boolean) as is_high_glucose_enabled,
                cast(islowglucoseenabled as boolean) as is_low_glucose_enabled, 
                cast(issignallossalarmenabled as boolean) as  is_signal_loss_alarm_enabled,
                round(nvl(lowglucosethresholdinmgdl,0),0)  as low_glucose_threshold_in_mgdl,
                CAST(device.date_ as date)
            from 
                live.GENERIC_SILVER generic_enriched
            inner join live.DEVICE_SETTINGS_SILVER device 
            on device.reader_uuid =  generic_enriched.reader_uuid 
            and type ='alarmSetting'
        """)
    
    alarm_settings = a.withColumn("alarm_setting_id", monotonically_increasing_id())
    return alarm_settings.withColumnRenamed("date_", "first_processed_date")

# COMMAND ----------

# MAGIC %md
# MAGIC ###Skin Temperature

# COMMAND ----------


@dlt.table(name="SKIN_TEMPERATURE_GOLD",
  comment="gold skin_temperature",
  schema=gold_schema.skin_temperature_schema)
def skin_temperature():
    skin_temperature = spark.sql("""
        select 
            device.device_id, 
            generic_enriched.reader_uuid, 
            generic_enriched.country as country_code,
            CAST(generic_enriched.upload_id as bigint),  
            CAST(generic_enriched.userRecorded as timestamp) as user_recorded,
            CAST(generic_enriched.userRecHour as smallint) as user_rec_hour,   
            CAST(generic_enriched.factoryrecorded as timestamp) as factory_recorded,
            CAST(generic_enriched.factoryRecHour as smallint) as factory_rec_hour, 
            (value * .1) as skin_temperature_celsius,
            CAST(device.date_ as date)
        from 
            live.GENERIC_SILVER generic_enriched  
        inner join live.DEVICE_SETTINGS_SILVER device 
        on device.reader_uuid = generic_enriched.reader_uuid
        and type ='temperature'
    """)

    skin_temperature_with_id = skin_temperature.withColumn("skin_temperature_id", monotonically_increasing_id())
    return skin_temperature_with_id.withColumnRenamed("date_", "first_processed_date")

# COMMAND ----------

# MAGIC %md
# MAGIC ###ISF Glucose Alarm

# COMMAND ----------

  @dlt.table(name="ISF_GLUCOSE_ALARM_GOLD",
  comment="gold isf_alarms",
  schema=gold_schema.isf_alarms_schema)
def isf_alarmsettings():
    isf_alarmsettings = spark.sql("""
            select 
                device.device_id, 
                generic_enriched.reader_uuid,
                generic_enriched.country as country_code,
                CAST(generic_enriched.upload_id as bigint),
                CAST(generic_enriched.userRecorded as timestamp) as user_recorded, 
                CAST(generic_enriched.userRecHour as smallint) as user_rec_hour,
                CAST(generic_enriched.factoryrecorded as timestamp) as factory_recorded, 
                CAST(generic_enriched.factoryRecHour as smallint) as factory_rec_hour,
                CAST(fixedLowGlucoseAlarmIsInEpisode AS BOOLEAN) as fixed_low_is_in_episode,
                CAST(fixedLowGlucoseAlarmIsCleared AS BOOLEAN) as fixed_low_is_cleared,
                CAST(fixedLowGlucoseAlarmIsDismissed AS BOOLEAN) as fixed_low_is_dismissed,
                CAST(fixedLowGlucoseAlarmIsPresented AS BOOLEAN) as fixed_low_is_presented,
                CAST(lowGlucoseAlarmIsInEpisode AS BOOLEAN) as low_is_in_episode,
                CAST(lowGlucoseAlarmIsCleared AS BOOLEAN) as low_is_cleared,
                CAST(lowGlucoseAlarmIsDismissed AS BOOLEAN) as low_is_dismissed,
                CAST(lowGlucoseAlarmIsPresented AS BOOLEAN) as low_is_presented,
                CAST(highGlucoseAlarmIsInEpisode AS BOOLEAN) as high_is_in_episode,   
                CAST(highGlucoseAlarmIsCleared AS BOOLEAN) as high_is_cleared,
                CAST(highGlucoseAlarmIsDismissed AS BOOLEAN) as high_is_dismissed,
                CAST(highGlucoseAlarmIsPresented AS BOOLEAN) as high_is_presented,
                CAST(signalLossAlarmIsInEpisode AS BOOLEAN) as signal_loss_is_in_episode,
                CAST(signalLossAlarmIsCleared AS BOOLEAN) as signal_loss_is_cleared,
                CAST(signalLossAlarmIsPresented AS BOOLEAN) as signal_loss_is_presented,
                CAST(signalLossAlarmIsAutoDismissed AS BOOLEAN) as signal_loss_is_auto_dismissed,
                CAST(signalLossAlarmIsUserDismissed AS BOOLEAN) as signal_loss_is_user_dismissed,
                CAST(device.date_ as date)
            from 
                live.GENERIC_SILVER generic_enriched 
            inner join live.DEVICE_SETTINGS_SILVER device 
            on device.reader_uuid = generic_enriched.reader_uuid 
            and type ='isfGlucoseAlarm'
    """)

    isf_alarmsettings = isf_alarmsettings.withColumn("alarm_id", monotonically_increasing_id())
    return isf_alarmsettings.withColumnRenamed("date_", "first_processed_date")

# COMMAND ----------

# MAGIC %md
# MAGIC ###Time Change
# MAGIC

# COMMAND ----------

@dlt.table(name="TIME_CHANGE_GOLD",
  comment="gold timechange",
  schema=gold_schema.timechange_schema)
def time_change():
    time_change = spark.sql("""
        select 
            device.device_id, 
            generic_enriched.reader_uuid, 
            generic_enriched.country as country_code,
            CAST(generic_enriched.upload_id as bigint),  
            CAST(generic_enriched.userRecorded as timestamp) as user_recorded,
            CAST(generic_enriched.userRecHour as smallint) as user_rec_hour,
            CAST(generic_enriched.factoryrecorded as timestamp) as factory_recorded, 
            CAST(generic_enriched.factoryRecHour as smallint) as factory_rec_hour,
            cast(timeDelta as integer) as time_delta,
            CAST(device.date_ as date)
        from live.GENERIC_SILVER generic_enriched 
        inner join live.DEVICE_SETTINGS_SILVER device 
        on device.reader_uuid = generic_enriched.reader_uuid 
        and type ='timechange'
    """)
    
    time_change = time_change.withColumn("time_change_id", monotonically_increasing_id())
    return time_change.withColumnRenamed("date_", "first_processed_date")

# COMMAND ----------

# MAGIC %md
# MAGIC ###Exercise

# COMMAND ----------

@dlt.table(name="EXERCISE_GOLD",
  comment="gold exercise",
  schema=gold_schema.exercise_schema)
def exercise():
    exercise = spark.sql("""
        select 
            device.device_id,

            CASE
                WHEN unix_timestamp(extended.factoryRecorded, 'yyyy-MM-dd HH:mm:ss') BETWEEN 
                    unix_timestamp(sensor.FIRST_SCHED_FACTORY_READING, 'yyyy-MM-dd HH:mm:ss') 
                    AND 
                    unix_timestamp(sensor.LAST_SCHED_FACTORY_READING, 'yyyy-MM-dd HH:mm:ss') 
                THEN TRUE
                ELSE FALSE
            END as ACTIVE_SENSOR_IND,
            sensor.sensor_id, 
            sensor.sensor_no, 
            CAST(extended.upload_id as bigint),
            CAST(extended.userRecorded as timestamp) as user_recorded, 
            CAST(extended.userRecHour as smallint) as user_rec_hour, 
            CAST(extended.factoryrecorded as timestamp) as factory_recorded, 
            CAST(extended.factoryRecHour as smallint) as factory_rec_hour,

            cast(((int(unix_timestamp(extended.factoryRecorded, 'yyyy-MM-dd HH:mm:ss')/60) - int(unix_timestamp(sensor.first_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')/60))/1440) + 1 as int) as wear_day,

            datediff(to_date(extended.factoryRecorded, 'yyyy-MM-dd HH:mm:ss'), to_date(sensor.first_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')) + 1 as calendar_day, 
            useday.use_day as usage_day,
            datediff(to_date(extended.factoryRecorded, 'yyyy-MM-dd HH:mm:ss'), to_date(device.first_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')) as ownership_day,
            case
                when day(to_date(extended.factoryRecorded, 'yyyy-MM-dd HH:mm:ss')) = day(to_date(sensor.first_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')) 
                then TRUE
                when day(to_date(extended.factoryRecorded, 'yyyy-MM-dd HH:mm:ss')) = day(to_date(sensor.last_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')) 
                then TRUE 
                else FALSE 
            end as first_last_calendar_day_ind,
            extended.reader_uuid,
            extended.country,
            CAST(device.date_ as date)
        from 
            live.GENERIC_SILVER extended 
        inner join live.DEVICE_SETTINGS_SILVER device 
        on device.reader_uuid = extended.reader_uuid 
        left outer join live.SENSOR_SILVER sensor
        on sensor.device_id = device.device_id 
        and unix_timestamp(extended.factoryRecorded, 'yyyy-MM-dd HH:mm:ss') between 
            unix_timestamp(sensor.first_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss') 
            and  unix_timestamp(sensor.last_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')
        left outer join live.useday_filtered useday 
        on (extended.reader_uuid = useday.reader_uuid and to_date(extended.factoryRecorded, 'yyyy-MM-dd HH:mm:ss') = to_date(useday.factoryRecorded, 'yyyy-MM-dd HH:mm:ss'))
        where extended.type = 'exercise'
    """)

    exercise = exercise.withColumn("exercise_id", monotonically_increasing_id())
    return exercise.withColumnRenamed("date_", "first_processed_date")

# COMMAND ----------

# MAGIC %md
# MAGIC ###Ref Country

# COMMAND ----------

@dlt.table(
  name="REF_COUNTRY_GOLD",
  comment="load ref country",
  schema=gold_schema.ref_country_schema)
def ref_country():
    return spark.read.table(f"`{marshall_catalog}`.`{misc_schema}`.`ref-country`")
    
    


# COMMAND ----------

# MAGIC %md
# MAGIC ###Ref Insulin

# COMMAND ----------

@dlt.table(name="ref_insulin_status_flag_novo_gold")
def ref_insulin():
    return spark.read.table(f"`{marshall_catalog}`.`{misc_schema}`.`ref_insulin_status_flag_novo`")



# COMMAND ----------

# MAGIC %md
# MAGIC ### Sensor Wear Day

# COMMAND ----------

@dlt.table(name="SENSOR_WEAR_DAY_GOLD",
  comment="gold sensor_wear_day",
  schema=gold_schema.sensor_wear_day_schema)
def sensor_wear_day():
    sen = spark.sql(f"""
        SELECT
            sens_day.sensor_id,
            sens_day.wear_day wear_day,
            sens_day.wd_sched_reading_count wd_sched_reading_count,
            COALESCE(ug.unsched_reads, 0) wd_unsched_reading_count,
            sens_day.time_in_target,
            sens_day.time_above_target,
            sens_day.time_below_target,
            percentile.ptc10 percentile_10th,
            percentile.ptc25 percentile_25th,
            percentile.ptc50 percentile_50th,
            percentile.ptc75 percentile_75th,
            percentile.ptc90 percentile_90th,
            CAST(sens_day.date_ as date)
        FROM (
            select 
                sensor_id, 
                wear_day, 
                sched_reads as wd_sched_reading_count,
                COALESCE(ROUND(read_in_target/(sched_reads * 1.0) ,5)*24, 0) as time_in_target,
                COALESCE(ROUND(read_above_target/(sched_reads * 1.0) ,5)*24, 0) as time_above_target,
                COALESCE(ROUND(read_below_target/(sched_reads * 1.0) ,5)*24, 0) as time_below_target,
                first_processed_date as date_
            from (
                select 
                    sensor_id, 
                    wear_day,
                    first_processed_date,
                    count(case when CAST(read_in_target_flg AS BOOLEAN) then 1 end)as read_in_target,
                    count(case when CAST(read_below_target_flg AS BOOLEAN) then 1 end) as read_below_target,
                    count(case when CAST(read_above_target_flg AS BOOLEAN) then 1 end) as read_above_target,
                    count(*) as sched_reads
                from 
                    LIVE.{scheduled_table_name + "GOLD"}
                group by sensor_id, wear_day, first_processed_date
            )
        ) sens_day
        JOIN (
            SELECT DISTINCT
                sg.sensor_id,
                sg.wear_day,
                PERCENTILE_CONT (0.1) WITHIN GROUP (ORDER BY sg.value_mgdl ASC) OVER (PARTITION BY sg.sensor_id, sg.wear_day) ptc10,
                PERCENTILE_CONT (0.25) WITHIN GROUP ( ORDER BY sg.value_mgdl ASC) OVER (PARTITION BY sg.sensor_id, sg.wear_day) ptc25,
                PERCENTILE_CONT (0.5) WITHIN GROUP ( ORDER BY sg.value_mgdl ASC) OVER (PARTITION BY sg.sensor_id, sg.wear_day) ptc50,
                PERCENTILE_CONT (0.75) WITHIN GROUP ( ORDER BY sg.value_mgdl ASC) OVER (PARTITION BY sg.sensor_id, sg.wear_day) ptc75,
                PERCENTILE_CONT (0.9) WITHIN GROUP ( ORDER BY sg.value_mgdl ASC) OVER (PARTITION BY sg.sensor_id, sg.wear_day) ptc90
            FROM
                LIVE.{scheduled_table_name + "GOLD"} sg) percentile
        ON  percentile.sensor_id = sens_day.sensor_id 
        AND percentile.wear_day = sens_day.wear_day
        LEFT OUTER JOIN (
                select 
                    sensor_id, 
                    wear_day, 
                    count(*) as unsched_reads 
                from 
                    LIVE.UNSCHEDULED_GLUCOSE_READING_GOLD
                group by sensor_id, wear_day
        ) ug
        ON ug.sensor_id = sens_day.sensor_id 
        AND ug.wear_day = sens_day.wear_day
        """)
    
    sen = sen.withColumn("sens_wear_day_id", monotonically_increasing_id())
    return sen.withColumnRenamed("date_", "first_processed_date")


# COMMAND ----------

# MAGIC %md
# MAGIC ###Distribution Sensor Scan Day Wear Day Frequency
# MAGIC

# COMMAND ----------

@dlt.table(name="DISTRIBUTION_BY_WEARDAY_SCAN_FREQUENCY_GOLD",
  comment="sensor scan wearday",
  schema=gold_schema.sensor_scan_wearday_schema)
def distribution_by_scan_wearday_frequency():
    return spark.sql("""
        SELECT  
            d.READER_NATIONALITY, 
            a.SENSOR_START_YEAR,
            a.SENSOR_START_MONTH, 
            a.AVG_SCAN_PER_WEAR_DAY,
            COUNT(s.sensor_id) SENSOR_COUNT, 
            COUNT(DISTINCT(d.DEVICE_ID)) DISTINCT_DEVICE_COUNT,
            d.first_processed_date
        FROM (
            SELECT
                year(s.FIRST_SCHED_FACTORY_READING) SENSOR_START_YEAR,
                month(s.FIRST_SCHED_FACTORY_READING) SENSOR_START_MONTH,
                AVG_SCAN_PER_WEAR_DAY
            FROM LIVE.SENSOR_GOLD s
            UNION
            SELECT
                year(d.FIRST_SCHED_FACTORY_READING) SENSOR_START_YEAR,
                month(d.FIRST_SCHED_FACTORY_READING) SENSOR_START_MONTH,
                AVG_SCAN_PER_WEAR_DAY
            FROM LIVE.DEVICE_GOLD d
        ) a 
        JOIN LIVE.SENSOR_GOLD s 
        ON s.AVG_SCAN_PER_WEAR_DAY = a.AVG_SCAN_PER_WEAR_DAY
        AND month(s.FIRST_SCHED_FACTORY_READING) = a.SENSOR_START_MONTH
        AND year (s.FIRST_SCHED_FACTORY_READING) = a.SENSOR_START_YEAR
        JOIN LIVE.DEVICE_GOLD d ON d.DEVICE_ID = s.DEVICE_ID
        WHERE s.irregular_sensor = 0
        GROUP BY d.READER_NATIONALITY, a.SENSOR_START_YEAR, a.SENSOR_START_MONTH, a.AVG_SCAN_PER_WEAR_DAY, d.first_processed_date
    """)
    

# COMMAND ----------

# MAGIC %md
# MAGIC # Views

# COMMAND ----------

# MAGIC %md
# MAGIC ###V_REPORT_DISTRIBUTION_BY_WEARDAY_SCAN_FREQUENCY

# COMMAND ----------

@dlt.table(name="V_REPORT_DISTRIBUTION_BY_WEARDAY_SCAN_FREQUENCY_GOLD")
def VIEW_REPORT_DISTRIBUTION_BY_WEARDAY_SCAN_FREQUENCY():
    return spark.sql("""  
        SELECT
            c.CODE reader_nationality,
            d.sensor_start_year,
            d.sensor_start_month,
            d.avg_scan_per_wear_day,
            d.sensor_count,
            d.distinct_device_count
        FROM
            LIVE.DISTRIBUTION_BY_WEARDAY_SCAN_FREQUENCY_GOLD D
            JOIN LIVE.REF_COUNTRY_GOLD C ON C.CODE = D.READER_NATIONALITY;
    """)
  

# COMMAND ----------

# MAGIC %md
# MAGIC ###V_REPORT_GLYCEMIC_PROFILE_BY_SCAN_FREQUENCY

# COMMAND ----------


@dlt.table(name="V_REPORT_GLYCEMIC_PROFILE_BY_SCAN_FREQUENCY_GOLD")
def VIEW_REPORT_GLYCEMIC_PROFILE_BY_SCAN_FREQUENCY():
    return spark.sql("""
         SELECT
            sens.device_id,
            sens.sensor_id,
            sens.sensor_no,
            c.CODE reader_nationality,
            sens.first_sched_user_reading,
            sens.first_sched_factory_reading,
            sens.hours_operational,
            sens.time_to_next_sensor_start,
            sens.avg_scan_per_wear_day,
            sens.sched_reading_count,
            sens.read_in_target,
            sens.read_below_target,
            sens.read_above_target,
            sens.time_in_target,
            sens.time_below_target,
            sens.time_above_target
        FROM
            LIVE.SENSOR_GOLD SENS
            JOIN LIVE.DEVICE_GOLD D ON D.DEVICE_ID = SENS.DEVICE_ID
            JOIN LIVE.REF_COUNTRY_GOLD C ON C.CODE = D.READER_NATIONALITY;           
    """)

# COMMAND ----------

# MAGIC %md
# MAGIC ###V_REPORT_SENSOR_PROFILE

# COMMAND ----------

@dlt.table(name="V_REPORT_SENSOR_PROFILES_GOLD")
def VIEW_REPORT_SENSOR_PROFILE():
    return spark.sql("""
        SELECT
            d.device_id,
            s.sensor_no,
            c.CODE as reader_nationality,
            s.hours_operational,
            s.first_sched_factory_reading,
            s.confirm_status,
            s.time_to_next_sensor_start,
            swd.wear_day,
            swd.percentile_10th,
            swd.percentile_25th,
            swd.percentile_50th,
            swd.percentile_75th,
            swd.percentile_90th,
            swd.wd_sched_reading_count,
            swd.wd_unsched_reading_count,
            swd.time_in_target,
            swd.time_above_target,
            swd.time_below_target
        FROM
            LIVE.DEVICE_GOLD D
            JOIN LIVE.SENSOR_GOLD S ON D.DEVICE_ID = S.DEVICE_ID
            JOIN LIVE.SENSOR_WEAR_DAY_GOLD SWD ON S.SENSOR_ID = SWD.SENSOR_ID
            JOIN LIVE.REF_COUNTRY_GOLD C ON D.READER_NATIONALITY = C.CODE;
    """)

# COMMAND ----------

# MAGIC %md
# MAGIC ###V_REPORT_SENSOR_WEAR_DURATION

# COMMAND ----------

@dlt.table(name="V_REPORT_SENSOR_PROFILE_GOLD")
def VIEW_REPORT_SENSOR_PROFILE():
    return spark.sql("""
        SELECT
            c.CODE reader_nationality,
            round(hours_operational/24, 0)::smallint wear_day,
            count (*) no_of_sensors
        FROM
            LIVE.SENSOR_GOLD S
        JOIN LIVE.DEVICE_GOLD D ON S.DEVICE_ID = D.DEVICE_ID
        JOIN LIVE.REF_COUNTRY_GOLD C  ON C.CODE = D.READER_NATIONALITY
        GROUP BY
            C.CODE,
            ROUND(HOURS_OPERATIONAL/24, 0);           
    """)

# COMMAND ----------

# MAGIC %md
# MAGIC ###V_REPORT_UPLOAD_STATISTICS_FOR_ENGINEERING

# COMMAND ----------

@dlt.table(name="V_REPORT_UPLOAD_STATISTICS_FOR_ENGINEERING_GOLD")
def VIEW_REPORT_UPLOAD_STATISTICS_FOR_ENGINEERING():
    return spark.sql("""
        SELECT
            c.CODE upload_country,
            upload_year,
            upload_month,
            upload_total,
            upload_new_data,
            distinct_readers
        FROM
            LIVE.UPLOAD_STATISTICS_GOLD U
            JOIN LIVE.REF_COUNTRY_GOLD C  ON C.CODE = U.UPLOAD_COUNTRY;
    """)


# COMMAND ----------

# MAGIC %md
# MAGIC ###V_EA1C

# COMMAND ----------

@dlt.table(name="V_EA1C_GOLD")
def VIEW_EA1C():
    return spark.sql("""
        SELECT
            s.device_id,
            s.sensor_id,
            cast((avg(sgr.value_mgdl)+46.7)/28.7 as float) as ea1c
        FROM LIVE.SCHEDULED_GLUCOSE_READING_GOLD SGR 
        INNER JOIN LIVE.SENSOR_GOLD S
        ON S.sensor_id = SGR.sensor_id WHERE S.DATA_SUFFICIENCY_IND = 1
        GROUP BY S.device_id, S.sensor_id;
    """)
