# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
source_catalog = dbutils.widgets.get("source_catalog")
target_catalog = dbutils.widgets.get("target_catalog")
source_schema = dbutils.widgets.get("source_schema")
target_schema = dbutils.widgets.get("target_schema")
target_group = dbutils.widgets.get("target_group")
overwrite = bool(dbutils.widgets.get("overwrite"))
gold_only = bool(dbutils.widgets.get("gold_only"))

# ==This is for manual runs==
# source_catalog = 'qa-adc-marshallrwe-catalog-us-west-2'
# target_catalog = 'qa-adc-marshallrwe-catalog-us-west-2'
# source_schema = 'rwe-dummy-fsl3'
# target_schema = 'marshall_phase2_aqc'
# target_group = 'Databricks-RWE-Data-Scientist'
# overwrite = True

# COMMAND ----------

tab = spark.sql(f"SHOW TABLES FROM `{source_catalog}`.`{source_schema}`")

tables = [row.tableName for row in tab.select('tableName').collect()]

if overwrite:
    delet = spark.sql(f"DROP SCHEMA IF EXISTS `{target_catalog}`.`{target_schema}` CASCADE; ")

spark.sql(f"CREATE SCHEMA IF NOT EXISTS `{target_catalog}`.`{target_schema}`")

newtables = spark.sql(f"SHOW TABLES FROM `{target_catalog}`.`{target_schema}`")
new = [row.tableName for row in newtables.select('tableName').collect()]

for table in tables:
    if gold_only:
        if "_gold" not in table:
            continue
        else:
            new_table = table.replace("_gold", "")
    else:
        new_table = table
    
    print("Cloning ", new_table)

    if new_table in new:
        spark.sql(f"""
                  INSERT INTO `{target_catalog}`.`{target_schema}`.`{new_table}`
                  SELECT * FROM `{source_catalog}`.`{source_schema}`.`{new_table}`          
                  """)
    else:
        spark.sql(f"""
                CREATE TABLE IF NOT EXISTS `{target_catalog}`.`{target_schema}`.`{new_table}`
                AS (SELECT * FROM `{source_catalog}`.`{source_schema}`.`{table}`)
                """)         

# COMMAND ----------

spark.sql(f"GRANT USAGE ON SCHEMA `{target_catalog}`.`{target_schema}` TO  `{target_group}`")
spark.sql(f"GRANT EXECUTE ON SCHEMA `{target_catalog}`.`{target_schema}` TO `{target_group}`")
spark.sql(f"GRANT SELECT ON SCHEMA `{target_catalog}`.`{target_schema}` TO `{target_group}`")
