# Databricks notebook source
from pyspark.sql.types import IntegerType
from pyspark.sql.functions import monotonically_increasing_id

import dlt
import bronze_schema
import gold_schema

from variables_orig import *
from data_quality import *

# COMMAND ----------

# MAGIC %md # Silver Table

# COMMAND ----------

#@dlt.view()
@dlt.table(temporary=temporary)
def scheduled_aggregated_sensor():
    return spark.sql("""
        select 
            reader_uuid, 
            sensor_number,
            row_number() over (partition by reader_uuid order by sensor_number asc) as reordered_sensor_number,
            first_sched_factory_reading, 
            last_sched_factory_reading, 
            first_sched_user_reading,
            last_sched_user_reading, 
            sched_reading_count,
            read_in_target, 
            read_below_target, 
            read_above_target,
            sensoruid as original_sensor_uid,
            sensoruidcorrected as sensor_uid
        from
            (
                select 
                    reader_uuid, 
                    sensor_number, 
                    last(sensoruid) as sensoruid , 
                    last(sensoruidcorrected) as sensoruidcorrected, 
                    min(factoryRecorded) as first_sched_factory_reading, 
                    max(factoryRecorded) as last_sched_factory_reading,
                    min(userRecorded) as first_sched_user_reading, 
                    max(userRecorded) as last_sched_user_reading,
                    count(*) as sched_reading_count, 
                    sum(read_in_target_flg) as read_in_target, 
                    sum(read_below_target_flg) as read_below_target,
                    sum(read_above_target_flg) as read_above_target
                from 
                    live.SCHEDULED_GLUCOSE_READING_SILVER 
                where sensor_number > 0 
                group by 1, 2
            )
    """)
    

@dlt.table(temporary=temporary)
def sensor_enriched():
    sensor = spark.sql("""
        select 
            device_id, 
            reader_uuid, 
            prelim_sensor_no, 
            sensor_no,
            first_sched_factory_reading,
            last_sched_factory_reading, 
            first_sched_user_reading,
            last_sched_user_reading, 
            reader_nationality, 
            hours_operational,
            irregular_sensor, 
            time_to_next_sensor_start/3600.0 as time_to_next_sensor_start , 
            sched_reading_count,
            read_in_target, 
            read_above_target, 
            read_below_target, 
            time_in_target,
            time_below_target, 
            time_above_target, 
            confirm_status,
            case 
                when sensor_no = max(case when confirm_status = 1 then sensor_no else 0 end) over (partition by device_id) 
                then TRUE 
                else FALSE 
            end as last_confirmed_sensor_ind , 
            sensor_uid, 
            original_sensor_uid,
            date_
            from (
                select 
                    device.device_id,
                    sched_glu_aggr.reader_uuid, 
                    sched_glu_aggr.sensor_number as prelim_sensor_no, 
                    sched_glu_aggr.reordered_sensor_number as sensor_no, 
                    sched_glu_aggr.first_sched_factory_reading, 
                    sched_glu_aggr.last_sched_factory_reading,
                    sched_glu_aggr.first_sched_user_reading, 
                    sched_glu_aggr.last_sched_user_reading, 
                    device.reader_nationality,

                    ROUND((int((unix_timestamp(sched_glu_aggr.last_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')/60)) - int((unix_timestamp(sched_glu_aggr.first_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')/60)))/60.0, 5) as hours_operational,

                    case 
                        when (int(unix_timestamp(sched_glu_aggr.last_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')/60) - int(unix_timestamp(sched_glu_aggr.first_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')/60))/60.0 > 336 
                        then TRUE
                        else FALSE 
                    end as irregular_sensor,

                    abs(((unix_timestamp(lead(sched_glu_aggr.first_sched_factory_reading, 1) over (partition by sched_glu_aggr.reader_uuid order by sched_glu_aggr.reader_uuid, sched_glu_aggr.reordered_sensor_number), 'yyyy-MM-dd HH:mm:ss')) - (unix_timestamp(sched_glu_aggr.last_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')))) as time_to_next_sensor_start,

                    sched_glu_aggr.sched_reading_count,  
                    sched_glu_aggr.read_in_target,  
                    sched_glu_aggr.read_below_target, 
                    sched_glu_aggr.read_above_target,
                    nvl(round(sched_glu_aggr.read_in_target/sched_glu_aggr.sched_reading_count, 5)*24,0) as time_in_target,
                    nvl(round(sched_glu_aggr.read_below_target/sched_glu_aggr.sched_reading_count, 5)*24,0) as time_below_target,
                    nvl(round(sched_glu_aggr.read_above_target/sched_glu_aggr.sched_reading_count, 5)*24,0) as time_above_target,
                    
                    case 
                        when sched_glu_aggr.reordered_sensor_number = device.sensor_count 
                        then FALSE 
                        else TRUE 
                    end as confirm_status, 
                    sensor_uid,
                    original_sensor_uid,
                    CAST(device.date_ as date)
                from 
                    LIVE.scheduled_aggregated_sensor sched_glu_aggr 
                    inner join LIVE.DEVICE_SETTINGS_SILVER device 
                    where sched_glu_aggr.reader_uuid = device.reader_uuid 
                    order by sched_glu_aggr.reader_uuid, sched_glu_aggr.reordered_sensor_number
            )
    """) 
    
    return sensor.withColumn("sensor_id", monotonically_increasing_id())



@dlt.table(
  name=sensor_table_name + "SILVER",
  comment="silver sensor",
  temporary = temporary)
def sensor_silver():
    return spark.sql("""
        select 
            sensor.*, 
            sensor_start.producttype as product_type
        from 
        LIVE.sensor_enriched as sensor
        left join (
            select 
                reader_uuid,  
                sensoruid, 
                producttype  
            from 
                LIVE.GENERIC_SILVER as generic
            where type ='sensorstart'  
            group by reader_uuid, sensoruid, producttype
        ) as sensor_start  
        on sensor.reader_uuid = sensor_start.reader_uuid
        and sensor.sensor_uid = sensor_start.sensoruid  
        order by sensor.reader_uuid, sensor.sensor_no asc 
    """)
    

# COMMAND ----------

# MAGIC %md ### Useday

# COMMAND ----------


@dlt.table(temporary=temporary)
def useday():
    return spark.sql("""
            select 
                reader_uuid, 
                factoryrecorded,
                row_number() over (partition by reader_uuid order by factoryrecorded asc) as use_day 
            from (
                select distinct 
                    reader_uuid,
                    --This needs to stay because data is not in the correct format at this point  
                    to_date(factoryRecorded, 'yyyy-MM-dd HH:mm:ss') as factoryRecorded 
                from 
                    LIVE.SCHEDULED_GLUCOSE_READING_SILVER 
                where sensor_number > 0
            )
    """)

@dlt.table(temporary=temporary)
def useday_filtered():
    return spark.sql("""
            select
                *
            from
                LIVE.useday
            where reader_uuid in (
                select reader_uuid from LIVE.DEVICE_SETTINGS_SILVER
            )
    """)

# COMMAND ----------

# MAGIC %md # Gold Table

# COMMAND ----------

@dlt.table(temporary=temporary)
def sensor_data_sufficiency():
    return spark.sql(f"""
        SELECT
            SENSOR_ID,

            CASE
                WHEN SUM(CASE WHEN UNIQUE_DATES >= 5 AND READINGS_COUNT >= 10 THEN 1 ELSE 0 END) >= 20 
                THEN TRUE
                ELSE FALSE
            END as DATA_SUFFICIENCY_IND

        FROM(
            SELECT
                SENSOR_ID,
                COUNT(DISTINCT TO_DATE(FACTORY_RECORDED, 'yyyy-MM-dd HH:mm:ss')) AS UNIQUE_DATES,
                COUNT(SENSOR_ID) AS READINGS_COUNT
            FROM 
                LIVE.scheduled_final
            GROUP BY SENSOR_ID, FACTORY_REC_HOUR
        ) SENS_DS
        GROUP BY SENSOR_ID
    """)


@dlt.table(name=sensor_table_name + "GOLD",
  comment="gold sensor",
  schema=gold_schema.sensor_schema)
def sensor_stg():
    df = spark.sql(f"""
        select 
            sensor.sensor_id, 
            sensor.device_id, 
            sensor.reader_uuid, 
            sensor.sensor_no,
            sensor.first_sched_user_reading, 
            sensor.last_sched_user_reading,
            sensor.first_sched_factory_reading, 
            sensor.last_sched_factory_reading, 
            sensor.hours_operational,
            CAST(sensor.confirm_status as boolean), 
            sensor.time_to_next_sensor_start, 
            sensor.sched_reading_count,
            unsched.unsched_count as unsched_reading_count,
            
            nvl(round(unsched.unsched_count/(((cast(int((unix_timestamp(last_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')/60)) - int(unix_timestamp(first_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')/60)  as integer)/1440)+1)*1.0)), 0) as avg_scan_per_wear_day,
                
            sensor.read_in_target, 
            sensor.read_below_target, 
            sensor.read_above_target, 
            sensor.time_in_target,
            sensor.time_below_target, 
            sensor.time_above_target, 
            CAST(sensor.last_confirmed_sensor_ind as boolean), 
            sensor.irregular_sensor,
            sensor.reader_nationality,  
            CAST(sensor_data_sufficiency.data_sufficiency_ind as boolean) as data_sufficiency_ind, 
            sensor.sensor_uid, 
            sensor.original_sensor_uid, 
            sensor.product_type,
            CAST(sensor.date_ as date)
        from 
            LIVE.{sensor_table_name}SILVER as sensor
        inner join LIVE.sensor_data_sufficiency as sensor_data_sufficiency 
        on sensor.sensor_id = sensor_data_sufficiency.sensor_id
        left outer join (
            select 
                unsched_glucose.device_id, 
                unsched_glucose.sensor_no, 
                count(*) as unsched_count 
            from 
                LIVE.unscheduled_final as unsched_glucose 
            group by unsched_glucose.device_id, sensor_no) unsched
            
        on sensor.device_id = unsched.device_id 
        and sensor.sensor_no = unsched.sensor_no
    """)
    return df.withColumnRenamed("date_", "first_processed_date")






# COMMAND ----------

# MAGIC %md # Misc Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ###Day Hour

# COMMAND ----------

@dlt.view()
def day_hour():
    day_hour =  [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23]
    day_hour_df = spark.createDataFrame(day_hour, IntegerType())
    return day_hour_df



# COMMAND ----------

# MAGIC %md
# MAGIC ###Sensor Day Hour

# COMMAND ----------

@dlt.view()
def sensor_day_hr_map():
    df = spark.sql("""
        select 
            s.device_id as sd_device_id, 
            s.reader_nationality sd_reader_nationality, 
            s.sensor_id sd_sensor_id,
            s.sensor_no sd_sensor_no, 
            s.first_sched_factory_reading as sd_first_sched_factory_reading,
            s.first_sched_user_reading sd_first_sched_user_reading, 
            s.cal_days as sd_cal_days, 
            dh.value as hr,
            s.date_
        from 
            LIVE.day_hour dh 
        CROSS JOIN (
            select 
                sensor.sensor_id, 
                sensor.sensor_no, 
                sensor.device_id, 
                sensor.reader_nationality,
                sensor.first_sched_factory_reading, 
                sensor.first_sched_user_reading,
                sg_sensor.sg_cal_days as cal_days,
                sensor.date_ 
            from (
                select 
                    sensor_id sg_sensor_id, 
                    COUNT(DISTINCT calendar_day) as sg_cal_days 
                from LIVE.scheduled_final ssg_sensor 
                where irregular_reading = 0 
                and first_last_calendar_day_ind = 0 
                and irregular_reading = 0 
                group by sensor_id
            ) sg_sensor
            inner join LIVE.SENSOR_SILVER sensor 
            on sg_sensor.sg_sensor_id = sensor.sensor_id
        ) s
    """)
    return df.withColumnRenamed("date_", "first_processed_date") 

# COMMAND ----------

# MAGIC %md
# MAGIC ###Sensor Calendar Day Reads

# COMMAND ----------

@dlt.view()
def sensor_cal_day_reads():
    df =  spark.sql("""
        select 
            sg.sensor_id as sc_sensor_id, 
            sg.user_rec_hour as sc_user_rec_hour, 
            sg.reads as sc_reads, 
            sg.read_days as sc_read_days,
            sg.date_
        from (
            select 
                sensor_id, 
                user_rec_hour, 
                COUNT(sched_glucose_id) as reads, 
                COUNT(DISTINCT(calendar_day)) as read_days ,
                date_
            from 
                LIVE.scheduled_final 
            where calendar_day > 0 
            and first_last_calendar_day_ind = 0 
            and irregular_reading = 0 
            GROUP BY sensor_id, user_rec_hour, date_
        ) sg
    """)
    return df.withColumnRenamed("date_", "first_processed_date")


# COMMAND ----------

# MAGIC %md
# MAGIC ###Reads Per User Hour

# COMMAND ----------

@dlt.table(name="READS_PER_USER_HOUR_GOLD",
  comment="gold reads_per_user_hour",
  schema=gold_schema.reads_per_user_hour_schema)
def reads_per_user_hr():    
    return spark.sql("""
        select 
            sen_day.sd_reader_nationality as reader_nationality, 
            sen_day.sd_device_id as device_id, 
            sen_day.sd_sensor_no as sensor_no, 
            sen_day.sd_sensor_id as sensor_id,
            sen_day.sd_first_sched_factory_reading as first_sched_factory_reading, 
            sen_day.sd_first_sched_user_reading as first_sched_user_reading, 
            sen_day.sd_cal_days as calendar_days, 
            sen_day.hr as user_hour, 
            NVL(sen_read.sc_reads, 0) as sched_reading_count,
            sen_day.first_processed_date
        from 
            LIVE.sensor_day_hr_map sen_day 
        left outer join LIVE.sensor_cal_day_reads as sen_read
        on sen_day.sd_sensor_id = sen_read.sc_sensor_id 
        and sen_day.hr = sen_read.sc_user_rec_hour 
        where sen_day.sd_first_sched_factory_reading IS NOT NULL
    """)
