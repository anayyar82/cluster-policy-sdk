# Databricks notebook source
from pyspark.sql.functions import lit, col

import dlt
import bronze_schema
import gold_schema

from variables_orig import *
from data_quality import *

# COMMAND ----------

# MAGIC %md # Bronze Table

# COMMAND ----------

# MAGIC %md ### Blacklisted Accounts

# COMMAND ----------

@dlt.table(temporary=temporary)
def bronze_blacklist_account():
    #Ingesting the Blacklist.csv file
    return spark.read.table(f"`{marshall_catalog}`.`{misc_schema}`.`bl-accounts`")

# COMMAND ----------

# MAGIC %md
# MAGIC ###Blacklist Gold
# MAGIC

# COMMAND ----------

@dlt.table(name=bl_accounts_table_name + "GOLD",
  comment="blacklist gold table",
  schema=gold_schema.account_blacklist_schema)
#@dlt.expect_all_or_drop(account_blacklist)
def gold_blacklist_account():
    return spark.sql("""select 
                     accountid as account_id,
                     reason,
                     CAST(date_added as date)
      from live.bronze_blacklist_account""")

# COMMAND ----------

# MAGIC %md ### Account Details

# COMMAND ----------

@dlt.table(temporary=temporary)
#@dlt.view()
def account_details_input():
    return spark.read.table(f"`{dmz_catalog}`.`{input_schema}`.`account_details`")

# @dlt.view()
@dlt.table(temporary=temporary)
def account_details_threshold():
    #Checking that devices come from a region with more than 11 devices
    return spark.sql("select accountid from  LIVE.account_details_input where devicenationality in (select\
            devicenationality from LIVE.account_details_input group by devicenationality having count(devicenationality) >= 11)")
           

# @dlt.view()
@dlt.table(temporary=temporary)
def account_details_without_blacklisted_users():
    #Choosing accounts not in blacklist
    return spark.sql("select * from LIVE.account_details_input where accountid NOT IN (select accountid from LIVE.bronze_blacklist_account )")

#@dlt.view()
@dlt.table(temporary=temporary)
def accounts_greater_than_threshold():
    #Comparing preivous table against threshold table
    return spark.sql("select * from LIVE.account_details_without_blacklisted_users where \
                                                    accountid IN (select accountid from LIVE.account_details_threshold )")




@dlt.table(name="ACCOUNT_GOLD",
           )
def account_details_gold():
    #Gold account table that stores all the accounts used. 
    return spark.sql("""
            select 
                accountid as account_id, 
                devicenationality as reader_nationality,
                CAST(agerangelower as integer) as age_range_lower,
                CAST(agerangeupper as integer) as age_range_upper 
            from 
                LIVE.accounts_greater_than_threshold
            INNER JOIN LIVE.whitelisted_countries
            ON LIVE.accounts_greater_than_threshold.devicenationality =  LIVE.whitelisted_countries.code
        """)
    # This table does not store history, so removing this column makes sense since otherwise it will just show the processed time. 
    # We could bring this up with Superior and maybe have them pass this column in. For now commenting on. 
    # return df.withColumn("first_processed_date",  lit(snapshot_date))

# COMMAND ----------

# MAGIC %md ### Account Devices

# COMMAND ----------

#Creating original table
@dlt.table(temporary=temporary)
#@dlt.view()
def account_input():
    df = (spark.read
            .table(f"`{dmz_catalog}`.`{input_schema}`.`account_devices`")
            .where(col("uploaddate").between(start_date, end_date))
    )              
    return df.withColumn("date_", lit(snapshot_date))


@dlt.table(temporary=temporary)
#@dlt.view()
def account_history():
    query = f"SHOW TABLES IN `{history_catalog}`.`{history_schema}` LIKE 'account_devices'"
    result = spark.sql(query).collect()

    if result:
        return (spark.read
                .table(f'`{history_catalog}`.`{history_schema}`.`account_devices`')
        )
    else:
        return spark.createDataFrame([], schema=bronze_schema.account_devices_schema)


@dlt.view()
#@dlt.table(temporary=temporary)
def account_combined():
    combined = spark.sql("SELECT accountid, deviceuuid, date_ from LIVE.account_input UNION SELECT accountid, deviceuuid, date_ from LIVE.account_history;")

    
    return combined.orderBy("accountid", "deviceuuid", "date_").dropDuplicates(subset=['accountid', 'deviceuuid'])


@dlt.table(
  name=account_devices_table_name + "GOLD",
  comment="final account devices",
  schema=gold_schema.account_devices_schema)
def account_final():
    #Final Account Table that stores all account info mapped to specific devices
    return spark.sql("""
            select 
                accountId as account_id, 
                deviceuuid as reader_uuid, 
                CAST(date_ as date) as first_processed_date 
            from 
                LIVE.account_combined 
            where deviceuuid in (select distinct(reader_uuid) from LIVE.DEVICE_SETTINGS_SILVER)
    """)


@dlt.table(
  name=account_devices_table_name + "BRONZE_HISTORY",
  comment="bronze account devices",
  schema=bronze_schema.account_devices_schema,
  temporary=temporary)
def account_devices_update_history():
    #Updating history for Account
    df = spark.sql(f"select ac.account_id as accountid, ac.reader_uuid as deviceuuid, ac.first_processed_date as date_ from live.{account_devices_table_name}GOLD ac where ac.first_processed_date = '{snapshot_date}' ")
     
    df.write.mode("append").format("delta")\
        .option('nullValue', None)\
        .option("mergeSchema", "true")\
        .saveAsTable(f"`{marshall_catalog}`.`{history_schema}`.`account_devices`")

    
    return df

