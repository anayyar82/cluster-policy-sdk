# Databricks notebook source
from pyspark.sql.functions import col, lit, from_unixtime, date_format, unix_timestamp, hour, to_timestamp

import dlt
import bronze_schema
import gold_schema

from variables_orig import *
from data_quality import *

# COMMAND ----------

# MAGIC %md # Bronze Table

# COMMAND ----------


@dlt.table(temporary=temporary)
@dlt.expect_all_or_drop(generic_input_rules)
def generic_input():
    df = (spark.read
        .table(f"`{dmz_catalog}`.`{input_schema}`.`{generic_table_name[:-1]}`")
        .where(col("uploaddate").between(start_date, end_date))
    )              
    return df.withColumn("date_", lit(snapshot_date))

@dlt.table(temporary=temporary)
def generic_history():
    query = f"SHOW TABLES IN `{history_catalog}`.`{history_schema}` LIKE '{generic_table_name[:-1]}'"
    result = spark.sql(query).collect()
    if result:
        return (spark.read
                .table(f'`{history_catalog}`.`{history_schema}`.`{generic_table_name[:-1]}`')
        )
    else:
        return spark.createDataFrame([], schema=bronze_schema.generic_schema)



@dlt.view()
def generic_combined():
    return spark.sql("SELECT * from LIVE.generic_input UNION SELECT * from LIVE.generic_history;")

@dlt.view()
def generic_dedup():
    df = spark.sql(f"SELECT * from LIVE.generic_combined ORDER BY deviceuuid ASC, factoryrecorded ASC, uploadsequence ASC, date_ ASC;")
    return df.dropDuplicates(subset=['deviceuuid', 'factoryrecorded', 'type'])

@dlt.view()
def generic_blacklist():
    return spark.sql("select a.* from live.generic_dedup as a LEFT Join live.bronze_blacklist_account as b on a.accountid = b.accountid where b.accountId is null")


@dlt.table(name=generic_table_name + "BRONZE",
           temporary = temporary)
def generic_threshold():
    return spark.sql("""SELECT a.* from live.generic_blacklist as a WHERE a.accountid in (
        SELECT accountid from live.accounts_greater_than_threshold where accountid is not null
    )""")


@dlt.table(
  name=generic_table_name + "BRONZE_HISTORY",
  comment="combined generic",
  schema=bronze_schema.generic_schema,
  temporary=temporary)
def generic_update_history():
    df=spark.sql(f"select * from live.{generic_table_name}BRONZE where date_ = '{snapshot_date}' ")
        
    df.write.mode("append").format("delta")\
        .option('nullValue', None)\
        .option("mergeSchema", "false")\
        .saveAsTable(f"`{marshall_catalog}`.`{history_schema}`.`{generic_table_name[:-1]}`")

    
    return df




# COMMAND ----------

# MAGIC %md # Silver Table

# COMMAND ----------


@dlt.table(temporary=temporary)
def generic_filtered():
    #Formating Time
    time_df = spark.sql(f"select  if  (instr(right(userRecorded,6), '+') > 0 or instr(right(userRecorded,6), '-') > 0 , substr(userRecorded,0,length(userRecorded)-6) , userRecorded) as userRecorded_modified,*  from  LIVE.{generic_table_name}BRONZE")
    
    time_df = time_df.drop("userRecorded") \
                    .withColumnRenamed("userRecorded_modified", "userRecorded") \
                    .withColumn('userRecorded', to_timestamp(col('userRecorded'))) \
                    .withColumn('factoryrecorded', to_timestamp(col('factoryrecorded')))
    return time_df

@dlt.table(
  name=generic_table_name + "SILVER",
  temporary=temporary)
def generic_silver():
    new_df = spark.sql("SELECT * from LIVE.generic_filtered;")
    new_df = new_df \
                        .withColumn("factoryrechour", hour(new_df.factoryrecorded)) \
                        .withColumn("userrechour", hour(new_df.userRecorded))

    new_df = new_df.withColumnRenamed("deviceUUID", "reader_uuid") \
                                        .withColumnRenamed("deviceNationality", "country") \
                                        .withColumnRenamed("uploadSequence", "upload_id") \
                                        .withColumnRenamed("firmwareVersion", "firmware")      
    new_df.orderBy(new_df['reader_uuid'].asc(), new_df['factoryrecorded'].asc())
    
    return new_df
