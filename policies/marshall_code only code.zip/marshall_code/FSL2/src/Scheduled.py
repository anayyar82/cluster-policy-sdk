# Databricks notebook source
from pyspark.sql.functions import col, expr, lit, from_unixtime, unix_timestamp, monotonically_increasing_id, hour, date_format, to_timestamp, udf
from pyspark.sql.types import BooleanType

import dlt
import bronze_schema
import gold_schema

from variables_orig import *
from data_quality import *

# COMMAND ----------

import datetime
def is_date(date_text):
	try:
		datetime.datetime.strptime(date_text, '%Y-%m-%d')
		return True
	except ValueError:
		return False
isdate = udf(is_date, BooleanType())
spark.udf.register('isdate', isdate)


# COMMAND ----------

# MAGIC %md # Bronze Table

# COMMAND ----------

@dlt.table(temporary=temporary)
@dlt.expect_all_or_drop(scheduled_input_rules)
def scheduled_input():
    df = (spark.read
            .table(f"`{dmz_catalog}`.`{input_schema}`.`scheduled`")
            .where(col("uploaddate").between(start_date, end_date))
    )

                   
    return df.withColumn("date_", lit(snapshot_date))


@dlt.table(temporary=temporary)
def scheduled_history():
    query = f"SHOW TABLES IN `{history_catalog}`.`{history_schema}` LIKE 'scheduled'"
    result = spark.sql(query).collect()
    if result:
        history = (spark.read
                .table(f'`{history_catalog}`.`{history_schema}`.`scheduled`')
        )

        #Unsure if this part is really needed. This may be removed as part of our sensoruid changes.   
        history = history.select("accountid", "factoryrecorded", "userrecorded", "deviceuuid", "devicenationality", "uploadsequence", 
                                            "firmwareversion","mgdl","firstaftertimechange","devicetype","sensoruid","uploaddate", 
                                            expr("case when isdate(sensoruidcorrected) = true then NULL else  sensoruidcorrected  end").alias("sensoruidcorrected"), "date_")
    else:
        history = spark.createDataFrame([], schema=bronze_schema.scheduled_schema)
    
    return history

@dlt.view()
#@dlt.table(temporary=temporary)
def scheduled_combined():
    return spark.sql("SELECT * from LIVE.scheduled_input UNION SELECT * from LIVE.scheduled_history;")


@dlt.view()
#@dlt.table(temporary=temporary)
def scheduled_dedup():
    df = spark.sql("SELECT * from LIVE.scheduled_combined ORDER BY deviceuuid ASC, factoryrecorded ASC, uploadsequence ASC, date_ ASC;")
    return df.dropDuplicates(subset=['deviceuuid', 'factoryrecorded'])


@dlt.view()
#@dlt.table(temporary=temporary)
def scheduled_blacklist_applied():
    return spark.sql("select a.* from live.scheduled_dedup as a LEFT Join live.bronze_blacklist_account as b on a.accountid = b.accountid where b.accountid is null")



@dlt.view(name=scheduled_table_name + "BRONZE")
def scheduled_threshold():
    return spark.sql("""SELECT a.* from live.scheduled_blacklist_applied as a WHERE a.accountid in (
        SELECT accountid from live.accounts_greater_than_threshold where accountid is not null
    )""")


@dlt.table(
  name=scheduled_table_name + "HISTORY_BRONZE",
  comment="combined scheduled",
  schema=bronze_schema.scheduled_schema,
  temporary=temporary)
def scheduled_update_history():
    df = spark.sql(f"select * from live.{scheduled_table_name}BRONZE where date_ = '{snapshot_date}' ")

    df.write.mode("append").format("delta")\
        .option('nullValue', None)\
        .option("mergeSchema", "false")\
        .saveAsTable(f"`{marshall_catalog}`.`{history_schema}`.`scheduled`")
    
    return df

# COMMAND ----------

# MAGIC %md # Silver Table

# COMMAND ----------

#@dlt.view()
@dlt.table(temporary=temporary)
def scheduled_first_activation():
    activate =  spark.sql(f"""
        select *,
        0 as firstAfterActivation,
        lag(s.sensoruid) over (partition by deviceUUID,sensoruid order by deviceUUID,factoryrecorded, sensoruid) as previous_sensor_id 
        from LIVE.{scheduled_table_name}BRONZE as s
    """) 
    

    after_activation = activate.select("sensoruid", "accountid", "factoryrecorded", 
                                       "userrecorded", "deviceuuid", "devicenationality", 
                                       "uploadsequence", "firmwareversion", "mgdl", 
                                       "firstaftertimechange", "devicetype", 
                                       expr("case when previous_sensor_id = sensoruid then 0 else 1 end as firstafteractivation").alias('firstafteractivation'), 
                                       "sensoruidcorrected", "date_")
    return after_activation

#@dlt.view()
@dlt.table(temporary=temporary)
def scheduled_filtered():
    time_df = spark.sql("select  if  (instr(right(userrecorded,6), '+') > 0 or instr(right(userrecorded,6), '-') > 0 , substr(userrecorded,0,length(userrecorded)-6) , userrecorded) as userrecorded_modified,* from LIVE.scheduled_first_activation")

    time_df = time_df.drop("userrecorded") \
                    .withColumnRenamed("userrecorded_modified", "userrecorded") \
                    .withColumn('userrecorded', to_timestamp(col('userRecorded'))) \
                    .withColumn('factoryrecorded', to_timestamp(col('factoryrecorded')))
    return time_df

#@dlt.view()
@dlt.table(temporary=temporary)
def scheduled_renaming():
    new_df = spark.sql("SELECT * from LIVE.scheduled_filtered;")
    new_df = new_df \
                        .withColumn("factoryrechour", hour(new_df.factoryrecorded)) \
                        .withColumn("userrechour", hour(new_df.userrecorded))

    new_df = new_df.withColumnRenamed("deviceuuid", "reader_uuid") \
                                        .withColumnRenamed("devicenationality", "country") \
                                        .withColumnRenamed("uploadsequence", "upload_id") \
                                        .withColumnRenamed("firmwareversion", "firmware")      

    new_df.orderBy(new_df['reader_uuid'].asc(), new_df['factoryrecorded'].asc())
    
    return new_df



@dlt.table(
  name=scheduled_table_name + "SILVER",
  comment="silver scheduled",
  temporary=temporary)
def scheduled_silver():
    return spark.sql("""
        select 
            reader_uuid, 
            country,
            upload_id, 
            firmware,
            mgdl as value_mgdl, 
            firstafteractivation,
            case when mgdl between 70 and 180 then 1 else 0 end as read_in_target_flg,
            case when mgdl < 70 then 1 else 0 end as read_below_target_flg,
            case when mgdl > 180 then 1 else 0 end as read_above_target_flg,
            firstaftertimechange,
            sum(firstafteractivation) over (partition by reader_uuid order by factoryrecorded rows between unbounded preceding and current row) as sensor_number,
            factoryrecorded, 
            factoryrechour, 
            userrecorded, 
            userrechour,
            sensoruid,
            sensoruidcorrected, 
            date_ 
        from 
            LIVE.scheduled_renaming
    """)

# COMMAND ----------

# MAGIC %md # Gold Table

# COMMAND ----------

# MAGIC %md ### Prereplace Study Table

# COMMAND ----------

# ==THIS TABLE IS CURRENTLY COMMENTED OUT DUE TO IT BEING UNNECESSARY FOR VERSION 1.1.0. IF NO LONGER NEEDED, THE NEXT RELEASE WILL REMOVE IT ENTIRELY ==

# @dlt.table(temporary=temporary)
# def pre_replace_study():        
#     return spark.sql("""
#         select 
#             sched_glucose_id as prerep_sched_glucose_id, 
#             device_id, 
#             reader_uuid, 
#             sensor_id, 
#             irregular_sensor, 
#             factory_recorded_b2,
#             factory_recorded_b1, 
#             factory_recorded_pr, 
#             factory_recorded_f1, 
#             factory_recorded_f2, 
#             b2_b1_gap, 
#             b1_pr_gap, 
#             pr_f1_gap, 
#             f1_f2_gap,

#             case
#                 when b1_pr_gap = 1 and pr_f1_gap = 1 
#                 then 1 
#                 else 0 
#             end as isolated_read,

#             case
#                 when value_mgdl_b1 > 300 AND value_mgdl_pr > 300 AND b1_pr_gap = 0 AND pr_f1_gap = 1 
#                 THEN 3
#                 when value_mgdl_pr > 300 AND value_mgdl_f1 > 300 AND b1_pr_gap = 1 AND pr_f1_gap = 0 
#                 THEN 1
#                 WHEN value_mgdl_b1 > 300 AND VALUE_MGDL_PR > 300 AND (VALUE_MGDL_F1 <= 300 OR VALUE_MGDL_F1 is NULL) AND B1_PR_GAP = 0 
#                 THEN 3
#                 WHEN (value_mgdl_b1 <= 300 OR value_mgdl_b1 is NULL) AND VALUE_MGDL_PR > 300 AND VALUE_MGDL_F1 > 300 AND PR_F1_GAP = 0 
#                 THEN 1
#                 WHEN value_mgdl_b1 > 300 AND VALUE_MGDL_PR > 300 AND VALUE_MGDL_F1 > 300 AND PR_F1_GAP = 0 AND B1_PR_GAP = 0 
#                 THEN 2
#                 ELSE 0
#             end as hyper_300,

#             case
#                 WHEN value_mgdl_b1 > 240 AND VALUE_MGDL_PR > 240 AND B1_PR_GAP = 0 AND PR_F1_GAP = 1 
#                 THEN 3
#                 WHEN VALUE_MGDL_PR > 240 AND VALUE_MGDL_F1 > 240 AND B1_PR_GAP = 1 AND PR_F1_GAP = 0 
#                 THEN 1
#                 WHEN value_mgdl_b1 > 240 AND VALUE_MGDL_PR > 240 AND (VALUE_MGDL_F1 <= 240 OR VALUE_MGDL_F1 is NULL) AND B1_PR_GAP = 0 
#                 THEN 3
#                 WHEN (value_mgdl_b1 <= 240 OR value_mgdl_b1 is NULL) AND VALUE_MGDL_PR > 240 AND VALUE_MGDL_F1 > 240 AND PR_F1_GAP = 0 
#                 THEN 1
#                 WHEN value_mgdl_b1 > 240 AND VALUE_MGDL_PR > 240 AND VALUE_MGDL_F1 > 240 AND PR_F1_GAP = 0 AND B1_PR_GAP = 0 
#                 THEN 2
#                 ELSE 0
#             end as hyper_240,

#             case
#                 WHEN value_mgdl_b1 > 180 AND VALUE_MGDL_PR > 180 AND B1_PR_GAP = 0 AND PR_F1_GAP = 1 
#                 THEN 3
#                 WHEN VALUE_MGDL_PR > 180 AND VALUE_MGDL_F1 > 180 AND B1_PR_GAP = 1 AND PR_F1_GAP = 0 
#                 THEN 1
#                 WHEN value_mgdl_b1 > 180 AND VALUE_MGDL_PR > 180 AND (VALUE_MGDL_F1 <= 180 OR VALUE_MGDL_F1 is NULL) AND B1_PR_GAP = 0 
#                 THEN 3
#                 WHEN (value_mgdl_b1 <= 180 OR value_mgdl_b1 is NULL) AND VALUE_MGDL_PR > 180 AND VALUE_MGDL_F1 > 180 AND PR_F1_GAP = 0 
#                 THEN 1
#                 WHEN value_mgdl_b1 > 180 AND VALUE_MGDL_PR > 180 AND VALUE_MGDL_F1 > 180 AND PR_F1_GAP = 0 AND B1_PR_GAP = 0 
#                 THEN 2
#                 ELSE 0
#             end as hyper_180,

#             case
#                 WHEN value_mgdl_b1 < 70 AND VALUE_MGDL_PR < 70 AND B1_PR_GAP = 0 AND PR_F1_GAP = 1 
#                 THEN 3
#                 WHEN VALUE_MGDL_PR < 70 AND VALUE_MGDL_F1 < 70 AND B1_PR_GAP = 1 AND PR_F1_GAP = 0 
#                 THEN 1
#                 WHEN value_mgdl_b1 < 70 AND VALUE_MGDL_PR < 70 AND (VALUE_MGDL_F1 >= 70 OR VALUE_MGDL_F1 is NULL) AND B1_PR_GAP = 0 
#                 THEN 3
#                 WHEN (value_mgdl_b1 >= 70 OR value_mgdl_b1 is NULL) AND VALUE_MGDL_PR < 70 AND VALUE_MGDL_F1 < 70 AND PR_F1_GAP = 0 
#                 THEN 1
#                 WHEN value_mgdl_b1 < 70 AND VALUE_MGDL_PR < 70 AND VALUE_MGDL_F1 < 70 AND PR_F1_GAP = 0 AND B1_PR_GAP = 0 
#                 THEN 2
#                 ELSE 0
#             end as hypo_70,

#             case
#                 WHEN value_mgdl_b1 < 55 AND VALUE_MGDL_PR < 55 AND B1_PR_GAP = 0 AND PR_F1_GAP = 1 
#                 THEN 3
#                 WHEN VALUE_MGDL_PR < 55 AND VALUE_MGDL_F1 < 55 AND B1_PR_GAP = 1 AND PR_F1_GAP = 0 
#                 THEN 1
#                 WHEN value_mgdl_b1 < 55 AND VALUE_MGDL_PR < 55 AND (VALUE_MGDL_F1 >= 55 OR VALUE_MGDL_F1 is NULL) AND B1_PR_GAP = 0 
#                 THEN 3
#                 WHEN (value_mgdl_b1 >= 55 OR value_mgdl_b1 is NULL) AND VALUE_MGDL_PR < 55 AND VALUE_MGDL_F1 < 55 AND PR_F1_GAP = 0 
#                 THEN 1
#                 WHEN value_mgdl_b1 < 55 AND VALUE_MGDL_PR < 55 AND VALUE_MGDL_F1 < 55 AND PR_F1_GAP = 0 AND B1_PR_GAP = 0 
#                 THEN 2
#                 ELSE 0
#             end as hypo_55,

#             case
#                 WHEN value_mgdl_b1 < 45 AND VALUE_MGDL_PR < 45 AND B1_PR_GAP = 0 AND PR_F1_GAP = 1 
#                 THEN 3
#                 WHEN VALUE_MGDL_PR < 45 AND VALUE_MGDL_F1 < 45 AND B1_PR_GAP = 1 AND PR_F1_GAP = 0 
#                 THEN 1
#                 WHEN value_mgdl_b1 < 45 AND VALUE_MGDL_PR < 45 AND (VALUE_MGDL_F1 >= 45 OR VALUE_MGDL_F1 is NULL) AND B1_PR_GAP = 0 
#                 THEN 3
#                 WHEN (value_mgdl_b1 >= 45 OR value_mgdl_b1 is NULL) AND VALUE_MGDL_PR < 45 AND VALUE_MGDL_F1 < 45 AND PR_F1_GAP = 0 
#                 THEN 1
#                 WHEN value_mgdl_b1 < 45 AND VALUE_MGDL_PR < 45 AND VALUE_MGDL_F1 < 45 AND PR_F1_GAP = 0 AND B1_PR_GAP = 0 
#                 THEN 2
#                 ELSE 0
#             end as hypo_45

#         from (
#             select 
#                 sched_glucose_id, 
#                 device_id, 
#                 reader_uuid, 
#                 sensor_id, 
#                 irregular_sensor, 
#                 factory_recorded_b2, 
#                 factory_recorded_pr, 
#                 upload_id,
#                 factory_recorded_b1, 
#                 factory_recorded_f1, 
#                 factory_recorded_f2, 
#                 value_mgdl_b1, 
#                 value_mgdl_b2, 
#                 value_mgdl_f1, 
#                 value_mgdl_f2, 
#                 value_mgdl_pr,

#                 case
#                     when factory_recorded_b2 IS NULL 
#                     THEN 1
#                     when factory_recorded_b1 IS NULL 
#                     THEN 1
#                     when unix_timestamp(factory_recorded_b1, 'yyyy-MM-dd HH:mm:ss') - unix_timestamp(factory_recorded_b2, 'yyyy-MM-dd HH:mm:ss') > 3600 
#                     THEN 1
#                     else 0 
#                 end as b2_b1_gap,

#                 case
#                     when factory_recorded_b1 IS NULL 
#                     THEN 1
#                     when unix_timestamp(factory_recorded_pr, 'yyyy-MM-dd HH:mm:ss') - unix_timestamp(factory_recorded_b1, 'yyyy-MM-dd HH:mm:ss') > 3600 
#                     THEN 1
#                     else 0 
#                 end as b1_pr_gap,

#                 case
#                     when factory_recorded_f1 IS NULL 
#                     THEN 1
#                     when unix_timestamp(factory_recorded_f1, 'yyyy-MM-dd HH:mm:ss') - unix_timestamp(factory_recorded_pr, 'yyyy-MM-dd HH:mm:ss') > 3600 
#                     THEN 1
#                     else 0 
#                 end as pr_f1_gap,

#                 case
#                     when factory_recorded_f1 IS NULL 
#                     THEN 1
#                     when factory_recorded_f2 IS NULL 
#                     THEN 1
#                     when unix_timestamp(factory_recorded_f2, 'yyyy-MM-dd HH:mm:ss') - unix_timestamp(factory_recorded_f1, 'yyyy-MM-dd HH:mm:ss') > 3600 
#                     THEN 1
#                     else 0 
#                 end as f1_f2_gap
                
#             from
#                 (
#                     select 
#                         sched_glucose_id, 
#                         device_id, 
#                         reader_uuid, 
#                         sensor_id, 
#                         irregular_sensor, 
#                         upload_id,
#                         lag(factory_recorded, 2) over (partition by device_id order by factory_recorded) as factory_recorded_b2,
#                         lag(factory_recorded, 1) over (partition by device_id order by factory_recorded) as factory_recorded_b1,
#                         factory_recorded as factory_recorded_pr,
#                         lead(factory_recorded, 1) over (partition by device_id order by factory_recorded) as factory_recorded_f1,
#                         lead(factory_recorded, 2) over (partition by device_id order by factory_recorded) as factory_recorded_f2,
#                         lag(value_mgdl, 2) over (partition by device_id order by factory_recorded) as value_mgdl_b2,
#                         lag(value_mgdl, 1) over (partition by device_id order by factory_recorded) as value_mgdl_b1,
#                         value_mgdl as value_mgdl_pr,
#                         lead(value_mgdl, 1) over (partition by device_id order by factory_recorded) as value_mgdl_f1,
#                         lead(value_mgdl, 2) over (partition by device_id order by factory_recorded) as value_mgdl_f2
#                     from 
#                         LIVE.scheduled_final
#                 )
#             )
#     """)
    

# COMMAND ----------

# MAGIC %md ### Final Scheduled

# COMMAND ----------

#@dlt.view()
@dlt.table(temporary=temporary)
def scheduled_final():
    df = spark.sql("""
                select 
                    sched_glucose.reader_uuid,
                    sched_glucose.country,
                    device.device_id as device_id, 
                    sensor.sensor_id, 
                    sensor.sensor_no, 
                    sensor.irregular_sensor, 
                    sched_glucose.upload_id,
                    ROUND(sched_glucose.value_mgdl, 2) as value_mgdl, 
                    sched_glucose.factoryrecorded as factory_recorded, 
                    sched_glucose.factoryRecHour as factory_rec_hour,
                    sched_glucose.read_in_target_flg, 
                    sched_glucose.read_above_target_flg, 
                    sched_glucose.read_below_target_flg,
                    sched_glucose.userRecorded as user_recorded, 
                    sched_glucose.userRecHour as user_rec_hour, 
                    sched_glucose.firstAfterActivation as first_after_activation,  
                    sched_glucose.firstAfterTimeChange as first_after_time_change,
                    datediff(sched_glucose.factoryRecorded, sensor.first_sched_factory_reading) + 1 as calendar_day,
                    datediff(sched_glucose.factoryRecorded, device.first_sched_factory_reading) as ownership_day,

                    cast(((int(unix_timestamp(sched_glucose.factoryRecorded, 'yyyy-MM-dd HH:mm:ss')/60) - int(unix_timestamp(sensor.first_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')/60))/1440) + 1 as int) as wear_day,

                    case
                        when day(sched_glucose.factoryRecorded) = day(sensor.first_sched_factory_reading) 
                        then TRUE
                        when day(sched_glucose.factoryRecorded) = day(sensor.last_sched_factory_reading) 
                        then TRUE 
                        else FALSE 
                        end 
                    as first_last_calendar_day_ind,
                    
                    case 
                        when (int((int(unix_timestamp(sched_glucose.factoryRecorded, 'yyyy-MM-dd HH:mm:ss')/60) - int(unix_timestamp(sensor.first_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')/60))/(1440)) + 1)  > 14 \
                        then TRUE 
                        else FALSE 
                        end 
                    as irregular_reading, 

                    useday.use_day as usage_day, 
                    0 as adc_analysis_ind,
                    sched_glucose.date_
                from 
                    LIVE.SCHEDULED_GLUCOSE_READING_SILVER as sched_glucose 
                inner join LIVE.DEVICE_SETTINGS_SILVER as device 
                on device.reader_uuid = sched_glucose.reader_uuid 
                inner join LIVE.SENSOR_SILVER as sensor 
                on (sched_glucose.reader_uuid = sensor.reader_uuid and sched_glucose.sensor_number = sensor.prelim_sensor_no) 
                inner join LIVE.useday_filtered as useday 
                on (sched_glucose.reader_uuid = useday.reader_uuid and to_date(sched_glucose.factoryRecorded) = to_date(useday.factoryRecorded))
        """) 
    
    return df.withColumn("sched_glucose_id", monotonically_increasing_id())

# ==THIS TABLE IS CURRENTLY COMMENTED OUT DUE TO IT BEING UNNECESSARY FOR VERSION 1.1.0. IF NO LONGER NEEDED, THE NEXT RELEASE WILL REMOVE IT ENTIRELY ==
# @dlt.table(temporary=temporary)
# def scheduled_stg():
#     return spark.sql("""
#                     select 
#                         sched_glu_data.sched_glucose_id, 
#                         sched_glu_data.device_id, 
#                         sched_glu_data.sensor_no, 
#                         sched_glu_data.sensor_id, 
#                         sched_glu_data.upload_id,  
#                         sched_glu_data.irregular_reading,
#                         sched_glu_data.value_mgdl, 
#                         sched_glu_data.user_recorded, 
#                         sched_glu_data.user_rec_hour, 
#                         sched_glu_data.factory_recorded,
#                         sched_glu_data.factory_rec_hour, 
#                         sched_glu_data.wear_day, 
#                         sched_glu_data.calendar_day, 
#                         sched_glu_data.first_last_calendar_day_ind,
#                         sched_glu_data.first_after_activation,  
#                         sched_glu_data.first_after_time_change,
#                         sched_glu_data.usage_day,
#                         sched_glu_data.ownership_day,

#                         case when 
#                             (sched_glu_data.irregular_reading = 0 and prereplace_study.irregular_sensor = 0 and prereplace_study.isolated_read = 0) 
#                             then 1 
#                             else 0 
#                             end 
#                         as adc_analysis_ind,

#                         case when 
#                             (sched_glu_data.irregular_reading = 0 and prereplace_study.irregular_sensor = 0 and prereplace_study.isolated_read = 0) 
#                             then prereplace_study.B1_PR_GAP 
#                             end 
#                         as first_after_gap,
            
#                         case when
#                             (sched_glu_data.irregular_reading = 0 and prereplace_study.irregular_sensor = 0 and prereplace_study.isolated_read = 0) 
#                             then prereplace_study.PR_F1_GAP 
#                             end 
#                         as last_before_gap,
                            
#                         case when
#                             (sched_glu_data.irregular_reading = 0 and prereplace_study.irregular_sensor = 0 and prereplace_study.isolated_read = 0) 
#                             then prereplace_study.HYPER_300 
#                             end 
#                         as HYPER_300,
                            
#                         case when
#                             (sched_glu_data.irregular_reading = 0 and prereplace_study.irregular_sensor = 0 and prereplace_study.isolated_read = 0) 
#                             then prereplace_study.HYPER_240 
#                             end 
#                         as HYPER_240,
                            
#                         case when
#                             (sched_glu_data.irregular_reading = 0 and prereplace_study.irregular_sensor = 0 and prereplace_study.isolated_read = 0) 
#                             then prereplace_study.HYPER_180 
#                             end 
#                         as HYPER_180,
                            
#                         case when
#                             (sched_glu_data.irregular_reading = 0 and prereplace_study.irregular_sensor = 0 and prereplace_study.isolated_read = 0) 
#                             then prereplace_study.HYPO_70 
#                             end 
#                         as HYPO_70,
                            
#                         case when
#                             (sched_glu_data.irregular_reading = 0 and prereplace_study.irregular_sensor = 0 and prereplace_study.isolated_read = 0) 
#                             then prereplace_study.HYPO_55 
#                             end 
#                         as HYPO_55,
                            
#                         case when
#                             (sched_glu_data.irregular_reading = 0 and prereplace_study.irregular_sensor = 0 and prereplace_study.isolated_read = 0) 
#                             then prereplace_study.HYPO_45 
#                             end 
#                         as HYPO_45,
                            
#                         sched_glu_data.read_in_target_flg, 
#                         sched_glu_data.read_above_target_flg, 
#                         sched_glu_data.read_below_target_flg,
#                         sched_glu_data.irregular_sensor, 
#                         sched_glu_data.reader_uuid, 
#                         sched_glu_data.country,
#                         sched_glu_data.date_
#                     from 
#                         LIVE.scheduled_final sched_glu_data 
#                     left outer join LIVE.pre_replace_study as prereplace_study
#                     on (
#                         sched_glu_data.reader_uuid = prereplace_study.reader_uuid 
#                         and sched_glu_data.factory_recorded = prereplace_study.factory_recorded_pr
#                     )
#         """)


@dlt.table(name=scheduled_table_name + "GOLD",
  comment="gold scheduled",
  schema=gold_schema.scheduled_schema) 
def scheduled_gold():
    df = spark.sql(f"""
        SELECT 
            sched.sched_glucose_id, 
            sched.device_id, 
            sched.sensor_no, 
            sched.sensor_id, 
            CAST(sched.upload_id as bigint), 
            CAST(sched.irregular_reading as boolean), 
            sched.value_mgdl, 
            CAST(sched.user_recorded as timestamp), 
            CAST(sched.user_rec_hour as smallint),
            CAST(sched.factory_recorded as timestamp), 
            CAST(sched.factory_rec_hour as smallint), 
            sched.wear_day, 
            sched.calendar_day, 
            CAST(sched.first_last_calendar_day_ind as boolean), 
            CAST(sched.first_after_activation as boolean), 
            CAST(sched.first_after_time_change as boolean),
            sched.usage_day, 
            sched.ownership_day, 
            CAST(sched.read_in_target_flg as boolean),  
            CAST(sched.read_above_target_flg as boolean), 
            CAST(sched.read_below_target_flg as boolean), 
            sched.irregular_sensor, 
            sched.reader_uuid, 
            sched.country,
            CAST(sched.date_ as date)
        FROM 
            LIVE.scheduled_final SCHED
        """)
    return df.withColumnRenamed("date_", "first_processed_date")
    
