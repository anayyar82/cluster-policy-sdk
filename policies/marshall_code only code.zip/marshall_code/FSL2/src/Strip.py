# Databricks notebook source
from pyspark.sql.functions import col, lit, from_unixtime, unix_timestamp, monotonically_increasing_id, hour, date_format, to_timestamp

import dlt
import bronze_schema
import gold_schema

from variables_orig import *
from data_quality import *

# COMMAND ----------

# MAGIC %md # Bronze Table

# COMMAND ----------

#Creating original table
@dlt.table(temporary=temporary)
@dlt.expect_all_or_drop(strip_input_rules)
def strip_input():
    df = (spark.read
            .table(f"`{dmz_catalog}`.`{input_schema}`.`{strip_table_name[:-1]}`")
            .where(col("uploaddate").between(start_date, end_date))
    )              
    return df.withColumn("date_", lit(snapshot_date))


@dlt.table(temporary=temporary)
def strip_history():
    query = f"SHOW TABLES IN `{history_catalog}`.`{history_schema}` LIKE '{strip_table_name[:-1]}'"
    result = spark.sql(query).collect()
    if result:
        return (spark.read
                .table(f'`{history_catalog}`.`{history_schema}`.`{strip_table_name[:-1]}`')
        )
    else:
          return spark.createDataFrame([], schema=bronze_schema.strip_schema)


#@dlt.view()
@dlt.table(temporary=temporary)
def strip_combined():
    return spark.sql("SELECT * from LIVE.strip_input UNION SELECT * from LIVE.strip_history;")

#@dlt.view()
@dlt.table(temporary=temporary)
def strip_dedup():
    df = spark.sql(f"SELECT * from LIVE.strip_combined ORDER BY deviceuuid ASC, factoryRecorded ASC, uploadsequence ASC, date_ ASC;")
    return df.dropDuplicates(subset=['deviceuuid', 'factoryrecorded'])


#@dlt.view()
@dlt.table(temporary=temporary)
def strip_blacklist():
    return spark.sql("select a.* from live.strip_dedup as a LEFT Join live.bronze_blacklist_account as b on a.accountid = b.accountid where b.accountId is null")


@dlt.view(name=strip_table_name + "BRONZE")
def strip_threshold():
    return spark.sql("""SELECT a.* from live.strip_blacklist as a WHERE a.accountid in (
        SELECT accountid from live.accounts_greater_than_threshold where accountid is not null
    )""")


@dlt.table(
  name=strip_table_name + "BRONZE_HISTORY",
  comment="combined strip",
  schema=bronze_schema.strip_schema,
  temporary=temporary)
def strip_update_history():
    df=spark.sql(f"select * from live.{strip_table_name}BRONZE where date_ = '{snapshot_date}' ")
        
    df.write.mode("append").format("delta")\
        .option('nullValue', None)\
        .option("mergeSchema", "false")\
        .saveAsTable(f"`{marshall_catalog}`.`{history_schema}`.`{strip_table_name[:-1]}`")

    
    return df


# COMMAND ----------

# MAGIC %md # Silver Table

# COMMAND ----------

#@dlt.view()
@dlt.table(temporary=temporary)
def strip_filtered():
    #Formating Time
    time_df = spark.sql(f"select  if  (instr(right(userrecorded,6), '+') > 0 or instr(right(userrecorded,6), '-') > 0 , substr(userrecorded,0,length(userrecorded)-6) , userrecorded) as userrecorded_modified, * from LIVE.{strip_table_name}BRONZE")

    time_df = time_df.drop("userrecorded") \
                    .withColumnRenamed("userrecorded_modified", "userrecorded") \
                    .withColumn('userrecorded', to_timestamp(col('userRecorded'))) \
                    .withColumn('factoryrecorded', to_timestamp(col('factoryrecorded')))
    return time_df

@dlt.table(
  name=strip_table_name + "SILVER",
  comment="silver strip",
  temporary=temporary)
def food_silver():
    new_df = spark.sql("SELECT * from LIVE.strip_filtered;")
    new_df = new_df \
                        .withColumn("factoryrechour", hour(new_df.factoryrecorded)) \
                        .withColumn("userrechour", hour(new_df.userrecorded))

    new_df = new_df.withColumnRenamed("deviceuuid", "reader_uuid") \
                    .withColumnRenamed("devicenationality", "country") \
                    .withColumnRenamed("uploadsequence", "upload_id") \
                    .withColumnRenamed("firmwareversion", "firmware")      

    new_df.orderBy(new_df['reader_uuid'].asc(), new_df['factoryrecorded'].asc())
    
    return new_df


# COMMAND ----------

# MAGIC %md # Gold Table

# COMMAND ----------

@dlt.table(
  name=strip_table_name + "GLUCOSE_READING_GOLD",
  comment="gold strip",
  schema=gold_schema.strip_schema)
def strip_gold():
    results_strip_df = spark.sql("""
        SELECT 
            d.device_id,
            CASE
                WHEN unix_timestamp(st.factoryRecorded, 'yyyy-MM-dd HH:mm:ss') BETWEEN unix_timestamp(s.FIRST_SCHED_FACTORY_READING, 'yyyy-MM-dd HH:mm:ss') AND unix_timestamp(s.LAST_SCHED_FACTORY_READING, 'yyyy-MM-dd HH:mm:ss') 

                THEN TRUE
                ELSE FALSE
                END
            as active_sensor_ind,
            s.sensor_no,
            s.sensor_id,
            CAST(st.upload_id as bigint), 
            ROUND(st.mgdl, 0) as value_mgdl, 
            CAST(st.userRecorded as timestamp) as user_recorded, 
            CAST(st.userRecHour as smallint) as user_rec_hour,
            CAST(st.factoryrecorded as timestamp) as factory_recorded, 
            CAST(st.FactoryRecHour as smallint) as factory_rec_hour,
            cast(((int(unix_timestamp(st.factoryRecorded, 'yyyy-MM-dd HH:mm:ss')/60) - int(unix_timestamp(s.first_sched_factory_reading, 'yyyy-MM-dd HH:mm:ss')/60))/1440) + 1 as int) as wear_day,

            datediff(st.factoryRecorded, s.first_sched_factory_reading) + 1 calendar_day, 
            u.use_day as usage_day,

            datediff(st.factoryRecorded, d.first_sched_factory_reading) as ownership_day,

            CASE
                WHEN DAY(st.factoryRecorded) = DAY(S.FIRST_SCHED_FACTORY_READING) 
                THEN TRUE
                WHEN DAY(st.factoryRecorded) = DAY(S.LAST_SCHED_FACTORY_READING) 
                THEN TRUE
                ELSE FALSE 
                END 
            as first_last_calendar_day_ind,
            st.reader_uuid, 
            st.country,
            CAST(st.date_ as date)
        FROM 
            LIVE.STRIP_SILVER st 
        INNER JOIN LIVE.DEVICE_SETTINGS_SILVER d 
        ON st.reader_uuid = d.reader_uuid
        LEFT OUTER JOIN LIVE.SENSOR_SILVER s 
        ON st.reader_uuid = s.reader_uuid 

        AND unix_timestamp(st.factoryRecorded, 'yyyy-MM-dd HH:mm:ss') BETWEEN unix_timestamp(s.FIRST_SCHED_FACTORY_READING, 'yyyy-MM-dd HH:mm:ss') AND unix_timestamp(s.LAST_SCHED_FACTORY_READING, 'yyyy-MM-dd HH:mm:ss')

        LEFT OUTER JOIN LIVE.useday_filtered u ON st.reader_uuid = u.reader_uuid and to_date(st.factoryRecorded) = to_date(u.factoryRecorded)
    """)

    df = results_strip_df.withColumn("strip_glucose_id", monotonically_increasing_id())
    return df.withColumnRenamed("date_", "first_processed_date")
