""" Superior Input Data Quality Constraints for Marshall DLT Expectations"""
# DeviceSettings
device_input_rules = {}
#   NULL / BLANK check on [systemtype, modelname (fsl3), firmwareversion, reader_nationality]
device_input_rules["valid_systemtype"] = "systemtype IS NOT NULL AND systemtype != ''"
device_input_rules["valid_firmwareversion"]  = "firmwareversion IS NOT NULL AND firmwareversion != ''"
device_input_rules["valid_reader_nationality"]  = "devicenationality IS NOT NULL AND devicenationality != ''"

# ScheduledGlucose
scheduled_input_rules = {}
#   NULL / BLANK check on [factoryrecorded, userrecorded, mgdl, sensoruid, sensoruidcorrected, firstaftertimechange]
#   Note: factoryrecorded & userrecorded are handled in Superior
scheduled_input_rules["valid_mgdl"] = "mgdl IS NOT NULL"
scheduled_input_rules["valid_sensoruid"] = "sensoruid IS NOT NULL AND sensoruid != ''"
scheduled_input_rules["valid_sensoruidcorrected"] = "sensoruidcorrected IS NOT NULL AND sensoruidcorrected != ''"
#scheduled_input_rules["valid_firstaftertimechange"] = "firstaftertimechange IS NOT NULL AND firstaftertimechange != ''"

# UnscheduledGlucose
unscheduled_input_rules = {}
#   NULL / BLANK check on [factoryrecorded, userrecorded, mgdl, actionable, trendarrow, 
#                          firstaftertimechange (fsl3), viewed (fsl3), streaming? (fsl3)]
#   Note: factoryrecorded & userrecorded are handled in Superior
unscheduled_input_rules["valid_mgdl"] = "mgdl IS NOT NULL"
unscheduled_input_rules["valid_actionable"] = "actionable IS NOT NULL"
unscheduled_input_rules["valid_trendarrow"] = "trendarrow IS NOT NULL AND trendarrow != ''"

# Food
food_input_rules = {}
#   NULL / BLANK check on 
#      [factoryrecorded, userrecorded, mealname, numberofservings? (fsl3), sensoruid? (fsl3)]
#   Note: factoryrecorded & userrecorded are handled in Superior

food_input_rules["valid_mealname"] = "mealname IS NOT NULL"
# food_input_rules["valid_numberofservings"] = "numberofservings IS NOT NULL" (FSL3 field)

# Generic
generic_input_rules = {}
#   NULL / BLANK check on [factoryrecorded, userrecorded, type, latejoined (fsl3), streaming (fsl3)] (in general)
#   Note: factoryrecorded & userrecorded are handled in Superior
generic_input_rules["valid_type"] = "type IS NOT NULL"

#   NULL / BLANK check on [value] IF type is ‘temperature’
generic_input_rules["valid_value_when_temperature"] = "(type == 'temperature' AND value IS NOT NULL) OR (type != 'temperature')"

#   NULL / BLANK check on  
#       [lowglucosethresholdinmgdl, highglucosethresholdinmgdl, islowglucoseenabled, ishighglucoseenabled,issignallossalarmenabled]
#       IF type is ‘alarmSetting’
generic_input_rules["valid_lowglucosethreshold"] = """
    (type == 'alarmSetting' AND lowglucosethresholdinmgdl IS NOT NULL AND lowglucosethresholdinmgdl != '') OR (type != 'alarmSetting')
"""
generic_input_rules["valid_highglucosethreshold"] = """
    (type == 'alarmSetting' AND highglucosethresholdinmgdl IS NOT NULL AND highglucosethresholdinmgdl != '') OR (type != 'alarmSetting')
"""
generic_input_rules["valid_islowglucoseenabled"] = "(type == 'alarmSetting' AND islowglucoseenabled IS NOT NULL) OR (type != 'alarmSetting')"
generic_input_rules["valid_ishighglucoseenabled"] = "(type == 'alarmSetting' AND ishighglucoseenabled IS NOT NULL) OR (type != 'alarmSetting')"
generic_input_rules["valid_issignallossalarmenabled"] = "(type == 'alarmSetting' AND issignallossalarmenabled IS NOT NULL) OR (type != 'alarmSetting')"

#   NULL / BLANK check on [
#   fixedlowglucosealarmisinepisode,
#   fixedlowglucosealarmiscleared,
#   fixedlowglucosealarmisusercleared (fsl3),
#   fixedlowglucosealarmispresented,
#   fixedlowglucosealarmisdismissed,
#   lowglucosealarmisinepisode,
#   lowglucosealarmiscleared,
#   lowglucosealarmisusercleared (fsl3),
#   lowglucosealarmispresented,
#   lowglucosealarmisdismissed,
#   highglucosealarmisinepisode,
#   highglucosealarmiscleared,
#   highglucosealarmisusercleared (fsl3),
#   highglucosealarmispresented,
#   highglucosealarmisdismissed,
#   signallossalarmisinepisode,
#   signallossalarmiscleared,
#   signallossalarmisusercleared (fsl3),
#   signallossalarmispresented,
#   signallossalarmisautodismissed,
#   signallossalarmisuserdismissed] IF type is ‘isfGlucoseAlarm’
generic_input_rules["valid_fixedlowglucosealarmisinepisode"] = "(type == 'isfGlucoseAlarm' AND fixedlowglucosealarmisinepisode IS NOT NULL) OR (type != 'isfGlucoseAlarm')"
generic_input_rules["valid_fixedlowglucosealarmiscleared"] = "(type == 'isfGlucoseAlarm' AND fixedlowglucosealarmiscleared IS NOT NULL) OR (type != 'isfGlucoseAlarm')"
generic_input_rules["valid_fixedlowglucosealarmispresented"] = "(type == 'isfGlucoseAlarm' AND fixedlowglucosealarmispresented IS NOT NULL) OR (type != 'isfGlucoseAlarm')"
generic_input_rules["valid_fixedlowglucosealarmisdismissed"] = "(type == 'isfGlucoseAlarm' AND fixedlowglucosealarmisdismissed IS NOT NULL) OR (type != 'isfGlucoseAlarm')"

generic_input_rules["valid_lowglucosealarmisinepisode"] = "(type == 'isfGlucoseAlarm' AND lowglucosealarmisinepisode IS NOT NULL) OR (type != 'isfGlucoseAlarm')"
generic_input_rules["valid_lowglucosealarmiscleared"] = "(type == 'isfGlucoseAlarm' AND lowglucosealarmiscleared IS NOT NULL) OR (type != 'isfGlucoseAlarm')"
generic_input_rules["valid_lowglucosealarmispresented"] = "(type == 'isfGlucoseAlarm' AND lowglucosealarmispresented IS NOT NULL) OR (type != 'isfGlucoseAlarm')"
generic_input_rules["valid_lowglucosealarmisdismissed"] = "(type == 'isfGlucoseAlarm' AND lowglucosealarmisdismissed IS NOT NULL) OR (type != 'isfGlucoseAlarm')"

generic_input_rules["valid_highglucosealarmisinepisode"] = "(type == 'isfGlucoseAlarm' AND highglucosealarmisinepisode IS NOT NULL) OR (type != 'isfGlucoseAlarm')"
generic_input_rules["valid_highglucosealarmiscleared"] = "(type == 'isfGlucoseAlarm' AND highglucosealarmiscleared IS NOT NULL) OR (type != 'isfGlucoseAlarm')"
generic_input_rules["valid_highglucosealarmispresented"] = "(type == 'isfGlucoseAlarm' AND highglucosealarmispresented IS NOT NULL) OR (type != 'isfGlucoseAlarm')"
generic_input_rules["valid_highglucosealarmisdismissed"] = "(type == 'isfGlucoseAlarm' AND highglucosealarmisdismissed IS NOT NULL) OR (type != 'isfGlucoseAlarm')"

generic_input_rules["valid_signallossalarmisinepisode"] = "(type == 'isfGlucoseAlarm' AND signallossalarmisinepisode IS NOT NULL) OR (type != 'isfGlucoseAlarm')"
generic_input_rules["valid_signallossalarmiscleared"] = "(type == 'isfGlucoseAlarm' AND signallossalarmiscleared IS NOT NULL) OR (type != 'isfGlucoseAlarm')"
generic_input_rules["valid_signallossalarmispresented"] = "(type == 'isfGlucoseAlarm' AND signallossalarmispresented IS NOT NULL) OR (type != 'isfGlucoseAlarm')"
generic_input_rules["valid_signallossalarmisautodismissed"] = "(type == 'isfGlucoseAlarm' AND signallossalarmisautodismissed IS NOT NULL) OR (type != 'isfGlucoseAlarm')"
generic_input_rules["valid_signallossalarmisuserdismissed"] = "(type == 'isfGlucoseAlarm' AND signallossalarmisuserdismissed IS NOT NULL) OR (type != 'isfGlucoseAlarm')"

#   NULL / BLANK check on [puckgen (fsl3), wearduration (fsl3), sensoruid (fsl3) ] IF type is ‘sensorstart’
#   Not Applicable for now

# Insulin
insulin_input_rules = {}
#   NULL/BLANK check on [factoryrecorded, userrecorded, units, type, sensoruid? (fsl3)]
#   Note: factoryrecorded & userrecorded are handled in Superior
insulin_input_rules["valid_units"] = "units IS NOT NULL"
insulin_input_rules["valid_type"] = "type IS NOT NULL"

# Ketone
ketone_input_rules = {}
#   NULL/BLANK check on [factoryrecorded, userrecorded, valuemmol]
#   Note: factoryrecorded & userrecorded are handled in Superior
ketone_input_rules["valid_valuemmol"] = "valuemmol IS NOT NULL"

# Strip
strip_input_rules = {}
#   NULL / BLANK check on [factoryrecorded, userrecorded, mgdl]
#   Note: factoryrecorded & userrecorded are handled in Superior
strip_input_rules["mgdl"] = "mgdl IS NOT NULL"

# InsulinDeviceData
insulin_device_data_input_rules = {}
#   Invalid attribute should be False (invalid = TRUE, then we don't want that record right?)
#   validate_iso on [localtimestamp, utctimestamp]
#   Note: localtimestamp & utctimestamp are handled in Superior
insulin_device_data_input_rules["valid_invalid"] = "invalid = FALSE"