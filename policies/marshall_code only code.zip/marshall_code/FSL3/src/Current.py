# Databricks notebook source
from pyspark.sql.functions import hour, to_timestamp, col, lit, expr, monotonically_increasing_id

import dlt
import bronze_schema
import gold_schema

from variables_orig import *
from data_quality_gold import *
from data_quality import *

# COMMAND ----------

# MAGIC %md # Bronze Table

# COMMAND ----------

#Creating original table
@dlt.table(temporary=temporary)
@dlt.expect_all_or_drop(unscheduled_input_rules)
def current_input():
    df = (spark.read
            .table(f"`{dmz_catalog}`.`{input_schema}`.`current`")
            .where(col("uploaddate").between(start_date, end_date))
    )          
    return df.withColumn("date_", lit(snapshot_date))

@dlt.table(temporary=temporary)
def current_history():
    query = f"SHOW TABLES IN `{history_catalog}`.`{history_schema}` LIKE 'current'"
    result = spark.sql(query).collect()
    if result:
        return (spark.read
                .table(f'`{history_catalog}`.`{history_schema}`.`current`')
        )
    else:
          return spark.createDataFrame([], schema=bronze_schema.current_schema)
        
@dlt.view()
#@dlt.table(temporary=temporary)
def current_combined():
    return spark.sql("SELECT * from LIVE.current_input UNION SELECT * from LIVE.current_history;")

@dlt.view()
#@dlt.table(temporary=temporary)
def current_dedup():
    df = spark.sql(f"SELECT * from LIVE.current_combined ORDER BY deviceuuid ASC, factoryRecorded ASC, uploadsequence ASC, date_ ASC;")
    return df.dropDuplicates(subset=['deviceUUID', 'factoryrecorded'])

@dlt.view()
#@dlt.table(temporary=temporary)
def current_blacklist():
    return spark.sql("select a.* from live.current_dedup as a LEFT Join live.bronze_blacklist_account as b on a.accountid = b.accountid where b.accountId is null")

@dlt.view(
    name=current_table_name + "BRONZE"
)
def current_threshold():
    return spark.sql("""SELECT a.* from live.current_blacklist as a WHERE a.accountid in (
        SELECT accountid from live.accounts_greater_than_threshold where accountid is not null
    )""")


@dlt.table(
  name=current_table_name + "BRONZE_HISTORY",
  comment="combined current",
  temporary=temporary)
def current_update_history():
    df = spark.sql(f"select * from live.{current_table_name}BRONZE where date_ = '{snapshot_date}' ")

    df.write.mode("append").format("delta")\
        .option('nullValue', None)\
        .option("mergeSchema", "false")\
        .saveAsTable(f"`{marshall_catalog}`.`{history_schema}`.`current`")
    
    return df


# COMMAND ----------

# MAGIC %md # Silver Table

# COMMAND ----------

@dlt.view
#@dlt.table(temporary=temporary)
def current_filtered():
    #Formating Time
    time_df = spark.sql(f"select  if  (instr(right(userrecorded,6), '+') > 0 or instr(right(userrecorded,6), '-') > 0 , substr(userrecorded,0,length(userRecorded)-6) , userRecorded) as userRecorded_modified, * from LIVE.CURRENT_GLUCOSE_READING_BRONZE")

    time_df = time_df.drop("userrecorded") \
                    .withColumnRenamed("userrecorded_modified", "userrecorded") \
                    .withColumn('userrecorded', to_timestamp(col('userRecorded'))) \
                    .withColumn('factoryrecorded', to_timestamp(col('factoryrecorded')))
    return time_df

@dlt.table(
  name=current_table_name + "SILVER",
  comment="silver current",
  temporary=temporary)
def current_silver():
    new_df = spark.sql("SELECT * from LIVE.current_filtered;")
    new_df = new_df \
                        .withColumn("factoryrechour", hour(new_df.factoryrecorded)) \
                        .withColumn("userrechour", hour(new_df.userrecorded)) \
                        .withColumn("uploadSequence" ,col('uploadSequence').cast('long'))\
                        .withColumn("factoryrecorded" ,col('factoryrecorded').cast('timestamp'))
    new_df = new_df.withColumnRenamed("deviceUUID", "reader_uuid") \
                                        .withColumnRenamed("deviceNationality", "country") \
                                        .withColumnRenamed("uploadSequence", "upload_id") \
                                        .withColumnRenamed("firmwareVersion", "firmware")      
    new_df.orderBy(new_df['reader_uuid'].asc(), new_df['factoryrecorded'].asc())
    
    return new_df


# COMMAND ----------

# MAGIC %md # Gold Table

# COMMAND ----------

# This will get us the sensor_uid, and then we can get the first_after_activation right after
#@dlt.view
@dlt.table(temporary=temporary)
def current_prepared():
    results_current_df = spark.sql(
        """
        select
            device_id,
            sensor_no,
            sensor_id,
            sensor_uid,
            upload_id,
            CAST(irregular_reading as BOOLEAN),
            ROUND(value_mgdl, 0) as value_mgdl,
            user_recorded,
            CAST(user_rec_hour as SMALLINT),
            factory_recorded,
            CAST(factory_rec_hour as SMALLINT),
            wear_day,
            calendar_day,
            -- first_after_activation,
            first_after_time_change,
            CAST(usage_day as SMALLINT),
            CAST(ownership_day as SMALLINT),
            high_out_of_range, 
            low_out_of_range,
            is_viewed,
            is_actionable,
            is_streaming,
            trend_arrow,
            reader_uuid,
            firmware_version,
            country,
            first_processed_date
            from (
                select
                    device.device_id as device_id,
                    device.reader_uuid as reader_uuid,
                    device.firmware as firmware_version,
                    current_glucose.country,
                    sensor.sensor_no as sensor_no,
                    sensor.sensor_id as sensor_id,
                    sensor.sensor_uid as sensor_uid,
                    current_glucose.upload_id,
                    case 
                        when (int((int(unix_timestamp(current_glucose.factoryRecorded)/60) - int(unix_timestamp(sensor.first_sched_factory_reading)/60))/(1440)) + 1)  > 14 
                        then 1 
                        else 0 
                    end as irregular_reading,

                    current_glucose.mgdl as value_mgdl,
                    current_glucose.userrecorded as user_recorded,
                    current_glucose.userRecHour as user_rec_hour,
                    current_glucose.factoryRecorded as factory_recorded,
                    current_glucose.factoryRecHour as factory_rec_hour,
                    
                    cast(((int(unix_timestamp(current_glucose.factoryRecorded)/60) - int(unix_timestamp(sensor.first_sched_factory_reading)/60))/(1440)) + 1 as int) as wear_day,

                    datediff(to_date(current_glucose.factoryRecorded), to_date(sensor.first_sched_factory_reading)) + 1 as calendar_day,
                    -- a.firstafteractivation as first_after_activation,
                    current_glucose.firstaftertimechange as first_after_time_change,
                    useday.use_day as usage_day,
                    datediff(to_date(current_glucose.factoryRecorded), to_date(device.first_sched_factory_reading)) as ownership_day,
                    current_glucose.highoutofrange as high_out_of_range, 
                    current_glucose.lowoutofrange as low_out_of_range,
                    current_glucose.viewed as is_viewed,
                    current_glucose.actionable as is_actionable,
                    current_glucose.streaming as is_streaming,
                    current_glucose.trendarrow AS trend_arrow,
                    CAST(current_glucose.date_ as date) as first_processed_date
                from 
                    LIVE.CURRENT_GLUCOSE_READING_SILVER as current_glucose 
                inner join LIVE.DEVICE_SETTINGS_SILVER as device 
                on current_glucose.reader_uuid = device.reader_uuid
                left outer join LIVE.useday_filtered as useday 
                on (
                    current_glucose.reader_uuid = useday.reader_uuid 
                    and to_date(current_glucose.factoryRecorded) = to_date(useday.factoryRecorded)
                )
                inner join LIVE.SENSOR_SILVER as sensor 
                on (
                    device.device_id = sensor.device_id 
                    and unix_timestamp(current_glucose.factoryRecorded) between 
                        unix_timestamp(sensor.first_sched_factory_reading) 
                        and 
                        unix_timestamp(sensor.last_sched_factory_reading)
                )                
                order by device.reader_uuid, sensor.sensor_no, current_glucose.factoryRecorded
            )
        """)

    return results_current_df.withColumn("current_glucose_id", monotonically_increasing_id())


# ==THIS TABLE IS CURRENTLY COMMENTED OUT DUE TO BEING OUT OF SCOPE FOR VERSION 1.1.0, BUT WILL RETURN IN A FUTURE RELEASE==

# @dlt.view
# #@dlt.table(temporary=temporary)
# def current_first_activation():
#     df = spark.sql(f"""
#         select *,
#         false as first_after_activation,
#         lag(c.sensor_uid) over (partition by reader_uuid,sensor_uid order by reader_uuid,factory_recorded,sensor_uid) as previous_sensor_id 
#         from LIVE.current_prepared as c
#     """) 

#     df = df.withColumn("first_after_activation", 
#                 expr("case when previous_sensor_id = sensor_uid then false else true end"))
    
#     return df

# COMMAND ----------

#add dataframe for scheduled_glucose firstafteractivation logic
#need to add back in current_glucose.firstafteractivation as first_after_activation
###########################


@dlt.view()
def ondemand_alarms():
    return spark.sql("""
        select 
            factoryrecorded,
            userrecorded,
            reader_uuid,
            max((case When "type" ='low' then 1 else 0 end)) as ondemand_low_alarm,
            max((case When "type" ='high' then 1 else 0 end)) as ondemand_high_alarm,
            max((case When "type" ='projectedlow' then 1 else 0 end)) as ondemand_projected_low_alarm,
            max((case When "type" ='projectedhigh' then 1 else 0 end)) as ondemand_projected_high_alarm
        from (
            select 
                factoryrecorded,
                userrecorded,
                reader_uuid, 
                "type"
            from
                LIVE.GENERIC_SILVER 
            where "type" in ('low','high','projectedlow','projectedhigh')
        ) as ondemandalarms
        group by factoryrecorded,userrecorded,reader_uuid
    """)


@dlt.table(name=current_table_name + "GOLD",
  comment="gold current",
  schema=gold_schema.current_schema
)
#@dlt.expect_all_or_drop(current_glucose_reading)
def current_gold(): 
    return spark.sql("""
        select 
            current_glucose.* , 
            CAST(ondemand_low_alarm as BOOLEAN),
            CAST(ondemand_high_alarm as BOOLEAN),
            CAST(ondemand_projected_low_alarm as BOOLEAN),
            CAST(ondemand_projected_high_alarm as BOOLEAN)
        from 
            -- This used to be current_first_activation, however that column should be found in scheduled. 
            LIVE.current_prepared as current_glucose
        left join LIVE.ondemand_alarms 
        on current_glucose.reader_uuid = ondemand_alarms.reader_uuid 
        and current_glucose.factory_recorded = ondemand_alarms.factoryrecorded
    """)
