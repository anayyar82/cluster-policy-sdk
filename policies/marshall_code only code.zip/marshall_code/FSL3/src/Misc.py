# Databricks notebook source
from pyspark.sql.functions import monotonically_increasing_id
from pyspark.sql.types import BooleanType

import dlt
import bronze_schema
import gold_schema
from variables_orig import *
from data_quality import *
from data_quality_gold import *

# COMMAND ----------

# MAGIC %md
# MAGIC ###Survey
# MAGIC

# COMMAND ----------

surveyinput = spark.conf.get("survey").lower()
survey = eval("surveyinput == 'true'")
temporary_survey = not survey


@dlt.table(name = 'SURVEY_QUESTIONS_GOLD' if not temporary_survey else 'SURVEY_QUESTIONS_EMPTY',
    temporary = temporary_survey)
def load_survey_questions():
    if survey:
        return spark.read.table(f"`{marshall_catalog}`.`{misc_schema}`.`survey-questions`")
    else:
        return spark.createDataFrame([], bronze_schema.survey_questions)

@dlt.table(name = 'SURVEY_RESPONSES_GOLD' if not temporary_survey else 'SURVEY_RESPONSES_EMPTY',
           temporary = temporary_survey)
def load_survey_responses():
    if survey:
        return spark.read.table(f"`{marshall_catalog}`.`{misc_schema}`.`survey-responses`")
    else:
        return spark.createDataFrame([], bronze_schema.survey_responses)

    

# COMMAND ----------

# MAGIC %md
# MAGIC ###Medication

# COMMAND ----------


@dlt.table(name="MEDICATION_GOLD",
  comment="gold medication"
#   schema=gold_schema.medication_schema
)
#@dlt.expect_all_or_drop(medication)
def medication():
    m =  spark.sql("""
            select 
                device.device_id,
                extended.firmwareversion as firmware_version,
                extended.sensoruid as sensor_uid,
                sensor.sensor_id, 
                sensor.sensor_no,
                CAST(extended.upload_id as BIGINT), 
                extended.userrecorded as user_recorded,
                CAST(extended.userRecHour as SMALLINT) as user_rec_hour,
                extended.factoryrecorded as factory_recorded, 
                CAST(extended.factoryRecHour as SMALLINT) as factory_rec_hour,

                cast(((int(unix_timestamp(extended.factoryRecorded)/60) - int(unix_timestamp(sensor.first_sched_factory_reading)/60))/1440) + 1 as int) as wear_day,
                datediff(to_date(extended.factoryRecorded), to_date(sensor.first_sched_factory_reading)) + 1 as calendar_day, 
                u.use_day as usage_day,
                datediff(to_date(extended.factoryRecorded), to_date(device.first_sched_factory_reading)) as ownership_day,

                extended.reader_uuid,
                extended.country,
                cast(device.date_ as date) as first_processed_date --change made june 5th2024 AB
            from 
                live.GENERIC_SILVER extended
            inner join live.DEVICE_SETTINGS_SILVER device 
            on device.reader_uuid = extended.reader_uuid 
            left outer join live.SENSOR_SILVER sensor 
            on sensor.device_id = device.device_id 
            and 
                unix_timestamp(extended.factoryRecorded) between 
                    unix_timestamp(sensor.first_sched_factory_reading) 
                    and 
                    unix_timestamp(sensor.last_sched_factory_reading)
            left outer join live.useday_filtered u 
            on (extended.reader_uuid = u.reader_uuid and to_date(extended.factoryRecorded) = to_date(u.factoryRecorded))
            where extended.type = 'medication'
    """ )

    medication_with_id = m.withColumn("medication_id", monotonically_increasing_id())
    return medication_with_id

# COMMAND ----------

# MAGIC %md
# MAGIC ###Alarm Settings(Gold)

# COMMAND ----------

@dlt.table(
  name="ALARM_SETTING_GOLD",
  comment="gold alarm_settings",
  schema=gold_schema.alarm_settings_schema
)
#@dlt.expect_all_or_drop(alarm_setting)
def alarm_settings_fsl3():
    a = spark.sql("""
            select 
                device.device_id, 
                sensor.sensor_id,
                sensor.sensor_no,
                sensor.sensor_uid,
                generic_enriched.reader_uuid,
                generic_enriched.firmwareversion as firmware_version,
                generic_enriched.country as country,
                CAST(generic_enriched.upload_id as BIGINT),
                CAST(generic_enriched.userRecorded as TIMESTAMP) as user_recorded, 
                CAST(generic_enriched.userRecHour as SMALLINT) as user_rec_hour,
                CAST(generic_enriched.factoryRecorded as TIMESTAMP) as factory_recorded, 
                CAST(generic_enriched.factoryRecHour as SMALLINT) as factory_rec_hour,
                configurationChangeSource as configuration_change_source, 
                CAST(round(nvl(highGlucoseThresholdInMgDl,0),0) as INTEGER) as high_glucose_threshold_in_mgdl, 
                CAST(round(nvl(lowGlucoseThresholdInMgDl,0),0) as INTEGER)  as low_glucose_threshold_in_mgdl,
                CAST(isAlarmNotificationEnabled as BOOLEAN) as is_alarm_notification_enabled,
                CAST(isAlarmSoundEnabled as BOOLEAN) as is_alarm_sound_enabled, 
                CAST(isHighGlucoseEnabled as BOOLEAN) as is_high_glucose_enabled,
                CAST(isLowGlucoseEnabled as BOOLEAN) as is_low_glucose_enabled, 
                CAST(isSignalLossAlarmEnabled as BOOLEAN) as  is_signal_loss_alarm_enabled,
                CAST(device.date_ as DATE) as first_processed_date --change made june 5th2024 AB
            from 
                live.GENERIC_SILVER generic_enriched
            inner join live.DEVICE_SETTINGS_SILVER device 
            on device.reader_uuid =  generic_enriched.reader_uuid and type ='alarmSetting'
            left outer join live.SENSOR_SILVER sensor
            on sensor.device_id = device.device_id
                and unix_timestamp(generic_enriched.factoryRecorded) between 
                unix_timestamp(sensor.first_sched_factory_reading) 
                and unix_timestamp(sensor.last_sched_factory_reading)
        """)
    alarm_settings = a.withColumn("alarm_setting_id", monotonically_increasing_id())
    return alarm_settings

# COMMAND ----------

# MAGIC %md
# MAGIC ###Skin temperature(Gold)

# COMMAND ----------

@dlt.table(
    name="SKIN_TEMPERATURE_GOLD",
    comment="gold skin_temperature"
    # schema=gold_schema.skin_temperature_schema
)
#@dlt.expect_all_or_drop(skin_temperature)
def skin_temperature_fsl3():
    skin_temperature = spark.sql("""
        select 
            device.device_id, 
            generic_enriched.reader_uuid, 
            sensor.sensor_id,
            sensor.sensor_no,
            sensor.sensor_uid,
            generic_enriched.firmwareversion as firmware_version,
            generic_enriched.country as country,
            CAST(generic_enriched.upload_id as BIGINT),  
            CAST(generic_enriched.userRecorded as TIMESTAMP) as user_recorded,
            CAST(generic_enriched.userRecHour as SMALLINT) as user_rec_hour,   
            CAST(generic_enriched.factoryRecorded as TIMESTAMP) as factory_recorded,
            CAST(generic_enriched.factoryRecHour as SMALLINT) as factory_rec_hour, 
            (generic_enriched.value * .1) as skin_temperature_celsius,
            CAST(device.date_ as DATE) as first_processed_date --change made june 5th2024 AB
        from 
            live.GENERIC_SILVER generic_enriched  
        inner join live.DEVICE_SETTINGS_SILVER device 
        on device.reader_uuid = generic_enriched.reader_uuid and type = 'temperature'
        left outer join live.SENSOR_SILVER sensor
            on sensor.device_id = device.device_id
                and unix_timestamp(generic_enriched.factoryRecorded) between 
                unix_timestamp(sensor.first_sched_factory_reading) 
                and unix_timestamp(sensor.last_sched_factory_reading)

    """)

    skin_temperature_with_id = skin_temperature.withColumn("skin_temperature_id", monotonically_increasing_id())
    return skin_temperature_with_id

# COMMAND ----------

# MAGIC %md
# MAGIC ###isf Alarms(Gold)

# COMMAND ----------

  @dlt.table(name="ISF_GLUCOSE_ALARM_GOLD",
  comment="gold isf_alarms"
#   schema=gold_schema.isf_alarms_schema
)
#@dlt.expect_all_or_drop(ISF_glucose_alarm)
def isf_alarmsettings():
    isf_alarmsettings = spark.sql("""
            select 
                device.device_id, 
                sensor.sensor_id,
                sensor.sensor_no,
                generic_enriched.reader_uuid,
                generic_enriched.firmwareversion as firmware_version,
                generic_enriched.country,
                CAST(generic_enriched.upload_id as BIGINT),
                generic_enriched.sensoruid as sensor_uid,
                CAST(generic_enriched.userRecorded as TIMESTAMP) as user_recorded, 
                CAST(generic_enriched.userRecHour as SMALLINT) as user_rec_hour,
                CAST(generic_enriched.factoryRecorded as TIMESTAMP) as factory_recorded, 
                CAST(generic_enriched.factoryRecHour as SMALLINT) as factory_rec_hour,
                CAST(fixedLowGlucoseAlarmIsInEpisode AS BOOLEAN) as fixed_low_is_in_episode,
                CAST(fixedLowGlucoseAlarmIsCleared AS BOOLEAN) as fixed_low_is_cleared,
                CAST(fixedLowGlucoseAlarmIsDismissed AS BOOLEAN) as fixed_low_is_dismissed,
                CAST(fixedLowGlucoseAlarmIsPresented AS BOOLEAN) as fixed_low_is_presented,
                CAST(fixedlowGlucoseAlarmIsUserCleared AS BOOLEAN) as fixed_low_is_user_cleared,
                CAST(lowGlucoseAlarmIsInEpisode AS BOOLEAN) as low_is_in_episode,
                CAST(lowGlucoseAlarmIsCleared AS BOOLEAN) as low_is_cleared,
                CAST(lowGlucoseAlarmIsDismissed AS BOOLEAN) as low_is_dismissed,
                CAST(lowGlucoseAlarmIsPresented AS BOOLEAN) as low_is_presented,
                CAST(lowGlucoseAlarmIsUserCleared AS BOOLEAN) as low_is_user_cleared,
                CAST(highGlucoseAlarmIsInEpisode AS BOOLEAN) as high_is_in_episode,   
                CAST(highGlucoseAlarmIsCleared AS BOOLEAN) as high_is_cleared,
                CAST(highGlucoseAlarmIsDismissed AS BOOLEAN) as high_is_dismissed,
                CAST(highGlucoseAlarmIsPresented AS BOOLEAN) as high_is_presented,
                CAST(highGlucoseAlarmIsUserCleared AS BOOLEAN) as high_is_user_cleared,
                CAST(signalLossAlarmIsInEpisode AS BOOLEAN) as signal_loss_is_in_episode,
                -- CAST(signalLossAlarmIsCleared AS BOOLEAN) as signal_loss_is_cleared, -- Not in FSL3
                CAST(signalLossAlarmIsUserCleared AS BOOLEAN) as signal_loss_is_user_cleared,
                CAST(signalLossAlarmIsPresented AS BOOLEAN) as signal_loss_is_presented,
                CAST(signalLossAlarmIsAutoDismissed AS BOOLEAN) as signal_loss_is_auto_dismissed,
                CAST(signalLossAlarmIsUserDismissed AS BOOLEAN) as signal_loss_is_user_dismissed,
                CAST(device.date_ as DATE) as first_processed_date --change made june 5th2024 AB
            from 
                live.GENERIC_SILVER generic_enriched
            inner join live.DEVICE_SETTINGS_SILVER device 
            on device.reader_uuid = generic_enriched.reader_uuid 
            and type ='isfGlucoseAlarm'
            inner join live.SENSOR_SILVER sensor
            on sensor.device_id = device.device_id
                and unix_timestamp(generic_enriched.factoryRecorded) between 
                unix_timestamp(sensor.first_sched_factory_reading) 
                and unix_timestamp(sensor.last_sched_factory_reading)
    """)

    return isf_alarmsettings.withColumn("alarm_id", monotonically_increasing_id())

# COMMAND ----------

# MAGIC %md
# MAGIC ###sensor_alarm_coverage (move to future release)

# COMMAND ----------

# #most recent alarm_setting before sensor start
# @dlt.view()
# #@dlt.table(temporary=temporary)
# def alarm_setting_x_config_null():
#     return spark.sql("""
#         SELECT 
#             DEVICE_ID, 
#             FIRMWARE_VERSION, 
#             COUNTRY, 
#             SENSOR_ID,
#             SENSOR_NO, 
#             SENSOR_UID, 
#             READER_UUID, 
#             FACTORY_RECORDED, 
#             IS_ALARM_NOTIFICATION_ENABLED, 
#             IS_ALARM_SOUND_ENABLED, 
#             IS_LOW_GLUCOSE_ENABLED, 
#             IS_HIGH_GLUCOSE_ENABLED, 
#             IS_SIGNAL_LOSS_ALARM_ENABLED, 
#             LOW_GLUCOSE_THRESHOLD_IN_MGDL, 
#             HIGH_GLUCOSE_THRESHOLD_IN_MGDL
#         FROM LIVE.ALARM_SETTING_GOLD
#         WHERE CONFIGURATION_CHANGE_SOURCE=0 or CONFIGURATION_CHANGE_SOURCE IS NULL""")

# @dlt.view()
# #@dlt.table(temporary=temporary)
# def alarm_setting_x_sensor_irregular_sensor():
#     return spark.sql("""
#         SELECT 
#             READER_UUID, 
#             SENSOR_ID, 
#             FIRST_SCHED_FACTORY_READING, 
#             LAST_SCHED_FACTORY_READING 
#         FROM Live.SENSOR_GOLD 
#         WHERE IRREGULAR_SENSOR=false""")

# @dlt.view()
# #@dlt.table(temporary=temporary)
# def alarm_setting_x_sensor(): 
#     return spark.sql("""
#         SELECT 
#             S.READER_UUID, 
#             S.SENSOR_ID, 
#             DEVICE_ID, 
#             FIRMWARE_VERSION, 
#             COUNTRY, 
#             SENSOR_NO, 
#             SENSOR_UID, 
#             S.FIRST_SCHED_FACTORY_READING, 
#             S.LAST_SCHED_FACTORY_READING, 
#             FACTORY_RECORDED, 
#             IS_LOW_GLUCOSE_ENABLED, 
#             IS_HIGH_GLUCOSE_ENABLED, 
#             IS_SIGNAL_LOSS_ALARM_ENABLED, 
#             IS_ALARM_SOUND_ENABLED,
#             IS_ALARM_NOTIFICATION_ENABLED, 
#             LOW_GLUCOSE_THRESHOLD_IN_MGDL, 
#             HIGH_GLUCOSE_THRESHOLD_IN_MGDL 
#         FROM 
#             LIVE.alarm_setting_x_config_null A JOIN LIVE.alarm_setting_x_sensor_irregular_sensor S 
#             ON A.READER_UUID=S.READER_UUID AND A.SENSOR_ID = S.SENSOR_ID
#         ORDER BY READER_UUID, FIRST_SCHED_FACTORY_READING, FACTORY_RECORDED""")

# COMMAND ----------

# @dlt.view()
# #@dlt.table(temporary=temporary)
# def starting_alarm_setting_config_null():
#     return spark.sql("""SELECT 
#         DEVICE_ID, 
#         FIRMWARE_VERSION, 
#         COUNTRY, 
#         SENSOR_ID,
#         SENSOR_NO, 
#         SENSOR_UID, 
#         READER_UUID, 
#         FACTORY_RECORDED, 
#         IS_ALARM_NOTIFICATION_ENABLED, 
#         IS_ALARM_SOUND_ENABLED, 
#         IS_LOW_GLUCOSE_ENABLED, 
#         IS_HIGH_GLUCOSE_ENABLED, 
#         IS_SIGNAL_LOSS_ALARM_ENABLED, 
#         LOW_GLUCOSE_THRESHOLD_IN_MGDL, 
#         HIGH_GLUCOSE_THRESHOLD_IN_MGDL,
#         CONFIGURATION_CHANGE_SOURCE 
#     FROM live.ALARM_SETTING_GOLD
#     WHERE CONFIGURATION_CHANGE_SOURCE=0 or CONFIGURATION_CHANGE_SOURCE IS NULL""")

# @dlt.table(temporary=temporary)
# def starting_alarm_setting_max_factory_recorded():
#     return spark.sql("""
#         SELECT 
#             READER_UUID, 
#             SENSOR_ID, 
#             FIRST_SCHED_FACTORY_READING, 
#             LAST_SCHED_FACTORY_READING, 
#             MAX(FACTORY_RECORDED) AS FACTORY_RECORDED 
#         FROM LIVE.alarm_setting_x_sensor 
#         WHERE FACTORY_RECORDED <= FIRST_SCHED_FACTORY_READING 
#         GROUP BY READER_UUID, SENSOR_ID, FIRST_SCHED_FACTORY_READING, LAST_SCHED_FACTORY_READING""")

# @dlt.view()
# #@dlt.table(temporary=temporary)
# def starting_alarm_setting():
#     return spark.sql("""
#         SELECT 
#             S.READER_UUID, 
#             S.SENSOR_ID, 
#             DEVICE_ID, 
#             FIRMWARE_VERSION, 
#             COUNTRY, 
#             SENSOR_NO, 
#             SENSOR_UID, 
#             S.FIRST_SCHED_FACTORY_READING, 
#             S.LAST_SCHED_FACTORY_READING, 
#             S.FACTORY_RECORDED, 
#             IS_LOW_GLUCOSE_ENABLED, 
#             IS_HIGH_GLUCOSE_ENABLED, 
#             IS_SIGNAL_LOSS_ALARM_ENABLED, 
#             IS_ALARM_SOUND_ENABLED,
#             IS_ALARM_NOTIFICATION_ENABLED, 
#             LOW_GLUCOSE_THRESHOLD_IN_MGDL, 
#             HIGH_GLUCOSE_THRESHOLD_IN_MGDL
#         FROM LIVE.starting_alarm_setting_max_factory_recorded S JOIN LIVE.starting_alarm_setting_config_null A ON S.READER_UUID=A.READER_UUID AND S.FACTORY_RECORDED=A.FACTORY_RECORDED""")

# COMMAND ----------

# MAGIC %md
# MAGIC #### ending_alarm_setting(sensor_alarm_coverage) (future release)

# COMMAND ----------

# @dlt.view()
# #@dlt.table(temporary=temporary)
# def ending_alarm_setting_config_null():
#     return spark.sql("""
#         SELECT 
#             DEVICE_ID, 
#             FIRMWARE_VERSION, 
#             COUNTRY, 
#             SENSOR_ID,
#             SENSOR_NO, 
#             SENSOR_UID, 
#             READER_UUID, 
#             FACTORY_RECORDED, 
#             IS_ALARM_NOTIFICATION_ENABLED, 
#             IS_ALARM_SOUND_ENABLED, 
#             IS_LOW_GLUCOSE_ENABLED, 
#             IS_HIGH_GLUCOSE_ENABLED, 
#             IS_SIGNAL_LOSS_ALARM_ENABLED, 
#             LOW_GLUCOSE_THRESHOLD_IN_MGDL, 
#             HIGH_GLUCOSE_THRESHOLD_IN_MGDL
#         FROM LIVE.ALARM_SETTING_GOLD WHERE CONFIGURATION_CHANGE_SOURCE=0 or CONFIGURATION_CHANGE_SOURCE IS NULL""")

# @dlt.view()
# #@dlt.table(temporary=temporary)
# def ending_max_factory_recorded():
#     return spark.sql("""
#         SELECT 
#             READER_UUID, 
#             SENSOR_ID, 
#             FIRST_SCHED_FACTORY_READING, 
#             LAST_SCHED_FACTORY_READING, 
#             MAX(FACTORY_RECORDED) AS FACTORY_RECORDED 
#         FROM LIVE.alarm_setting_x_sensor
#      WHERE FACTORY_RECORDED <= LAST_SCHED_FACTORY_READING \
#      GROUP BY READER_UUID, SENSOR_ID, FIRST_SCHED_FACTORY_READING, LAST_SCHED_FACTORY_READING""")

# @dlt.view()
# #@dlt.table(temporary=temporary)
# def ending_alarm_setting():
#     return spark.sql("""
#         SELECT 
#             A.READER_UUID, 
#             A.SENSOR_ID, 
#             DEVICE_ID, 
#             FIRMWARE_VERSION, 
#             COUNTRY, 
#             SENSOR_NO, 
#             SENSOR_UID, 
#             S.FIRST_SCHED_FACTORY_READING, 
#             S.LAST_SCHED_FACTORY_READING, 
#             A.FACTORY_RECORDED, 
#             IS_LOW_GLUCOSE_ENABLED, 
#             IS_HIGH_GLUCOSE_ENABLED, 
#             IS_SIGNAL_LOSS_ALARM_ENABLED, 
#             IS_ALARM_SOUND_ENABLED,
#             IS_ALARM_NOTIFICATION_ENABLED, 
#             LOW_GLUCOSE_THRESHOLD_IN_MGDL, 
#             HIGH_GLUCOSE_THRESHOLD_IN_MGDL
#         FROM
#             LIVE.ending_max_factory_recorded S
#             JOIN live.ending_alarm_setting_config_null A
#             ON S.READER_UUID=A.READER_UUID AND S.FACTORY_RECORDED=A.FACTORY_RECORDED""")

# COMMAND ----------

# MAGIC %md
# MAGIC #### sensor_alarm_coverage(GOLD) (Moved to Hypercare)

# COMMAND ----------

# @dlt.table(name='SENSOR_ALARM_COVERAGE',
#            temporary='false')
# @dlt.expect_all_or_drop(sensor_alarm_coverage)
# def sensor_alarm_coverage_gold():
#       sensor_alarm_coverage = spark.sql("SELECT * FROM LIVE.alarm_setting_x_sensor \
#                        UNION SELECT * FROM LIVE.starting_alarm_setting \
#                        UNION SELECT * FROM LIVE.ending_alarm_setting")
#       sensor_alarm_coverage_with_id = sensor_alarm_coverage.withColumn("sensor_alarm_coverage_id", monotonically_increasing_id())
#       return sensor_alarm_coverage_with_id

# COMMAND ----------

# MAGIC %md
# MAGIC ###Timechange (Gold)
# MAGIC

# COMMAND ----------

@dlt.table(
    name="TIME_CHANGE_GOLD",
    comment="gold timechange"
#   schema=gold_schema.timechange_schema
)
#@dlt.expect_all_or_drop(time_change)
def time_change():
    time_change = spark.sql("""
        select 
            device.device_id, 
            generic_enriched.firmwareversion as firmware_version,
            generic_enriched.reader_uuid, 
            generic_enriched.country,
            CAST(generic_enriched.upload_id as BIGINT),
            sensor.sensor_id,
            sensor.sensor_no,
            generic_enriched.sensoruid as sensor_uid,
            CAST(generic_enriched.userRecorded as TIMESTAMP) as user_recorded,
            CAST(generic_enriched.userRecHour as SMALLINT) as user_rec_hour,
            CAST(generic_enriched.factoryRecorded as TIMESTAMP) as factory_recorded, 
            CAST(generic_enriched.factoryRecHour as SMALLINT) as factory_rec_hour,
            CAST(timeDelta as NUMERIC(20,5)) as time_delta,
            CAST(generic_enriched.date_ as DATE) as first_processed_date --change made june 5th2024 AB
        from live.GENERIC_SILVER generic_enriched 
        inner join live.DEVICE_SETTINGS_SILVER device 
        on device.reader_uuid = generic_enriched.reader_uuid 
        and type ='timechange'
        left outer join live.SENSOR_SILVER sensor
        on sensor.device_id = device.device_id
        and unix_timestamp(generic_enriched.factoryRecorded) between 
        unix_timestamp(sensor.first_sched_factory_reading) 
        and unix_timestamp(sensor.last_sched_factory_reading)
    """)
    
    return time_change.withColumn("time_change_id", monotonically_increasing_id())

# COMMAND ----------

# MAGIC %md
# MAGIC ###exercise(gold) 

# COMMAND ----------

@dlt.table(
  name="EXERCISE_GOLD",
  comment="gold exercise"
#   schema=gold_schema.exercise_schema
)
#@dlt.expect_all_or_drop(exercise)
def exercise():
    exercise = spark.sql("""
        select 
            device.device_id,
            sensor.sensor_id, 
            sensor.sensor_no,
            sensor.sensor_uid as sensor_uid,
            extended.firmwareversion as firmware_version, 
            CAST(extended.upload_id as BIGINT),
            CAST(extended.userRecorded as TIMESTAMP) as user_recorded, 
            CAST(extended.userRecHour as SMALLINT) as user_rec_hour, 
            CAST(extended.factoryRecorded as TIMESTAMP) as factory_recorded, 
            CAST(extended.factoryRecHour as SMALLINT) as factory_rec_hour,

            cast(((int(unix_timestamp(extended.factoryRecorded)/60) - int(unix_timestamp(sensor.first_sched_factory_reading)/60))/1440) + 1 as int) as wear_day,

            datediff(to_date(extended.factoryRecorded), to_date(sensor.first_sched_factory_reading)) + 1 as calendar_day, 
            useday.use_day as usage_day,
            datediff(to_date(extended.factoryRecorded), to_date(device.first_sched_factory_reading)) as ownership_day,

            extended.reader_uuid,
            extended.country,
            extended.intensity as intensity,
            cast(extended.durationinminutes as int) as duration_in_minutes,
            CAST(device.date_ as DATE) as first_processed_date --change made june 5th2024 AB
        from 
            live.GENERIC_SILVER extended 
        inner join live.DEVICE_SETTINGS_SILVER device 
        on device.reader_uuid = extended.reader_uuid 
        left outer join live.SENSOR_SILVER sensor
        on sensor.device_id = device.device_id 
        and unix_timestamp(extended.factoryRecorded) between 
            unix_timestamp(sensor.first_sched_factory_reading) 
            and  unix_timestamp(sensor.last_sched_factory_reading)
        left outer join live.useday_filtered useday 
        on (extended.reader_uuid = useday.reader_uuid and to_date(extended.factoryRecorded) = to_date(useday.factoryRecorded))
        where extended.type = 'exercise'
    """)

    return exercise.withColumn("exercise_id", monotonically_increasing_id())

# COMMAND ----------

# MAGIC %md
# MAGIC ###ref country(Manually populated, static file is located in S3 curated) -Redshift

# COMMAND ----------

#
@dlt.table(
  name="REF_COUNTRY_BRONZE",
  comment="load ref country input",
  temporary=temporary)
def ref_country_bronze():
    return spark.read.table(f"`{marshall_catalog}`.`{misc_schema}`.`ref-country`")

@dlt.table(
  name="REF_COUNTRY_GOLD",
  comment="load ref country",
  schema = gold_schema.ref_country_schema
)
def ref_country_gold():
    return spark.sql("""
        SELECT 
        ref.code as country, 
        ref.name as name, 
        CAST(coalesce(wl.included_in_reporting, 0) as int) as included_in_reporting
        FROM LIVE.REF_COUNTRY_BRONZE ref LEFT OUTER JOIN LIVE.whitelisted_countries wl
            on ref.code = wl.code
    """)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Sensor wear Day -Redshift

# COMMAND ----------

@dlt.table(name="SENSOR_WEAR_DAY_GOLD",
  comment="gold sensor_wear_day"
#   schema=gold_schema.sensor_wear_day_schema
)
#@dlt.expect_all_or_drop(sensor_wear_day)
def sensor_wear_day():
    df = spark.sql(f"""
        SELECT
            sens_day.sensor_id,
            sens_day.sensor_no,
            sens_day.sensor_uid as sensor_uid,
            sens_day.wear_day wear_day,
            sens_day.wd_sched_reading_count wd_sched_reading_count,
            COALESCE(ug.unsched_reads, 0) wd_current_reading_count,
            sens_day.time_in_target,
            sens_day.time_above_target,
            sens_day.time_below_target,
            CAST(percentile.ptc10 as INTEGER) percentile_10th,
            CAST(percentile.ptc25 as INTEGER) percentile_25th,
            CAST(percentile.ptc50 as INTEGER) percentile_50th,
            CAST(percentile.ptc75 as INTEGER) percentile_75th,
            CAST(percentile.ptc90 as INTEGER) percentile_90th,
            first_processed_date --change made june 5th2024 AB
        FROM (
            select 
                sensor_id,
                sensor_no,
                sensor_uid,
                wear_day, 
                sched_reads as wd_sched_reading_count,
                COALESCE(ROUND(read_in_target/(sched_reads * 1.0) ,5)*24,0) as time_in_target,
                COALESCE(ROUND(read_above_target/(sched_reads * 1.0) ,5)*24,0) as time_above_target,
                COALESCE(ROUND(read_below_target/(sched_reads * 1.0) ,5)*24,0) as time_below_target,
                first_processed_date
            from (
                select 
                    sensor_id,
                    sensor_no,
                    sensor_uid, 
                    wear_day,
                    first_processed_date,
                    count(case when CAST(read_in_target_flg AS BOOLEAN) then 1 end)as read_in_target,
                    count(case when CAST(read_below_target_flg AS BOOLEAN) then 1 end) as read_below_target,
                    count(case when CAST(read_above_target_flg AS BOOLEAN) then 1 end) as read_above_target,
                    count(*) as sched_reads
                from 
                    LIVE.{scheduled_table_name + "GOLD"}
                group by sensor_id, sensor_no, sensor_uid, wear_day, first_processed_date
            )
        ) sens_day
        JOIN (
            SELECT DISTINCT
                sg.sensor_id,
                sg.wear_day,
                PERCENTILE_CONT (0.1) WITHIN GROUP (ORDER BY sg.value_mgdl ASC) OVER (PARTITION BY sg.sensor_id, sg.wear_day) ptc10,
                PERCENTILE_CONT (0.25) WITHIN GROUP ( ORDER BY sg.value_mgdl ASC) OVER (PARTITION BY sg.sensor_id, sg.wear_day) ptc25,
                PERCENTILE_CONT (0.5) WITHIN GROUP ( ORDER BY sg.value_mgdl ASC) OVER (PARTITION BY sg.sensor_id, sg.wear_day) ptc50,
                PERCENTILE_CONT (0.75) WITHIN GROUP ( ORDER BY sg.value_mgdl ASC) OVER (PARTITION BY sg.sensor_id, sg.wear_day) ptc75,
                PERCENTILE_CONT (0.9) WITHIN GROUP ( ORDER BY sg.value_mgdl ASC) OVER (PARTITION BY sg.sensor_id, sg.wear_day) ptc90
            FROM
                LIVE.{scheduled_table_name + "GOLD"} sg) percentile
        ON  percentile.sensor_id = sens_day.sensor_id 
        AND percentile.wear_day = sens_day.wear_day
        LEFT OUTER JOIN (
                select 
                    sensor_id, 
                    wear_day, 
                    count(*) as unsched_reads 
                from 
                    LIVE.CURRENT_GLUCOSE_READING_GOLD
                group by sensor_id, wear_day
        ) ug
        ON ug.sensor_id = sens_day.sensor_id 
        AND ug.wear_day = sens_day.wear_day
        """)

    return df.withColumn("sensor_wear_day_id", monotonically_increasing_id())
