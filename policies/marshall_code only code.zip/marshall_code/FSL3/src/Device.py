# Databricks notebook source
from pyspark.sql.functions import lit, monotonically_increasing_id, col

import dlt
import bronze_schema
import gold_schema

from variables_orig import *
from data_quality import *
from data_quality_gold import *

# COMMAND ----------

# MAGIC %md # Bronze Table

# COMMAND ----------

# MAGIC %md ### Device Settings

# COMMAND ----------

#This cell is the deviceSettingsHandler.initalize function in EMR

#df_input_files
@dlt.table(temporary=temporary)
@dlt.expect_all_or_drop(device_input_rules)
def device_input():
    df = (spark.read
            .table(f"`{dmz_catalog}`.`{input_schema}`.`device_settings`")
            .where(col("uploaddate").between(start_date, end_date))
    )              
    return df.withColumn("date_", lit(snapshot_date))

#df_hist_files
@dlt.table(temporary=temporary)
def device_history():
    query = f"SHOW TABLES IN `{history_catalog}`.`{history_schema}` LIKE 'device_settings' "
    result = spark.sql(query).collect()
    
    if result:
        return (spark.read
                .table(f'`{history_catalog}`.`{history_schema}`.`device_settings`')
        )
    else:
        return spark.createDataFrame([], schema=bronze_schema.device_schema)


#df_device_settings_df
@dlt.view(name=device_table_name + "BRONZE")
def device_combined():
    combined = spark.sql("SELECT * from LIVE.device_input UNION SELECT * from LIVE.device_history;")
    
    return combined.orderBy("accountid", "deviceuuid", 'uploadsequence', "date_").dropDuplicates(subset=['accountid', 'deviceuuid', 'uploadsequence'])


# Update Device Settings History
@dlt.table(
  name=device_table_name + "BRONZE_HISTORY",
  comment="combined device",
  temporary=temporary)
def device_update_history():
    df = spark.sql(f"select * from live.{device_table_name}BRONZE where date_ = '{snapshot_date}'")

    df.write.mode("append").format("delta")\
        .option('nullValue', None)\
        .option("mergeSchema", "false")\
        .saveAsTable(f"`{marshall_catalog}`.`{history_schema}`.`device_settings`")

    
    return df

# COMMAND ----------

# MAGIC %md # Silver Table

# COMMAND ----------

# MAGIC %md ### Upload
# MAGIC

# COMMAND ----------

#deviceSettingsHandler.rep_create_upload_dataset()
@dlt.table(temporary=temporary)
def upload_input():
    return spark.sql(f"""
        select 
            CAST (uploadSequence as BIGINT) as upload_id,
            CAST (uploadDate as DATE) as upload_date,
            devicenationality as upload_country, 
            deviceuuid as reader_uuid, 
            firmwareversion as firmware_version,
            modelname as device_model
        from LIVE.{device_table_name}BRONZE
    """)

# COMMAND ----------

# MAGIC %md ### Sched & Unsched Aggregated
# MAGIC

# COMMAND ----------

#This cell is the rep_create_device_dataset function in EMR
@dlt.view()
#@dlt.table(temporary=temporary)
def scheduled_aggregated_device():
    return spark.sql("""
        select
            sg_aggr.reader_uuid,
            sg_aggr.country as reader_nationality,
            u.upload_date as upload_date,
            u.firmware_version as firmware,
            sg_aggr.first_sched_factory_reading,
            sg_aggr.last_sched_factory_reading,
            sg_aggr.first_sched_user_reading, 
            sg_aggr.last_sched_user_reading,
            sg_aggr.sensor_count, 
            sg_aggr.sched_reading_count,
            u.device_model as device_model,
            sg_aggr.date_
        from (
            select
                reader_uuid,
                country,
                max(upload_id) as max_upload_id,
                min(factoryrecorded) as first_sched_factory_reading,
                max(factoryrecorded) as last_sched_factory_reading,
                min(userrecorded) as first_sched_user_reading,
                max(userrecorded) as last_sched_user_reading,
                nvl(sum(firstAfterActivation), 0) as sensor_count,
                count(*) as sched_reading_count,
                first(date_) as date_
            from
                LIVE.SCHEDULED_GLUCOSE_READING_SILVER
            group by reader_uuid, country
        ) sg_aggr
        inner join LIVE.upload_input u
        on sg_aggr.reader_uuid = u.reader_uuid
        and sg_aggr.max_upload_id = u.upload_id
    """) 

# COMMAND ----------


#This cell is the rep_create_device_dataset function in EMR
@dlt.view()
#@dlt.table(temporary=temporary)
def current_aggregated():
    current_enriched_df = dlt.read('CURRENT_GLUCOSE_READING_SILVER')
    current_enriched_df.orderBy(current_enriched_df['reader_uuid'].asc(), current_enriched_df['factoryRecorded'].asc())
        
    #aggregate unscheduled dataset grouped by device id give count of unscheduled records for a device
    current_aggr_by_dev_df = current_enriched_df.groupBy("reader_uuid").count().withColumnRenamed("count", "current_reading_count")

    return current_aggr_by_dev_df

# COMMAND ----------

# MAGIC %md ## Device DF
# MAGIC

# COMMAND ----------

# MAGIC %md #### Create Device

# COMMAND ----------

#This came from rep_create_device_dataset
@dlt.table(temporary=temporary)
def device_initial():
    df = spark.sql("""
            select
                nvl(sched_glu_aggr.firmware, 'missing') as firmware,
                sched_glu_aggr.reader_uuid,
                sched_glu_aggr.reader_nationality,
                sched_glu_aggr.first_sched_factory_reading,
                sched_glu_aggr.last_sched_factory_reading,
                sched_glu_aggr.first_sched_user_reading,
                sched_glu_aggr.last_sched_user_reading,
                nvl(sched_glu_aggr.sched_reading_count, 0) as sched_reading_count,
                nvl(current_aggr_by_dev.current_reading_count, 0) as current_reading_count,
                nvl(sched_glu_aggr.sensor_count, 0) as sensor_count,
                nvl(
                    round(
                        current_aggr_by_dev.current_reading_count/(
                                (
                                    (
                                    int(unix_timestamp(last_sched_factory_reading)/60) - 
                                    int(unix_timestamp(first_sched_factory_reading)/60)  
                                    )/1440
                                )+1
                        ), 0)
                    , 0) as avg_scan_per_wear_day,
                case 
                    when DATEDIFF(CURRENT_DATE, sched_glu_aggr.upload_date) > 90 
                    then 1 
                    else 0 
                    end 
                as upload_interval,
                sched_glu_aggr.device_model,
                sched_glu_aggr.date_
            from
                LIVE.scheduled_aggregated_device as sched_glu_aggr
            left outer join LIVE.current_aggregated as current_aggr_by_dev
            on sched_glu_aggr.reader_uuid = current_aggr_by_dev.reader_uuid
            order by sched_glu_aggr.reader_uuid
        """)
    return df.withColumn("device_id", monotonically_increasing_id())

# COMMAND ----------

# MAGIC %md #### Date Handler

# COMMAND ----------

#df_devices_with_old_uploads
@dlt.view()
def device_old_uploads() :
    return spark.sql(f"SELECT reader_uuid from LIVE.SCHEDULED_GLUCOSE_READING_SILVER where datediff(userRecorded, '2014-10-16') < 0")

#df_devices_with_future_uploads
@dlt.view()
def device_future_uploads() :
    return spark.sql(f"SELECT reader_uuid from LIVE.SCHEDULED_GLUCOSE_READING_SILVER where datediff(factoryRecorded, CURRENT_DATE) > 0")

# COMMAND ----------

# MAGIC %md #### Whitelisted Countries (CountryFilterHandler)

# COMMAND ----------

#.get_white_listed_countries()
@dlt.table(temporary=temporary)
def whitelisted_countries():
    df_countries = spark.read.table(f"`{marshall_catalog}`.`{misc_schema}`.`wl-countries`")
    return df_countries.filter(df_countries.included_in_reporting == 1)


@dlt.view
#@dlt.table(temporary=temporary)
def device_whitelisted():
    return spark.sql("SELECT d.* from LIVE.device_initial d INNER JOIN LIVE.whitelisted_countries w ON d.reader_nationality = w.code")

# COMMAND ----------

# MAGIC %md #### Blacklisted Devices (DeviceBlacklistFilterHandler)

# COMMAND ----------

@dlt.table(temporary=temporary)
def blacklisted_devices():
    df = spark.read.table(f"`{marshall_catalog}`.`{misc_schema}`.`bl-devices`")
    return df.withColumn("date_added", lit(snapshot_date))


#This is a combination of get_all_blacklisted_items and total_blacklisted_devices. Since get_all_blacklisted_items is gold and the DF that refrences total_blacklisted_devices does a select on reader_uuid, we can combine it. 

@dlt.table(name="BLACKLIST_GOLD")
def blacklisted_items():    
    return spark.sql("""
            select 
                reader_uuid, 
                reason as reason,
                date_added
            from 
                LIVE.blacklisted_devices 
            UNION
            select 
                reader_uuid, 
                NULL as reason,
                NULL as date_added
            from 
                LIVE.device_old_uploads 
            UNION
            select 
                reader_uuid, 
                NULL as reason,
                NULL as date_added
            from 
                LIVE.device_future_uploads
    """)

@dlt.view()
#@dlt.table(temporary=temporary)
def device_blacklisted():
    return spark.sql("""
            select * 
            from LIVE.device_whitelisted 
            where reader_uuid NOT IN (
                select distinct(reader_uuid) 
                from LIVE.BLACKLIST_GOLD
            )
    """)

# COMMAND ----------

# MAGIC %md #### Devices Enriched (DeviceBlacklistFilterHandler)

# COMMAND ----------

#df_device_settings
@dlt.view()
#@dlt.table(temporary=temporary)
def df_device_settings():
    return spark.sql(f"""
        SELECT
            a.deviceUUID,
            deviceNationality,
            uploadSequence,
            firmwareVersion,
            systemType,
            readerType,
            CAST(a.date_ as DATE) as date_
        FROM
            LIVE.{device_table_name}BRONZE a
            INNER JOIN (SELECT deviceUUID, MAX(uploadSequence) maxUploadSeqence FROM LIVE.{device_table_name}BRONZE GROUP BY deviceUUID) b
            ON a.deviceUUID = b.deviceUUID
            AND a.uploadSequence = b.maxUploadSeqence 
            order by a.deviceUUID
    """)

#enrich_devices_with_device_settings

@dlt.table(temporary=temporary)
def device_enriched():
    return spark.sql("""
        select
            devices_filtered.*,
            device_settings.systemType as system_type,
            device_settings.readerType as reader_type,
            device_settings.firmwareVersion as firmwareversion
        from
            LIVE.device_blacklisted as devices_filtered
        inner join LIVE.df_device_settings as device_settings
        on devices_filtered.reader_uuid = device_settings.deviceUUID
    """)

# COMMAND ----------

# MAGIC %md #### Whitelisted Devices(FirmwareWhiteListFilterHandler)

# COMMAND ----------

#whitelisted_devices_df
@dlt.table(temporary=temporary,
           name="whitelisted_devices_bronze")
def whitelisted_devices():
    return spark.read.table(f"`{marshall_catalog}`.`{misc_schema}`.`wl-devices`")



#distinct_devices_firmwares_with_scheduled_df
@dlt.view()
#@dlt.table(temporary=temporary)
def firmware_distinct_devices():
    return spark.sql("""
            select 
                scheduled_glucose_readings.reader_uuid, 
                scheduled_glucose_readings.firmware 
            from 
                LIVE.SCHEDULED_GLUCOSE_READING_SILVER as scheduled_glucose_readings
            group by 
                scheduled_glucose_readings.reader_uuid, 
                scheduled_glucose_readings.firmware 
            order by scheduled_glucose_readings.reader_uuid
    """)

#all_devices_with_scheduled_glucose_reading_df
@dlt.view()
#@dlt.table(temporary=temporary)
def firmware_all_devices():
    return spark.sql("""
            select 
                f.reader_uuid, 
                f.firmware,
                devices.system_type 
            from 
                LIVE.firmware_distinct_devices as f 
            inner join LIVE.device_enriched as devices 
            on devices.reader_uuid = f.reader_uuid
    """)    

#self.firmwares_df
@dlt.table(temporary=temporary)
def firmware_input():
    return spark.read.table(f"`{marshall_catalog}`.`{misc_schema}`.`wl-firmwares`")

#white_listed_firmwares_df
@dlt.view()
#@dlt.table(temporary=temporary)
def whitelisted_firmwares():
    return spark.sql("""
            select 
                firmware_version,
                system_type,
                included_in_reporting 
            from LIVE.firmware_input
            where included_in_reporting =1
    """)


#devices_filtered_by_whitelist_df
@dlt.view
#@dlt.table(temporary=temporary)
def firmware_filtered():
    return spark.sql("""
            select f.reader_uuid 
            from LIVE.firmware_all_devices as f 
            inner join LIVE.whitelisted_firmwares as w 
            on f.firmware = w.firmware_version
            and f.system_type = w.system_type
    """)

# COMMAND ----------

# MAGIC %md #### Silver Device DF & Whitelist

# COMMAND ----------

#filtered_devices_df
@dlt.table(
 name=device_table_name + "SILVER",
 temporary=temporary)
def device_whitelist_filtered():
   return spark.sql("""
            SELECT * 
            from LIVE.device_enriched 
            where reader_uuid IN (
                SELECT reader_uuid 
                from LIVE.firmware_filtered 
                UNION 
                select reader_uuid 
                from LIVE.whitelisted_devices_bronze
            )
    """)

# This gets written to whitelisted-devies history?
#all_whitelisted_devices_df
@dlt.table(
    name="WHITELISTED_DEVICES",
    temporary=temporary,
    comment="whitelisted devices filtered history write"
)
def whitelisted_devices_final():
    df = spark.sql(f"select reader_uuid, firmware as firmware_version from LIVE.DEVICE_SETTINGS_SILVER")
    df.write.mode("overwrite").format("delta")\
        .option('nullValue', None)\
        .option("mergeSchema", "false")\
        .saveAsTable(f"`{marshall_catalog}`.`{misc_schema}`.`wl-devices`")

    
    return df

# COMMAND ----------

# MAGIC %md # Gold Tables

# COMMAND ----------

# MAGIC %md ### Device Gold

# COMMAND ----------

@dlt.view()
#@dlt.table(temporary=temporary)
def device_data_sufficiency():
    device_data_sufficiency = spark.sql(f"""
        SELECT 
            device_id,
            CASE
                WHEN SUM(CASE WHEN UNIQUE_DATES >= 5 AND READINGS_COUNT >= 10 THEN 1 ELSE 0 END) >= 20 
                THEN 1
                ELSE 0
            END as DATA_SUFFICIENCY_IND
        FROM (
            SELECT
                DEVICE_ID,
                COUNT(DISTINCT TO_DATE(FACTORY_RECORDED)) AS UNIQUE_DATES,
                COUNT(SENSOR_ID) AS READINGS_COUNT
            FROM 
                LIVE.scheduled_final
            GROUP BY DEVICE_ID, FACTORY_REC_HOUR
        ) TAB3
        GROUP BY DEVICE_ID
    """)
    return device_data_sufficiency

@dlt.view()
#@dlt.table(temporary=temporary)
def device_final_df():
    return spark.sql("""
        select 
            device.device_id, 
            device.reader_uuid, 
            device.reader_nationality, 
            device.first_sched_factory_reading,
            device.last_sched_factory_reading, 
            device.first_sched_user_reading, 
            device.last_sched_user_reading, 
            device.sensor_count, 
            device.sched_reading_count,
            device.current_reading_count, 
            device.avg_scan_per_wear_day, 
            device.upload_interval as abandoned_ind,
            
            case 
                when i.device_id is not null 
                then '1' 
                else '0' 
            end as use_insulin_calc_ind, 
            device.firmware as current_firmware_version,
            nvl(device_data_sufficiency.data_sufficiency_ind, '0') as  data_sufficiency_ind,
            device.device_model,
            CAST(device.date_ as DATE)
        from 
            live.DEVICE_SETTINGS_SILVER device 
        left outer join live.device_data_sufficiency device_data_sufficiency 
        on device.device_id = device_data_sufficiency.device_id
        left outer join (select distinct device_id from LIVE.INSULIN_GOLD) i on device.device_id = i.device_id
    """)

@dlt.view()
#@dlt.table(temporary=temporary)
def device_medicare():
    return spark.sql("""
        select
            reader_uuid,
            '1' as medicare_patient,
            min(userRecorded) as medicare_start_date
        from
            LIVE.GENERIC_SILVER
        where "type" ='sensorstart'  
        and localization='66' 
        group by reader_uuid
    """) 

@dlt.view()
#@dlt.table(temporary=temporary)
def device_medicare_df():
    return spark.sql("""
        select 
            device.* , 
            medicare_devices.medicare_patient, 
            medicare_devices.medicare_start_date 
        from
            LIVE.device_final_df device 
            left outer join LIVE.device_medicare as medicare_devices 
            on device.reader_uuid = medicare_devices.reader_uuid
    """)



@dlt.view()
#@dlt.table(temporary=temporary)
def device_stg():
    return spark.sql("""
        select 
            devices_filtered.*, 
            device_settings.systemType as system_type, 
            device_settings.readerType as reader_type
        from 
            LIVE.device_medicare_df devices_filtered 
        inner join LIVE.df_device_settings device_settings 
        on devices_filtered.reader_uuid = device_settings.deviceUUID 
    """)

# this is from the redshift scripts
@dlt.table(name='DEVICE_GOLD',
  comment="gold device",
  schema=gold_schema.device_schema
)
#@dlt.expect_all_or_drop(device)
def device_gold():
    device = spark.sql("""
            SELECT 
                device_id, 
                reader_uuid, 
                reader_nationality as country,  
                cast(first_sched_factory_reading as timestamp),  
                cast(last_sched_factory_reading as timestamp),  
                cast(first_sched_user_reading as timestamp),
                cast(last_sched_user_reading as timestamp),
                sensor_count,
                cast(sched_reading_count as long) as raw_sched_reading_count,
                cast(current_reading_count as long) as raw_current_reading_count,
                avg_scan_per_wear_day as avg_view_per_wear_day,
                cast(    
                    ((cast(int((unix_timestamp(last_sched_factory_reading, 'yyyy-mm-dd hh:mm:ss')/60)) - int(unix_timestamp(first_sched_factory_reading, 'yyyy-mm-dd hh:mm:ss')/60)  as integer)/1440)+1)*1.0
                as integer) as total_wear_days, 
                cast(abandoned_ind as boolean),   
                cast(use_insulin_calc_ind as boolean),  
                current_firmware_version,   
                cast(data_sufficiency_ind as boolean),
                cast(medicare_patient as boolean),
                medicare_start_date,
                system_type,
                reader_type,
                device_model,
                cast(date_ as date) as first_processed_date
            FROM 
                LIVE.device_stg
        """)
    return device


# COMMAND ----------

# MAGIC %md
# MAGIC ###Upload Gold

# COMMAND ----------

@dlt.table(
    name="UPLOAD_GOLD",
    schema=gold_schema.upload_schema
)
def upload_gold():
    return spark.sql("""
            select 
                CAST(u.upload_id as BIGINT), 
                CAST(u.upload_date as DATE), 
                u.upload_country as country,
                u.reader_uuid, 
                u.firmware_version,
                ad.account_id,
                cast(d.date_ as date) as first_processed_date
            from 
                LIVE.upload_input u 
            inner join LIVE.DEVICE_SETTINGS_SILVER d 
            on u.reader_uuid = d.reader_uuid
            inner join LIVE.ACCOUNT_DEVICE_GOLD ad on u.reader_uuid = ad.reader_uuid
    """)

# COMMAND ----------

# MAGIC %md ### Whitelist Gold

# COMMAND ----------

#all_distinct_firmwares_systemtype_df
@dlt.view()
#@dlt.table(temporary=temporary)
def firmware_distinct():
    return spark.sql("""
            select 
                firmware, 
                system_type 
            from 
                LIVE.firmware_all_devices 
            group by firmware, system_type
    """)


@dlt.view()
#@dlt.table(temporary=temporary)
def firmware_new():
    return spark.sql("""
            select 
                nvl(f.firmware,'missing') as firmware_version,
                f.system_type as system_type, 
                '-1' as included_in_reporting
            from 
                LIVE.firmware_distinct f  
            LEFT ANTI JOIN LIVE.firmware_input w 
            on f.firmware  = w.firmware_version 
            and f.system_type = w.system_type                 
    """)

@dlt.table(name="WHITELIST_GOLD")
def firmware_all():
    return spark.sql(f"""
            select 
                firmware_version,
                system_type, 
                CAST(included_in_reporting as INTEGER)
            from  
                LIVE.firmware_new  
            UNION
            select 
                firmware_version,
                system_type, 
                included_in_reporting
            from  
                LIVE.firmware_input
    """)
