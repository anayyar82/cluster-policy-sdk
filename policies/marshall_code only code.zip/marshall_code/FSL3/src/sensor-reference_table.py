# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, sha1, concat, lead, date_add, when, year, month,datediff,countDistinct,count,current_timestamp,sum as _sum,to_timestamp
from pyspark.sql.window import Window
from variables_orig import *
import dlt




# COMMAND ----------

# MAGIC %md # Sensor Reference Table

# COMMAND ----------

@dlt.table(
  name="Sensor_Reference_Table_gold",
  comment="Reference table that calculates the sensor start,assumed sensor end and other indicators per account,device",
  temporary=True
  )
def Sensor_Reference_Table_FSL3():
    #catalog information
    #dev-adc-dmz-catalog-us-east-2.rwe-input-fsl3.generic
    #dev-adc-marshallrwe-catalog-us-east-2.rwe-history-fsl3.generic
    #catalog_history = "`dev-adc-marshallrwe-catalog-us-east-2`"
    #catalog_dmz = "`dev-adc-dmz-catalog-us-east-2`"
    generic_history_df = spark.sql(f"SELECT * FROM `{history_catalog}`.`{history_schema}`.`generic` where factoryrecorded is not null ")
    #generic_input_df = spark.sql(f"SELECT * FROM `{dmz_catalog}`.`{input_schema}`.`generic` where factoryrecorded is not null")
    
    # Step 1:  From generic_history_df dataframe, filter by sensorstart and get the accountid,deviceuui,max(producttype),sensoruid and facoryrecorded.
    sensorstart = generic_history_df.filter(col("TYPE") == "sensorstart") \
    #.withColumn("factoryrecorded",to_timestamp("factoryrecorded", "yyyy-MM-dd'T'HH:mm:ss")) \
    .groupBy("accountid", "deviceuuid", "factoryrecorded","sensoruid","devicenationality") \
    .agg({"producttype": "max"}) \
    .withColumnRenamed("factoryrecorded", "sensor_start") \
    .withColumnRenamed("max(producttype)", "producttype")

    # Step 2: get the next_sensor_start by using window function
    window_spec = Window.partitionBy("accountid", "deviceuuid").orderBy("sensor_start")
    next_sensor_start_df = sensorstart.withColumn("next_sensorStart", lead("sensor_start").over(window_spec))
    
    # Step 3: get sensorend for history and input data
    sensorend_df = generic_history_df.filter(col("TYPE") == "sensorend") \
        .select("accountid", "deviceuuid", "factoryrecorded","sensoruid") \
        .withColumn("factoryrecorded",to_timestamp("factoryrecorded", "yyyy-MM-dd'T'HH:mm:ss")) \
        .withColumnRenamed("factoryrecorded", "sensorend") \
        .distinct()
    
    # Step 4: left join sensor start with sensor end. 
    # Set irregular_indicator as true if the difference between sensor start and sensor end is greater than 15 
    # Set has_sensor_end as 1 if sensorend for sensor is null else 0
    sensor_start_1 = next_sensor_start_df.join(sensorend_df, 
                                        (next_sensor_start_df.accountid == sensorend_df.accountid) & 
                                        (next_sensor_start_df.deviceuuid == sensorend_df.deviceuuid) & 
                                        (next_sensor_start_df.sensoruid == sensorend_df.sensoruid) & 
                                        (next_sensor_start_df.sensor_start < sensorend_df.sensorend) & 
                                        (next_sensor_start_df.next_sensorStart > sensorend_df.sensorend), 
                                          "left") \
    .select(next_sensor_start_df["*"], sensorend_df["sensorend"]) \
    .withColumn("irregular_sensor_indicator", when((col("sensorend").isNotNull()) & (datediff(col("sensorend"), col("sensor_start")) > 15), "true").otherwise("false")) \
    .withColumn("has_sensor_end", when(col("sensorend").isNotNull(), 1).otherwise(0)) 

    # Step 5: add assumed sensor end field . Also calculate sensor_duration_diff
    #Add an assumed sensor end field :
    #Calculation:
    #1. When sensorend is null and sensor_start+15 days is greater than next_sensor_start then the sensorend should be next_sensor_start
    #2. When sensorend is null and sensor_start+15 days is less than next_sensor_start then the sensorend should be next_sensor_start
    #3. In all other cases it should be 'sensorend'
    
    sensor_reference_df = sensor_start_1.withColumn(
    "assumed_sensor_end",
    when(col("sensorend").isNotNull(), col("sensorend"))
    .when(date_add(col("sensor_start"), 15) >= col("next_sensorStart"), col("next_sensorStart"))
    .when((date_add(col("sensor_start"), 15) < col("next_sensorStart")) | (col("next_sensorStart").isNull()), date_add(col("sensor_start"), 15))).withColumn(
    "sensor_duration_diff",datediff(col("assumed_sensor_end"), col("sensor_start"))).withColumn("Processed_timestamp",current_timestamp())
    
    sensor_reference_df.write.mode("overwrite").format("delta")\
        .option('nullValue', None)\
        .option("mergeSchema", "true")\
        .saveAsTable(f"`{marshall_catalog}`.`{target_schema}`.`Sensor_Reference_Table_gold`")
        
    return sensor_reference_df
  
  
@dlt.table(
  name="Sensor_coverage_metric_gold",
  comment="Percentage coverage metric of sensor by nationality and devicetype. sensor coverage is measured by dividing number of records  ",
  temporary=True
  )
def Sensor_Coverage_Table_FSL3():

  fsl3_current_df = spark.sql(f"SELECT distinct accountid,deviceuuid,factoryrecorded,mgdl FROM `{dmz_catalog}`.`{input_schema}`.`current`")
  Sensor_Reference_Table_FSL3_df =dlt.read('Sensor_Reference_Table_gold')
  #Left join the FSL3 current table with the sensor reference table . 
  #We are interested in finding glucose records that fall within the sensor start and assumed sensor end. We use a column 'has_sensoruid' and mark it as 1 if the records that fall within the sensor start and assumed sensor end otherwise 0.
  
  #Ultimately, create a table called sensor_coverage_metric with columns
  # '''
  # month:integer
  # year:integer 
  # sensor_coverage_true:long 
  # sensor_coverage_false:long 
  # percentage_difference
  # '''
  # month                 --> Month of current glucose records
  # year                  --> Year of current glucose records
  # sensor_coverage_true  --> Number of records that fall within the sensor start and assumed sensor end for the month,year combination
  # sensor_coverage_false --> Number of records that do not fall within the sensor start and assumed sensor end for the month,year combination
  # percentage_difference --> Percentage difference between sensor_coverage_true and sensor_coverage_false



  sensor_counts_fsl3_df = fsl3_current_df.join(Sensor_Reference_Table_FSL3_df, 
                           (fsl3_current_df.accountid == Sensor_Reference_Table_FSL3_df.accountid) & 
                           (fsl3_current_df.deviceuuid == Sensor_Reference_Table_FSL3_df.deviceuuid) & 
                           (Sensor_Reference_Table_FSL3_df.assumed_sensor_end >= fsl3_current_df.factoryrecorded) & 
                           (Sensor_Reference_Table_FSL3_df.sensor_start <= fsl3_current_df.factoryrecorded), 
                           "left").select(fsl3_current_df["factoryrecorded"],fsl3_current_df["accountid"],fsl3_current_df["deviceuuid"],Sensor_Reference_Table_FSL3_df["sensoruid"],Sensor_Reference_Table_FSL3_df["devicenationality"],fsl3_current_df["mgdl"]).withColumn("has_sensoruid", when(col("sensoruid").isNotNull(), 1).otherwise(0))
  
  # Count how many sensoruids have and do not have sensor ends
  sensor_coverage_counts_fsl3_df = sensor_counts_fsl3_df.groupBy("has_sensoruid","devicenationality",year("factoryrecorded").alias("year"), month("factoryrecorded").alias("month")).agg(count("has_sensoruid").alias("sensoruid_count"))

  # Aggregate counts by month and year
  sensor_coverage_agg_fsl3_df = sensor_coverage_counts_fsl3_df.groupBy("month", "year","devicenationality").agg(
    _sum(when(col("has_sensoruid") == 1, col("sensoruid_count")).otherwise(0)).alias("sensor_coverage_true"),
    _sum(when(col("has_sensoruid") == 0, col("sensoruid_count")).otherwise(0)).alias("sensor_coverage_false")
  )

  # Calculate percentage difference
  sensor_coverage_result_fsl3_df = sensor_coverage_agg_fsl3_df.withColumn(
    "percentage_difference",
    (col("sensor_coverage_true") - col("sensor_coverage_false"))* 100 / (col("sensor_coverage_true") + col("sensor_coverage_false")) 
  )
  

  sensor_coverage_result_fsl3_df.write.mode("overwrite").format("delta")\
        .option('nullValue', None)\
        .option("mergeSchema", "true")\
        .saveAsTable(f"`{marshall_catalog}`.`{target_schema}`.`Sensor_coverage_metric_gold`")
        
  return sensor_coverage_result_fsl3_df


