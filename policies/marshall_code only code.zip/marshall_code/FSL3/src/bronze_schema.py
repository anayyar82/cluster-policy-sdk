from pyspark.sql.types import LongType, StringType, StructField, StructType, BooleanType, ArrayType, IntegerType, TimestampType, DateType, FloatType, DoubleType

account_details_schema = StructType([
    StructField("accountid", StringType(), True),
    StructField("devicenationality", StringType(), True),
    StructField("agerangelower", StringType(), True),
    StructField("agerangeupper", StringType(), True)
])

account_devices_schema = StructType([
    StructField("accountid", StringType(), True),
    StructField("deviceuuid", StringType(), True),
    StructField("date_", StringType(), True)
])

bl_devices_schema = StructType([
    StructField("reader_uuid", StringType(), True),
    StructField("reason", StringType(), True)

])

bl_accounts_schema = StructType([
    StructField("accountid", StringType(), True),
    StructField("reason", StringType(), True),
    StructField("date_added", StringType(), True) 
])

current_schema = StructType([
    StructField("accountid", StringType(), True), 
    StructField("factoryrecorded", StringType(), True),
    StructField("userrecorded", StringType(), True),
    StructField("deviceuuid", StringType(), True),
    StructField("devicenationality", StringType(), True),
    StructField("uploadsequence", StringType(), True), 
    StructField("firmwareversion", StringType(), True), 
    StructField("mgdl", DoubleType(), True),
    StructField("highoutofrange", BooleanType(), True),
    StructField("lowoutofrange", BooleanType(), True),
    StructField("actionable", BooleanType(), True),
    StructField("firstaftertimechange", BooleanType(), True),
    StructField("viewed", BooleanType(), True),
    StructField("streaming", BooleanType(), True),
    StructField("trendarrow", StringType(), True),
    StructField("uploaddate", StringType(), True),
    StructField("date_", StringType(), True)
])

device_schema = StructType([
    StructField("accountid", StringType(), True),
    StructField("deviceuuid", StringType(), True),
    StructField("devicenationality", StringType(), True),
    StructField("uploadsequence", StringType(), True),
    StructField("firmwareversion", StringType(), True),
    StructField("systemtype", StringType(), True),
    StructField("readertype", StringType(), True),
    StructField("devicetype", StringType(), True),
    StructField("modelname", StringType(), True),
    StructField("uploaddate", StringType(), True),
    StructField("date_", StringType(), True)
])

food_schema = StructType([
    StructField("accountid", StringType(), True),
    StructField("factoryrecorded", StringType(), True),
    StructField("userRecorded", StringType(), True),
    StructField("deviceuuid", StringType(), True),
    StructField("devicenationality", StringType(), True),
    StructField("uploadsequence", StringType(), True),
    StructField("firmwareversion", StringType(), True),
    StructField("mealname", StringType(), True),
    StructField("valuecarbs", FloatType(), True),
    StructField("numberofservings", IntegerType(), True),
    StructField("uploaddate", StringType(), True),
    StructField("date_", StringType(), True)
])

generic_schema = StructType([
    StructField("accountid", StringType(), True),
    StructField("factoryrecorded", StringType(), True),
    StructField("userrecorded", StringType(), True), 
    StructField("deviceuuid", StringType(), True), 
    StructField("devicenationality", StringType(), True), 
    StructField("uploadsequence", StringType(), True), 
    StructField("firmwareversion", StringType(), True), 
    StructField("type", StringType(), True),
    StructField("localization", StringType(), True),
    StructField("fixedlowglucosealarmisinepisode", BooleanType(), True),
    StructField("fixedlowglucosealarmiscleared", BooleanType(), True),
    StructField("fixedlowglucosealarmispresented", BooleanType(), True),
    StructField("fixedlowglucosealarmisdismissed", BooleanType(), True),
    StructField("fixedlowglucosealarmisusercleared", BooleanType(), True),

    StructField("lowglucosealarmisinepisode", BooleanType(), True),
    StructField("lowglucosealarmiscleared", BooleanType(), True),
    StructField("lowglucosealarmispresented", BooleanType(), True),
    StructField("lowglucosealarmisdismissed", BooleanType(), True),
    StructField("lowglucosealarmisusercleared", BooleanType(), True),

    StructField("highglucosealarmisinepisode", BooleanType(), True),
    StructField("highglucosealarmiscleared", BooleanType(), True),
    StructField("highglucosealarmispresented", BooleanType(), True),
    StructField("highglucosealarmisdismissed", BooleanType(), True),
    StructField("highglucosealarmisusercleared", BooleanType(), True),

    StructField("signallossalarmisinepisode", BooleanType(), True),
    StructField("signallossalarmiscleared", BooleanType(), True),
    StructField("signallossalarmispresented", BooleanType(), True),
    StructField("signallossalarmisautodismissed", BooleanType(), True),
    StructField("signallossalarmisuserdismissed", BooleanType(), True),
    StructField("signallossalarmisusercleared", BooleanType(), True),
    
    StructField("lowglucosethresholdinmgdl", StringType(), True),
    StructField("highglucosethresholdinmgdl", StringType(), True),
    StructField("islowglucoseenabled", BooleanType(), True),
    StructField("ishighglucoseenabled", BooleanType(), True),
    StructField("issignallossalarmenabled", BooleanType(), True),
    StructField("isalarmsoundenabled", BooleanType(), True),
    StructField("isalarmnotificationenabled", BooleanType(), True),
    StructField("configurationchangesource", IntegerType(), True),
    StructField("value", StringType(), True),
    StructField("timeDelta", StringType(), True),
    StructField("uploaddate", StringType(), True), 
    StructField("sensoruid", StringType(), True),
    StructField("producttype", StringType(), True),
    StructField("puckgen", StringType(), True),
    StructField("activationtype", StringType(), True),
    StructField("wearduration", StringType(), True),
    StructField("latejoined", StringType(), True),
    StructField("streaming", StringType(),True),
    StructField("warmuptime", StringType(), True),
    StructField("intensity", StringType(), True),
    StructField("durationinminutes", StringType(), True),
    StructField("sensorexpired", StringType(), True),
    StructField("sensorterminated", StringType(), True),
    StructField("date_", StringType(), True)
])

insulin_schema = StructType([
    StructField("accountid", StringType(), True),
    StructField("factoryrecorded", StringType(), True),
    StructField("userrecorded", StringType(), True),
    StructField("deviceuuid", StringType(), True),
    StructField("devicenationality", StringType(), True),
    StructField("uploadsequence", StringType(), True),
    StructField("firmwareversion", StringType(), True),
    StructField("type", StringType(), True),
    StructField("units", DoubleType(), True),
    StructField("insulinonboardinunits", StringType(), True),
    StructField("correctionamountinunits", StringType(), True),
    StructField("mealamountinunits", StringType(), True),
    StructField("useroverrideinunits", StringType(), True),
    StructField("uploaddate", StringType(), True),
    StructField("date_", StringType(), True)
])

insulin_devices_schema = StructType([
    StructField("accountid", StringType(), True),
    StructField("deviceUUID", StringType(), True),
    StructField("devicenationality", StringType(), True),
    StructField("manufacturer", StringType(), True),
    StructField("modelname", StringType(), True),
    StructField("localmodelname", StringType(), True),
    StructField("serialnumber", StringType(), True),
    StructField("hardwarerevision", StringType(), True),
    StructField("firmwarerevision", StringType(), True),
    StructField("softwarerevision", StringType(), True),
    StructField("blesoftwarerevision", StringType(), True),
    StructField("bleprotocolrevision", StringType(), True),
    StructField("devicetime", StringType(), True),
    StructField("defaultinsulintype", StringType(), True),
    StructField("defaultinsulinbrand", StringType(), True),
    StructField("uploadSequence", StringType(), True),
    StructField("uploaddate", StringType(), True),
    StructField("date_", StringType(), True)
])

insulin_devices_data_schema = StructType([
    StructField("accountid", StringType(), True),
    StructField("deviceuuid", StringType(), True),
    StructField("devicenationality", StringType(), True),
    StructField("relativetimestamp", StringType(), True),
    StructField("elapsedseconds", StringType(), True),
    StructField("serialnumber", StringType(), True),
    StructField("localtimestamp", StringType(), True),
    StructField("utctimestamp", TimestampType(), True),
    StructField("value", StringType(), True),
    StructField("insulintype", StringType(), True),
    StructField("insulinbrand", StringType(), True),
    StructField("primedose", BooleanType(), True),
    StructField("primealgo", BooleanType(), True),
    StructField("editeddose", BooleanType(), True),
    StructField("statusflags", StringType(), True),
    StructField("uploadSequence", LongType(), True),
    StructField("uploaddate", StringType(), True),
    StructField("date_", StringType(), True)
])

ketone_schema = StructType([
    StructField("accountid", StringType(), True),
    StructField("factoryrecorded", StringType(), True),
    StructField("userrecorded", StringType(), True),
    StructField("deviceuuid", StringType(), True),
    StructField("devicenationality", StringType(), True),
    StructField("uploadsequence", StringType(), True),
    StructField("firmwareversion", StringType(), True),
    StructField("valuemmol", DoubleType(), True), 
    StructField("uploaddate", StringType(), True),
    StructField("date_", StringType(), True)
])

ref_country_schema = StructType([
    StructField("code", StringType(), True), 
    StructField("name", StringType(), True),
    StructField("included_in_reporting", StringType(), True),
])

scheduled_schema = StructType([
    StructField("accountid", StringType(), True), 
    StructField("factoryrecorded", StringType(), True),
    StructField("userrecorded", StringType(), True),
    StructField("deviceuuid", StringType(), True),
    StructField("deviceNationality", StringType(), True),
    StructField("uploadsequence", StringType(), True),
    StructField("firmwareversion", StringType(), True),
    StructField("mgdl", DoubleType(), True),
    StructField("firstaftertimechange", BooleanType(), True),
    StructField("devicetype",StringType(), True),
    StructField("sensoruid", StringType(), True),
    StructField("uploaddate", StringType(), True),
    StructField("sensoruidcorrected", StringType(), True),
    StructField("lifecount", StringType(), True),
    StructField("date_", StringType(), True)
])

strip_schema =  StructType([
    StructField("accountid", StringType(), True),
    StructField("factoryrecorded", StringType(), True),
    StructField("userrecorded", StringType(), True),
    StructField("deviceuuid", StringType(), True),
    StructField("devicenationality", StringType(), True),
    StructField("uploadsequence", StringType(), True),
    StructField("firmwareversion", StringType(), True),
    StructField("mgdl", DoubleType(), True),
    StructField("uploaddate", StringType(), True),
    StructField("date_", StringType(), True)
])
                
survey_questions = StructType([
    StructField("surveyid", StringType(), False),
    StructField("surveyname", StringType(), True),
    StructField("surveyversion", IntegerType(), True),
    StructField("datepublished", TimestampType(), True),
    StructField("questionnumber", IntegerType(), True),
    StructField("questiontext", StringType(), True),
    StructField("responsenumber", IntegerType(), True),
    StructField("responsetext", StringType(), True)
])

survey_responses = StructType([
    StructField("accountid", StringType(), True),
    StructField("surveyid", StringType(), False),
    StructField("responseid", StringType(), True),
    StructField("responsedate", TimestampType(), True),
    StructField("questionnumber", IntegerType(), True),
    StructField("responsenumber", IntegerType(), True)
])
              
wl_country_schema = StructType([
    StructField("country", StringType(), True), 
    StructField("included_in_reporting", IntegerType(), True)
])

wl_device_schema = StructType([
    StructField("reader_uuid", StringType(), True) 
])

wl_firmware_schema = StructType([
    StructField("firmware_version", StringType(), True), 
    StructField("system_type", StringType(), True), 
    StructField("included_in_reporting", IntegerType(), True)
])
