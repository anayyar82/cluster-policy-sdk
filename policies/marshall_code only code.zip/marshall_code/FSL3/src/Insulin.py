# Databricks notebook source
from pyspark.sql.functions import col, lit, from_unixtime, unix_timestamp, monotonically_increasing_id, hour, to_timestamp


import dlt
import bronze_schema
import gold_schema
from variables_orig import *
from data_quality import *
from delta.tables import *

# COMMAND ----------

# MAGIC %md # Insulin

# COMMAND ----------

# MAGIC %md ## Bronze Table

# COMMAND ----------

#Creating original table
@dlt.table(temporary=temporary)
@dlt.expect_all_or_drop(insulin_input_rules)
def insulin_input():
    df = (spark.read
            .table(f"`{dmz_catalog}`.`{input_schema}`.`{insulin_table_name[:-1]}`")
            .where(col("uploaddate").between(start_date, end_date))
    )              
    return df.withColumn("date_", lit(snapshot_date))

@dlt.table(temporary=temporary)
def insulin_history():
    query = f"SHOW TABLES IN `{history_catalog}`.`{history_schema}` LIKE '{insulin_table_name[:-1]}'"
    result = spark.sql(query).collect()
    if result:
        return (spark.read
                .table(f'`{history_catalog}`.`{history_schema}`.`{insulin_table_name[:-1]}`')
        )
    else:
          return spark.createDataFrame([], schema=bronze_schema.insulin_schema)    

@dlt.view()
def insulin_combined():
    return spark.sql("SELECT * from LIVE.insulin_input UNION SELECT * from LIVE.insulin_history;")

@dlt.view()
def insulin_dedup():
    df = spark.sql(f"SELECT * from LIVE.insulin_combined ORDER BY deviceuuid ASC, factoryRecorded ASC, uploadsequence ASC, date_ ASC;")
    return df.dropDuplicates(subset=['deviceUUID', 'factoryrecorded', 'type'])

@dlt.view()
def insulin_blacklist():
    return spark.sql("select a.* from live.insulin_dedup as a LEFT Join live.bronze_blacklist_account as b on a.accountid = b.accountid where b.accountId is null")

@dlt.view(name=insulin_table_name + "BRONZE")
def insulin_threshold():
    return spark.sql("""SELECT a.* from live.insulin_blacklist as a WHERE a.accountid in (
        SELECT accountid from live.accounts_greater_than_threshold where accountid is not null
    )""")

@dlt.table(
  name=insulin_table_name + "BRONZE_HISTORY",
  comment="insulin bronze",
  temporary=temporary)
def insulin_update_history():
    df = spark.sql(f"select * from live.{insulin_table_name}BRONZE where date_ = '{snapshot_date}' ")

    df.write.mode("append").format("delta")\
        .option('nullValue', None)\
        .option("mergeSchema", "false")\
        .saveAsTable(f"`{marshall_catalog}`.`{history_schema}`.`{insulin_table_name[:-1]}`")

    
    return df


# COMMAND ----------

# MAGIC %md
# MAGIC ##Silver Table

# COMMAND ----------

@dlt.view()
#@dlt.table(temporary=temporary)
def insulin_format_user_time_stamp():
    format_user_timestamp_df = spark.sql("select  if  (instr(right(userRecorded,6), '+') > 0 or instr(right(userRecorded,6), '-') > 0 , substr(userRecorded,0,length(userRecorded)-6) , userRecorded) as userRecorded_modified,*  from  live.INSULIN_BRONZE")

    format_user_timestamp_df = format_user_timestamp_df.drop("userRecorded") \
                            .withColumnRenamed("userRecorded_modified", "userRecorded") \
                            .withColumn('userRecorded', to_timestamp(col('userRecorded'))) \
                            .withColumn('factoryrecorded', to_timestamp(col('factoryrecorded')))
    return format_user_timestamp_df
    
@dlt.view()
#@dlt.table(temporary=temporary)
def insulin_transformed():
    insulin_input_transformed_df =  spark.sql("select  cast(replace(insulinonboardinunits,',','.')  as float) as formatted_insulinOnboardInUnits, \
                                                    cast(replace(correctionamountinunits,',','.') as float) as formatted_correctionAmountInUnits,\
                                                    cast(replace(mealamountinunits,',','.')  as float) as formatted_mealAmountInUnits, \
                                                    cast(replace(useroverrideinunits,',','.') as float) as formatted_userOverrideInUnits,  \
                                                        *  from live.insulin_format_user_time_stamp")
    insulin_input_transformed_df = insulin_input_transformed_df.drop("insulinonboardinunits","correctionamountsinunits","mealamountinunits","useroverrideinunits") 
    return insulin_input_transformed_df


@dlt.table(
  name=insulin_table_name + "SILVER",
  comment="insulin silver",
  temporary=temporary)
def insulin_enriched():
    new_insulin_df = dlt.read('insulin_transformed')
    new_insulin_df = new_insulin_df.withColumn("factoryrechour", hour(new_insulin_df.factoryrecorded))\
                                    .withColumn ("userrechour", hour(new_insulin_df.userRecorded)) \
                                    .withColumn("uploadSequence" ,col('uploadSequence').cast('long'))\
                                    .withColumn("units" ,col('units').cast('float'))
                                                                   
    new_insulin_df = new_insulin_df.withColumnRenamed("deviceUUID", "reader_uuid") \
                                    .withColumnRenamed("deviceNationality", "country") \
                                    .withColumnRenamed("uploadSequence", "upload_id")
    
    new_insulin_df = new_insulin_df.orderBy(new_insulin_df['reader_uuid'].asc(), new_insulin_df['factoryrecorded'].asc())
    return new_insulin_df


# COMMAND ----------

# MAGIC %md
# MAGIC ##Gold Table

# COMMAND ----------

@dlt.table(name=insulin_table_name + "GOLD",
  comment="gold insulin",
  schema=gold_schema.insulin_schema
)
def insulin_fsl3():
    results_insulin_df = spark.sql("""
                    SELECT d.device_id,
                    s.SENSOR_ID, 
                    S.SENSOR_NO, 
                    S.SENSOR_UID,
                    CAST(i.upload_id as BIGINT), 
                    i.type as INSULIN_TYPE, 
                    i.units as VALUE_UNITS, 
                    CAST(i.userRecorded as TIMESTAMP) as USER_RECORDED, 
                    CAST(i.userRecHour as SMALLINT) as USER_REC_HOUR,
                    CAST(i.factoryRecorded as TIMESTAMP) as FACTORY_RECORDED, 
                    CAST(i.FactoryRecHour as SMALLINT) as FACTORY_REC_HOUR,
                    cast(((int(unix_timestamp(i.factoryRecorded)/60) - int(unix_timestamp(s.first_sched_factory_reading)/60))/1440) + 1 as int) as wear_day,

                    datediff(to_date(i.factoryRecorded), to_date(s.first_sched_factory_reading)) + 1 as CALENDAR_DAY, 
                    useday.use_day as usage_day,
                    datediff(to_date(i.factoryRecorded), to_date(d.first_sched_factory_reading)) as OWNERSHIP_DAY,
                    i.formatted_insulinOnboardInUnits as INSULIN_ON_BOARD_IN_UNITS, 
                    i.formatted_userOverrideInUnits as USER_OVERRIDE_AMOUNT_IN_UNITS, 
                    i.formatted_correctionAmountInUnits as CORRECTION_AMOUNT_IN_UNITS, 
                    i.formatted_mealAmountInUnits as MEAL_AMOUNT_IN_UNITS, 
                    i.reader_uuid, 
                    i.firmwareversion as firmware_version,
                    i.country,
                    cast(i.date_ as DATE) as first_processed_date
                FROM live.INSULIN_SILVER i 
                INNER JOIN LIVE.DEVICE_SETTINGS_SILVER d 
                ON i.reader_uuid = d.reader_uuid 
                LEFT OUTER JOIN live.SENSOR_SILVER s 
                ON d.DEVICE_ID = s.DEVICE_ID 
                AND unix_timestamp(i.factoryRecorded) between unix_timestamp(s.first_sched_factory_reading) 
                and unix_timestamp(s.last_sched_factory_reading)
                LEFT OUTER JOIN live.useday useday 
                on (i.reader_uuid = useday.reader_uuid and to_date(i.factoryRecorded) = to_date(useday.factoryRecorded))
    """)

    results_insulin_df = results_insulin_df.withColumn("insulin_id", monotonically_increasing_id())
    
    return results_insulin_df

# COMMAND ----------

# MAGIC %md
# MAGIC # Insulin Device

# COMMAND ----------

# MAGIC %md ## Bronze Table

# COMMAND ----------

@dlt.table(temporary=temporary)
def insulin_device_input():
    df = (spark.read
            .table(f"`{dmz_catalog}`.`{input_schema}`.`{insulin_device_table_name[:-1]}`")
            .where(col("uploaddate").between(start_date, end_date))
    )              
    return df.withColumn("date_", lit(snapshot_date))

@dlt.table(temporary=temporary)
def insulin_device_history():
    query = f"SHOW TABLES IN `{history_catalog}`.`{history_schema}` LIKE '{insulin_device_table_name[:-1]}'"
    result = spark.sql(query).collect()
    if result:
        return (spark.read
                .table(f'`{history_catalog}`.`{history_schema}`.`{insulin_device_table_name[:-1]}`')
        )
    else:
          return spark.createDataFrame([], schema=bronze_schema.insulin_devices_schema)    

@dlt.view()
def insulin_device_combined():
    return spark.sql("SELECT * from LIVE.insulin_device_input UNION SELECT * from LIVE.insulin_device_history;")

@dlt.view()
def insulin_device_dedup():
    df = spark.sql(f"SELECT * from LIVE.insulin_device_combined ORDER BY accountid ASC, deviceuuid ASC, uploadsequence ASC, date_ ASC;")
    return df.dropDuplicates(subset=['accountid', 'deviceuuid', 'uploadsequence'])

@dlt.view(name=insulin_device_table_name + "BRONZE")
def insulin_device_bronze():
    return spark.sql("""SELECT a.* from live.insulin_device_dedup as a WHERE a.accountid in (
        SELECT accountid from live.accounts_greater_than_threshold where accountid is not null
    )""")

@dlt.table(
  name=insulin_device_table_name + "BRONZE_HISTORY",
  comment="insulin device bronze",
  temporary=temporary)
def insulin_device_update_history():
    df = spark.sql(f"select * from live.{insulin_device_table_name}BRONZE where date_ = '{snapshot_date}' ")
    
    df.write.mode("append").format("delta")\
        .option('nullValue', None)\
        .option("mergeSchema", "false")\
        .saveAsTable(f"`{marshall_catalog}`.`{history_schema}`.`{insulin_device_table_name[:-1]}`")

    
    return df

# COMMAND ----------

# MAGIC %md ## Silver Table

# COMMAND ----------

@dlt.table(
  name=insulin_device_table_name + "SILVER",
  comment="insulin device silver",
  temporary=temporary)
def insulin_device_silver():
    return spark.sql("""
        SELECT 
            a.accountid,
            a.deviceUUID, 
            a.devicenationality, 
            a.manufacturer, 
            a.modelname, 
            a.localmodelname, 
            a.serialnumber,
            a.hardwarerevision,
            a.firmwarerevision,
            a.softwarerevision,
            a.blesoftwarerevision, 
            a.bleprotocolrevision, 
            a.devicetime,
            a.defaultinsulintype, 
            a.defaultinsulinbrand,
            a.date_  
        FROM 
            live.INSULIN_DEVICE_BRONZE a  
        INNER JOIN  (
            SELECT 
                serialnumber, 
                MAX(CAST(uploadSequence as LONG)) maxUploadSeqence 
            FROM 
                live.INSULIN_DEVICE_BRONZE  
            GROUP BY serialnumber 
        ) b 
        ON a.serialnumber = b.serialnumber 
        AND a.uploadSequence = b.maxUploadSeqence  
        order by  a.serialnumber
    """)

# COMMAND ----------

# MAGIC %md ## Gold Table

# COMMAND ----------

# ==Insulin Device does not have matching deviceuuids with Device Settings as of version 1.1.0, so join is being commented out==

@dlt.table(
  name=insulin_device_table_name + "GOLD",
  comment="insulin device gold")
def insulin_device_gold():
    df = spark.sql("""
        SELECT   
            l.accountid as account_id, 
            l.devicenationality as country, 
            l.deviceUUID as reader_uuid ,
            l.manufacturer, 
            l.modelname as model_name, 
            l.localmodelname as local_model_name,
            l.serialnumber as serial_number_hashed, 
            l.hardwarerevision as hardware_revision, 
            l.firmwarerevision as firmware_revision,
            l.softwarerevision as software_revision, 
            l.blesoftwarerevision as ble_software_revision,
            l.bleprotocolrevision as ble_protocol_revision, 
            l.devicetime as device_time , 
            l.defaultinsulintype as default_insulin_type,
            l.defaultinsulinbrand as default_insulin_brand,
            CAST(l.date_ as date) as first_processed_date 
            --device.device_id  
        FROM 
            live.INSULIN_DEVICE_SILVER l  
        --inner join LIVE.DEVICE_SETTINGS_SILVER device
        --on device.reader_uuid = l.deviceUUID
    """)
            
    return df.withColumn("insulin_device_id", monotonically_increasing_id())

# COMMAND ----------

# MAGIC %md
# MAGIC # Insulin Device Data     

# COMMAND ----------

# MAGIC %md ## Bronze Table

# COMMAND ----------


@dlt.table(temporary=temporary)
#@dlt.expect_all_or_drop(insulin_device_data_input_rules)
def insulin_device_data_input():
    df = (spark.read
            .table(f"`{dmz_catalog}`.`{input_schema}`.`{insulin_device_data_table_name[:-1]}`")
            .where(col("uploaddate").between(start_date, end_date))
    )              
    return df.withColumn("date_", lit(snapshot_date))


@dlt.table(temporary=temporary)
def insulin_device_data_history():
    query = f"SHOW TABLES IN `{history_catalog}`.`{history_schema}` LIKE '{insulin_device_data_table_name[:-1]}'"
    result = spark.sql(query).collect()
    if result:
        return (spark.read
                .table(f'`{history_catalog}`.`{history_schema}`.`{insulin_device_data_table_name[:-1]}`')
        )
    else:
          return spark.createDataFrame([], schema=bronze_schema.insulin_devices_data_schema)     



@dlt.view()
def insulin_device_data_combined():
    return spark.sql("SELECT * from LIVE.insulin_device_data_input UNION SELECT * from LIVE.insulin_device_data_history;")

@dlt.view()
def insulin_device_data_dedup():
    df = spark.sql(f"SELECT * from LIVE.insulin_device_data_combined ORDER BY accountid ASC, deviceuuid ASC, uploadsequence ASC, date_ ASC;")
    return df.dropDuplicates(subset=['serialnumber', 'utctimestamp'])

@dlt.view(name=insulin_device_data_table_name + "BRONZE")
def insulin_device_data_bronze():
    return spark.sql("""SELECT a.* from live.insulin_device_data_dedup as a WHERE a.accountid in (
        SELECT accountid from live.accounts_greater_than_threshold where accountid is not null
    )""")

@dlt.table(
  name=insulin_device_data_table_name + "BRONZE_HISTORY",
  comment="insulin device data bronze",
  temporary=temporary)
def insulin_device_data_update_history():
    df = spark.sql(f"select * from live.{insulin_device_data_table_name}BRONZE where date_ = '{snapshot_date}' ")

    df.write.mode("append").format("delta")\
        .option('nullValue', None)\
        .option("mergeSchema", "false")\
        .saveAsTable(f"`{marshall_catalog}`.`{history_schema}`.`{insulin_device_data_table_name[:-1]}`")

    
    return df


# COMMAND ----------

# MAGIC %md ## Silver Table

# COMMAND ----------

@dlt.table(
  name=insulin_device_data_table_name + "SILVER",
  comment="insulin device data silver",
  temporary=temporary)
def insulin_device_data_silver():
    #Formating Time
    time_df = spark.sql(f"""
            select  
                if (
                    instr(right(localtimestamp,6), '+') > 0 or instr(right(localtimestamp,6), '-') > 0 , 
                    substr(localtimestamp,0,length(localtimestamp)-6) , 
                    localtimestamp) 
                as local_timestamp_modified,
                *  
            from 
                LIVE.{insulin_device_data_table_name}BRONZE""")

    time_df = time_df.drop("local_timestamp") \
                    .withColumnRenamed("local_timestamp_modified", "local_timestamp") \
                    .withColumn('local_timestamp', col('local_timestamp').cast('timestamp'))
    return time_df

# COMMAND ----------

# MAGIC %md ## Gold Table

# COMMAND ----------

# ==Insulin Device does not have matching deviceuuids with Device Settings as of version 1.1.0, so device id is not needed==

@dlt.table(
  name=insulin_device_data_table_name + "GOLD",
  comment="insulin device data gold")
def insulin_device_data_gold():
    df= spark.sql("""
        select 
            i.accountid as account_id, 
            i.deviceuuid as reader_uuid,
            i.devicenationality as country,
            i.relativetimestamp as relative_timestamp,
            i.elapsedseconds as elapsed_seconds, 
            i.serialnumber as serial_number_hashed,
            i.local_timestamp as local_timestamp,
            CAST(i.utctimestamp as timestamp) as utc_timestamp, 
            i.value,
            i.insulintype as insulin_type,  
            i.insulinbrand as insulin_name,
            i.primedose as prime_dose, 
            i.primealgo as prime_algo,
            i.editeddose as edit_dose, 
            i.statusflags as status_flags,
            CAST(i.date_ as date) as first_processed_date,
            --insulin_devices.device_id, 
            insulin_devices.insulin_device_id
        from 
            LIVE.INSULIN_DEVICE_DATA_SILVER as i 
        inner join LIVE.INSULIN_DEVICE_GOLD as insulin_devices 
        on i.serialnumber = insulin_devices.serial_number_hashed
    """)
    return df.withColumn("insulin_device_data_id", monotonically_increasing_id())
