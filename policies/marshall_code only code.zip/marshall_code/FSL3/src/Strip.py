# Databricks notebook source
from pyspark.sql.functions import col, lit, from_unixtime, unix_timestamp, monotonically_increasing_id, hour, to_timestamp

import dlt
import bronze_schema
import gold_schema

from variables_orig import *
from data_quality import *

# COMMAND ----------

# MAGIC %md # Bronze Table

# COMMAND ----------

#Creating original table
@dlt.table(temporary=temporary)
@dlt.expect_all_or_drop(strip_input_rules)
def strip_input():
    df = (spark.read
            .table(f"`{dmz_catalog}`.`{input_schema}`.`strip`")
            .where(col("uploaddate").between(start_date, end_date))
    )              
    return df.withColumn("date_", lit(snapshot_date))

@dlt.table(temporary=temporary)
def strip_history():
    query = f"SHOW TABLES IN `{history_catalog}`.`{history_schema}` LIKE '{strip_table_name[:-1]}'"
    result = spark.sql(query).collect()
    if result:
        return (spark.read
                .table(f'`{history_catalog}`.`{history_schema}`.`{strip_table_name[:-1]}`')
        )
    else:
          return spark.createDataFrame([], schema=bronze_schema.strip_schema)


@dlt.view()
def strip_combined():
    return spark.sql("SELECT * from LIVE.strip_input UNION SELECT * from LIVE.strip_history;")

@dlt.view()
def strip_dedup():
    df = spark.sql(f"SELECT * from LIVE.strip_combined ORDER BY deviceuuid ASC, factoryRecorded ASC, uploadsequence ASC, date_ ASC;")
    return df.dropDuplicates(subset=['deviceuuid', 'factoryrecorded'])


@dlt.view()
def strip_blacklist():
    return spark.sql("select a.* from live.strip_dedup as a LEFT Join live.bronze_blacklist_account as b on a.accountid = b.accountid where b.accountId is null")


@dlt.view(name=strip_table_name + "BRONZE")
def strip_threshold():
    return spark.sql("""SELECT a.* from live.strip_blacklist as a WHERE a.accountid in (
        SELECT accountid from live.accounts_greater_than_threshold where accountid is not null
    )""")

@dlt.table(
  name=strip_table_name + "BRONZE_HISTORY",
  comment="combined strip",
  schema=bronze_schema.strip_schema,
  temporary=temporary)
def strip_update_history():
    df = spark.sql(f"select * from live.{strip_table_name}BRONZE where date_ = '{snapshot_date}' ")

    df.write.mode("append").format("delta")\
        .option('nullValue', None)\
        .option("mergeSchema", "false")\
        .saveAsTable(f"`{marshall_catalog}`.`{history_schema}`.`strip`")

    
    return df


# COMMAND ----------

# MAGIC %md # Silver Table

# COMMAND ----------

@dlt.view()
#@dlt.table(temporary=temporary)
def strip_filtered():
    #Formating Time
    time_df = spark.sql(f"select  if  (instr(right(userrecorded,6), '+') > 0 or instr(right(userrecorded,6), '-') > 0 , substr(userrecorded,0,length(userrecorded)-6) , userRecorded) as userrecorded_modified,* from LIVE.{strip_table_name}BRONZE")

    time_df = time_df.drop("userrecorded") \
                    .withColumnRenamed("userrecorded_modified", "userrecorded") \
                    .withColumn('userrecorded', to_timestamp(col('userRecorded'))) \
                    .withColumn('factoryrecorded', to_timestamp(col('factoryrecorded')))

    return time_df

@dlt.table(
  name=strip_table_name + "SILVER",
  comment="silver strip",
  temporary=temporary)
def strip_silver():
    new_df = spark.sql("SELECT * from LIVE.strip_filtered;")
    new_df = new_df \
                        .withColumn("factoryrechour", hour(new_df.factoryrecorded)) \
                        .withColumn("userrechour", hour(new_df.userrecorded)) \
                        .withColumn("factoryrecorded" ,col('factoryrecorded').cast('timestamp')) \
                        .withColumn("uploadSequence" ,col('uploadSequence').cast('long'))
    new_df = new_df.withColumnRenamed("deviceUUID", "reader_uuid") \
                                        .withColumnRenamed("deviceNationality", "country") \
                                        .withColumnRenamed("uploadSequence", "upload_id")     
    new_df.orderBy(new_df['reader_uuid'].asc(), new_df['factoryrecorded'].asc())
    
    return new_df

# COMMAND ----------

# MAGIC %md # Gold Table

# COMMAND ----------

@dlt.table(
  name=strip_table_name + "GLUCOSE_READING_GOLD",
  comment="gold strip",
  schema=gold_schema.strip_schema)
def strip_gold():
    results_strip_df = spark.sql(f"""
        SELECT 
            d.device_id,
            s.sensor_no,
            s.sensor_id,
            s.sensor_uid,
            CAST(st.upload_id as BIGINT), 
            ROUND(st.mgdl, 0) as value_mgdl, 
            CAST(st.userRecorded as TIMESTAMP) as user_recorded, 
            CAST(st.userRecHour as SMALLINT) as user_rec_hour,
            CAST(st.factoryRecorded as TIMESTAMP) as factory_recorded, 
            CAST(st.FactoryRecHour as SMALLINT) as factory_rec_hour,
            cast(((int(unix_timestamp(st.factoryRecorded)/60) - int(unix_timestamp(s.first_sched_factory_reading)/60))/1440) + 1 as short) as wear_day,

            datediff(to_date(st.factoryRecorded), to_date(s.first_sched_factory_reading)) + 1 calendar_day, 
            u.use_day as usage_day,

            datediff(to_date(st.factoryRecorded), to_date(d.first_sched_factory_reading)) as ownership_day,
            st.reader_uuid, 
            st.firmwareversion as firmware_version,
            st.country,
            CAST(st.date_ as DATE) as first_processed_date 
        FROM 
            LIVE.{strip_table_name}SILVER st
        INNER JOIN LIVE.DEVICE_SETTINGS_SILVER d 
        ON st.reader_uuid = d.reader_uuid
        LEFT OUTER JOIN LIVE.SENSOR_SILVER s 
        ON st.reader_uuid = s.reader_uuid 
        AND unix_timestamp(st.factoryRecorded) BETWEEN unix_timestamp(s.FIRST_SCHED_FACTORY_READING) AND unix_timestamp(s.LAST_SCHED_FACTORY_READING)

        LEFT OUTER JOIN LIVE.useday_filtered u ON st.reader_uuid = u.reader_uuid and to_date(st.factoryRecorded) = to_date(u.factoryRecorded)
    """)

    return results_strip_df.withColumn("strip_glucose_id", monotonically_increasing_id())
