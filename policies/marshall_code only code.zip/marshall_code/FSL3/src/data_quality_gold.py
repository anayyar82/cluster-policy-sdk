def get_constraint(tablename, fields):
    return {f"{tablename}_{field}": f"{field} IS NOT NULL" for field in fields}

sensor_start_exp = {}

sensor_start_exp["valid_sensor_start_id"] = "sensor_start_id IS NOT NULL"
# sensor_start["sensor_start_device_id"] = "device_id IS NOT NULL"
sensor_start_exp["sensor_start_reader_uuid"] = "reader_uuid IS NOT NULL"
# sensor_start["sensor_start_firmware_version"] = "firmware_version IS NOT NULL"
# sensor_start["sensor_start_sensor_id"] = "sensor_id IS NOT NULL"
# sensor_start["sensor_start_sensor_no"] = "sensor_no IS NOT NULL"
sensor_start_exp["sensor_start_sensor_uid"]= "sensor_uid IS NOT NULL"
sensor_start_exp["sensor_start_factory_recorded"] = "factory_recorded IS NOT NULL"
sensor_start_exp["sensor_start_user_recorded"] = "user_recorded IS NOT NULL"
# sensor_start["sensor_start_puck_gen"]= "puck_gen IS NOT NULL"=
# sensor_start["sensor_start_expected_wear_duration"] = "expected_wear_duration IS NOT NULL"
# sensor_start["sensor_start_warmup_time"] = "warmup_time IS NOT NULL"
# sensor_start["sensor_start_product_type"]= "product_type IS NOT NULL"
# sensor_start["sensor_start_upper_glucose_threshold"] = "upper_glucose_threshold IS NOT NULL"
# sensor_start["sensor_start_lower_glucose_threshold"] = "lower_glucose_threshold IS NOT NULL"
# sensor_start["sensor_start_country"] = "country IS NOT NULL"
# sensor_start["sensor_start_method"] = "sensor_start_method IS NOT NULL"
sensor_start_exp["sensor_start_first_processed_date"] = "first_processed_date IS NOT NULL"

sensor_end_exp = {}

sensor_end_exp["sensor_end_sensor_end_id"] = "sensor_end_id IS NOT NULL"
sensor_end_exp["sensor_end_device_id"] = "device_id IS NOT NULL"
sensor_end_exp["sensor_end_reader_uuid"] = "reader_uuid IS NOT NULL"
# sensor_end["sensor_end_firmware_version"] = "firmware_version IS NOT NULL"
# sensor_end["sensor_end_sensor_id"] = "sensor_id IS NOT NULL"
# sensor_end["sensor_end_sensor_no"] = "sensor_no IS NOT NULL"
sensor_end_exp["sensor_end_sensor_uid"] = "sensor_uid IS NOT NULL"
sensor_end_exp["sensor_end_factory_recorded"] = "factory_recorded IS NOT NULL"
sensor_end_exp["sensor_end_user_recorded"] = "user_recorded IS NOT NULL"
sensor_end_exp["sensor_end_first_processed_date"] = "first_processed_date IS NOT NULL"

sensor_glycemic_metrics = {}

sensor_glycemic_metrics["sensor_glycemic_metrics_sensor_id"] = "sensor_id IS NOT NULL"
sensor_glycemic_metrics["sensor_glycemic_metrics_device_id"] = "device_id IS NOT NULL"
sensor_glycemic_metrics["sensor_glycemic_metrics_reader_uuid"] = "reader_uuid IS NOT NULL"
# sensor_glycemic_metrics["sensor_glycemic_metrics_country"] = "country IS NOT NULL"
# sensor_glycemic_metrics["sensor_glycemic_metrics_firmware_version"] = "firmware_version IS NOT NULL"
sensor_glycemic_metrics["sensor_glycemic_metrics_sensor_uid"] = "sensor_uid IS NOT NULL"
# sensor_glycemic_metrics["sensor_glycemic_metrics_sensor_no"] = "sensor_no IS NOT NULL"
# sensor_glycemic_metrics["sensor_glycemic_metrics_product_type"] = "product_type IS NOT NULL"
# sensor_glycemic_metrics["sensor_glycemic_metrics_puck_gen"] = "puck_gen IS NOT NULL"
sensor_glycemic_metrics["sensor_glycemic_metrics_confirm_status"] = "confirm_status IS NOT NULL"
# sensor_glycemic_metrics["sensor_glycemic_metrics_last_confirmed_sensor_ind"] = "last_confirmed_sensor_ind IS NOT NULL"
# sensor_glycemic_metrics["sensor_glycemic_metrics_irregular_sensor"] = "irregular_sensor IS NOT NULL"
sensor_glycemic_metrics["sensor_glycemic_metrics_data_sufficiency_ind"] = "data_sufficiency_ind IS NOT NULL"
# sensor_glycemic_metrics["sensor_glycemic_metrics_sched_reading_count"] = "sched_reading_count IS NOT NULL"
# sensor_glycemic_metrics["sensor_glycemic_metrics_current_reading_count"] = "current_reading_count IS NOT NULL"
sensor_glycemic_metrics["sensor_glycemic_metrics_average_glucose"] = "average_glucose IS NOT NULL"
sensor_glycemic_metrics["sensor_glycemic_metrics_std_glucose"] = "std_glucose IS NOT NULL" 
sensor_glycemic_metrics["sensor_glycemic_metrics_avg_view_per_wear_day"] = "avg_view_per_wear_day IS NOT NULL"
sensor_glycemic_metrics["sensor_glycemic_metrics_read_in_range_70_180"] = "read_in_range_70_180 IS NOT NULL" 
sensor_glycemic_metrics["sensor_glycemic_metrics_read_below_45"] = "read_below_45 IS NOT NULL"
sensor_glycemic_metrics["sensor_glycemic_metrics_read_below_54"] = "read_below_54 IS NOT NULL"
sensor_glycemic_metrics["sensor_glycemic_metrics_read_below_70"] = "read_below_70 IS NOT NULL"
sensor_glycemic_metrics["sensor_glycemic_metrics_read_above_180"] = "read_above_180 IS NOT NULL"
sensor_glycemic_metrics["sensor_glycemic_metrics_read_above_250"] = "read_above_250 IS NOT NULL"
sensor_glycemic_metrics["sensor_glycemic_metrics_time_in_range_70_180"] = "time_in_range_70_180 IS NOT NULL"
sensor_glycemic_metrics["sensor_glycemic_metrics_time_below_45"] = "time_below_45 IS NOT NULL"
sensor_glycemic_metrics["sensor_glycemic_metrics_time_below_54"] = "time_below_54 IS NOT NULL"
sensor_glycemic_metrics["sensor_glycemic_metrics_time_below_70"] = "time_below_70 IS NOT NULL"
sensor_glycemic_metrics["sensor_glycemic_metrics_time_above_180"] = "time_above_180 IS NOT NULL"
sensor_glycemic_metrics["sensor_glycemic_metrics_time_above_250"] = "time_above_250 IS NOT NULL"
sensor_glycemic_metrics["sensor_glycemic_metrics_EA1C"] = "EA1C IS NOT NULL"
sensor_glycemic_metrics["sensor_glycemic_metrics_first_processed_date"] = "first_processed_date IS NOT NULL" 

sensor_alarm_coverage={}

sensor_alarm_coverage["sensor_alarm_coverage_sensor_alarm_coverage_id"] = "sensor_alarm_coverage_id IS NOT NULL"
sensor_alarm_coverage["sensor_alarm_coverage_device_id"] = "device_id IS NOT NULL"
sensor_alarm_coverage["sensor_alarm_coverage_reader_uuid"] = "reader_uuid IS NOT NULL"
# sensor_alarm_coverage["sensor_alarm_coverage_firmware_version"] = "firmware_version IS NOT NULL"  
# sensor_alarm_coverage["sensor_alarm_coverage_country"] = "country IS NOT NULL"
# sensor_alarm_coverage["sensor_alarm_coverage_sensor_id"] = "sensor_id IS NOT NULL" 
# sensor_alarm_coverage["sensor_alarm_coverage_sensor_no"] = "sensor_no IS NOT NULL"
sensor_alarm_coverage["sensor_alarm_coverage_sensor_uid"] = "sensor_uid IS NOT NULL"
# sensor_alarm_coverage["sensor_alarm_coverage_IS_LOW_GLUCOSE_ENABLED"] = "IS_LOW_GLUCOSE_ENABLED IS NOT NULL"
# sensor_alarm_coverage["sensor_alarm_coverage_IS_HIGH_GLUCOSE_ENABLEDn"] = "IS_HIGH_GLUCOSE_ENABLED IS NOT NULL"
# sensor_alarm_coverage["sensor_alarm_coverage_IS_SIGNAL_LOSS_ALARM_ENABLED"] = "IS_SIGNAL_LOSS_ALARM_ENABLED IS NOT NULL"
# sensor_alarm_coverage["sensor_alarm_coverage_IS_ALARM_SOUND_ENABLED"] = "IS_ALARM_SOUND_ENABLED IS NOT NULL"
# sensor_alarm_coverage["sensor_alarm_coverage_signal_IS_ALARM_NOTIFICATION_ENABLED"] = "IS_ALARM_NOTIFICATION_ENABLED IS NOT NULL"
# sensor_alarm_coverage["sensor_alarm_coverage_signal_LOW_GLUCOSE_THRESHOLD_IN_MGDL"] = "LOW_GLUCOSE_THRESHOLD_IN_MGDL IS NOT NULL"
# sensor_alarm_coverage["sensor_alarm_coverage_signal_HIGH_GLUCOSE_THRESHOLD_IN_MGDL"] = "HIGH_GLUCOSE_THRESHOLD_IN_MGDL IS NOT NULL"
sensor_glycemic_metrics["sensor_alarm_coverage_first_processed_date"] = "first_processed_date IS NOT NULL" 

account_blacklist_exp = {}

account_blacklist_exp["account_blacklist_account_id"] = "account_id IS NOT NULL"
account_blacklist_exp["account_blacklist_date_added"] = "date_added IS NOT NULL"
account_blacklist_exp["account_blacklist_date_added"] = "date_added IS NOT NULL"

current_glucose_reading = {}

current_glucose_reading["current_glucose_reading_current_glucose_id"] = "current_glucose_id IS NOT NULL"
current_glucose_reading["current_glucose_reading_device_id"] = "device_id IS NOT NULL"
current_glucose_reading["current_glucose_reading_reader_uuid"] = "reader_uuid IS NOT NULL"
# current_glucose_reading["current_glucose_reading_firmware_version"] = "firmware_version IS NOT NULL"
current_glucose_reading["current_glucose_reading_country"] = "country IS NOT NULL"
# current_glucose_reading["current_glucose_reading_sensor_id"] = "sensor_id IS NOT NULL"
# current_glucose_reading["current_glucose_reading_sensor_no"] = "sensor_no IS NOT NULL"
current_glucose_reading["current_glucose_reading_sensor_uid"] = "sensor_uid IS NOT NULL"
current_glucose_reading["current_glucose_reading_upload_id"] = "upload_id IS NOT NULL"
current_glucose_reading["current_glucose_reading_irregular_reading"] = "irregular_reading IS NOT NULL"
current_glucose_reading["current_glucose_reading_value_mgdl"] = "value_mgdl IS NOT NULL"
current_glucose_reading["current_glucose_reading_user_recorded"] = "user_recorded IS NOT NULL"
current_glucose_reading["current_glucose_reading_user_rec_hour"] = "user_rec_hour IS NOT NULL"
current_glucose_reading["current_glucose_reading_factory_recorded"] = "factory_recorded IS NOT NULL"
# current_glucose_reading["current_glucose_reading_factory_rec_hour"] = "factory_rec_hour IS NOT NULL"
# current_glucose_reading["current_glucose_reading_calendar_day"] = "calendar_day IS NOT NULL"
# current_glucose_reading["current_glucose_reading_wear_day"] = "wear_day IS NOT NULL"
#current_glucose_reading["current_glucose_reading_first_after_activation"] = "first_after_activation IS NOT NULL"
# current_glucose_reading["current_glucose_reading_first_after_time_change"] = "first_after_time_change IS NOT NULL"
# current_glucose_reading["current_glucose_reading_is_viewed"] = "is_viewed IS NOT NULL"
current_glucose_reading["current_glucose_reading_first_processed_date"] = "first_processed_date IS NOT NULL"

device={}

device["device_device_id"] = "device_id IS NOT NULL"
device["device_reader_uuid"] = "reader_uuid IS NOT NULL"
device["device_current_firmware_version"] = "current_firmware_version IS NOT NULL"
device["device_reader_nationality"] = "country IS NOT NULL"
device["device_system_type"] = "system_type IS NOT NULL"
device["device_reader_type"] = "reader_type IS NOT NULL"
device["device_first_sched_factory_reading"] = "first_sched_factory_reading IS NOT NULL"
device["device_last_sched_factory_reading"] = "last_sched_factory_reading IS NOT NULL"
device["device_first_sched_user_reading"] = "first_sched_user_reading IS NOT NULL"
device["device_last_sched_user_reading"] = "last_sched_user_reading IS NOT NULL"
device["device_sensor_count"] = "sensor_count IS NOT NULL"
device["device_raw_sched_reading_count"] = "raw_sched_reading_count IS NOT NULL"
device["device_raw_current_reading_count"] = "raw_current_reading_count IS NOT NULL"
device["device_total_wear_days"] = "total_wear_days IS NOT NULL"
device["device_avg_view_per_wear_day"] = "avg_view_per_wear_day IS NOT NULL"
device["device_abandoned_ind"] = "abandoned_ind IS NOT NULL"
device["device_use_insulin_calc_ind"] = "use_insulin_calc_ind IS NOT NULL"
device["device_data_sufficiency_ind"] = "data_sufficiency_ind IS NOT NULL"
device["device_first_processed_date"] = "first_processed_date IS NOT NULL"

account={}

account["account_account_id"] = "account_id"
account["account_reader_nationality"] = "reader_nationality"
account["account_age_range_lower"] = "age_range_lower"
account["account_age_range_higher"] = "age_range_higher"
account["account_first_processed_date"] = "first_processed_date"

account_device={}

account_device["account_device_account_id"] = "account_id"
account_device["account_device_account_uuid"] = "account_uuid"
account_device["account_device_first_processed_date"] = "first_processed_date"

sensor = {}
sensor["sensor_sensor_id"] = "sensor_id"
sensor["sensor_device_id"] = "device_id"
sensor["sensor_reader_uuid"] = "reader_uuid"
sensor["sensor_reader_nationality"] = "reader_nationality"
sensor["sensor_firmware_version"] = "firmware_version"
sensor["sensor_sensor_no"] = "sensor_no"
sensor["sensor_sched_reading_count"] = "sched_reading_count"
sensor["sensor_first_sched_user_reading"] = "first_sched_user_reading"
sensor["sensor_last_sched_user_reading"] = "last_sched_user_reading"
sensor["sensor_first_sched_factory_reading"] = "first_sched_factory_reading"
sensor["sensor_last_sched_factory_reading"] = "last_sched_factory_reading"
sensor["sensor_hours_operational"] = "hours _operational"
sensor["sensor_first_processed_date"] = "first_processed_date"

scheduled_glucose_reading = {}

scheduled_glucose_reading["scheduled_glucose_reading_sched_glucose_id"] = "sched_glucose_id IS NOT NULL"
scheduled_glucose_reading["scheduled_glucose_reading_device_id"] = "device_id IS NOT NULL"
scheduled_glucose_reading["scheduled_glucose_reading_firmware_version"] = "firmware_version IS NOT NULL"
scheduled_glucose_reading["scheduled_glucose_reading_sensor_id"] = "sensor_id IS NOT NULL"
scheduled_glucose_reading["scheduled_glucose_reading_sensor_no"] = "sensor_no IS NOT NULL"
scheduled_glucose_reading["scheduled_glucose_reading_sensor_uid"] = "sensor_uid IS NOT NULL"
scheduled_glucose_reading["scheduled_glucose_reading_upload_id"] = "upload_id IS NOT NULL"
scheduled_glucose_reading["scheduled_glucose_reading_value_mgdl"] = "value_mgdl IS NOT NULL"
scheduled_glucose_reading["scheduled_glucose_reading_user_recorded"] = "user_recorded IS NOT NULL"
scheduled_glucose_reading["scheduled_glucose_reading_user_rec_hour"] = "user_rec_hour IS NOT NULL"
scheduled_glucose_reading["scheduled_glucose_reading_factory_recorded"] = "factory_recorded IS NOT NULL"
scheduled_glucose_reading["scheduled_glucose_reading_factory_rec_hour"] = "factory_rec_hour IS NOT NULL"
scheduled_glucose_reading["scheduled_glucose_reading_wear_day"] = "wear_day IS NOT NULL"
scheduled_glucose_reading["scheduled_glucose_reading_calendar_day"] = "calendar_day IS NOT NULL"
scheduled_glucose_reading["scheduled_glucose_reading_first_after_activation"] = "first_after_activation IS NOT NULL"
scheduled_glucose_reading["scheduled_glucose_reading_first_after_time_change"] = "first_after_time_change IS NOT NULL"
scheduled_glucose_reading["scheduled_glucose_reading_first_processed_date"] = "first_processed_date IS NOT NULL"

insulin = {}
insulin["insulin_insulin_id"] = "insulin_id IS NOT NULL"
insulin["insulin_device_id"] = "device_id IS NOT NULL"
insulin["insulin_upload_id"] = "upload_id IS NOT NULL"
insulin["insulin_insulin_type"] = "insulin_type IS NOT NULL"
insulin["insulin_value_units"] = "value_units IS NOT NULL"
insulin["insulin_user_recorded"] = "user_recorded IS NOT NULL"
insulin["insulin_user_rec_hour"] = "user_rec_hour IS NOT NULL"
insulin["insulin_factory_recorded"] = "factory_recorded IS NOT NULL"
insulin["insulin_factory_rec_hour"] = "factory_rec_hour IS NOT NULL"
insulin["insulin_first_processed_date"] = "first_processed_date IS NOT NULL"

medication = {}
medication["medication_medication_id"] = "medication_id IS NOT NULL"
medication["medication_device_id"] = "device_id IS NOT NULL"
medication["medication_upload_id"] = "upload_id IS NOT NULL"
medication["medication_user_recorded"] = "user_recorded IS NOT NULL"
medication["medication_user_rec_hour"] = "user_rec_hour IS NOT NULL"
medication["medication_factory_recorded"] = "factory_recorded IS NOT NULL"
medication["medication_factory_rec_hour"] = "factory_rec_hour IS NOT NULL"
medication["medication_first_processed_date"] = "first_processed_date IS NOT NULL"
medication["medication_sensor_id"] = "sensor_id IS NOT NULL"

ketone_reading = {}

ketone_reading["ketone_reading_ketone_id"] = "ketone_id IS NOT NULL"
ketone_reading["ketone_reading_device_id"] = "device_id IS NOT NULL"
ketone_reading["ketone_reading_upload_id"] = "upload_id IS NOT NULL"
ketone_reading["ketone_reading_user_recorded"] = "user_recorded IS NOT NULL"
ketone_reading["ketone_reading_user_rec_hour"] = "user_rec_hour IS NOT NULL"
ketone_reading["ketone_reading_factory_recorded"] = "factory_recorded IS NOT NULL"
ketone_reading["ketone_reading_factory_rec_hour"] = "factory_rec_hour IS NOT NULL"
ketone_reading["ketone_reading_first_processed_date"] = "first_processed_date IS NOT NULL"

exercise = {}
exercise["exercise_exercise_id"] = "exercise_id IS NOT NULL"
exercise["exercise_device_id"] = "device_id IS NOT NULL"
exercise["exercise_reader_uuid"] = "reader_uuid IS NOT NULL"
exercise["exercise_upload_id"] = "upload_id IS NOT NULL"
exercise["exercise_user_recorded"] = "user_recorded IS NOT NULL"
exercise["exercise_user_rec_hour"] = "user_rec_hour IS NOT NULL"
exercise["exercise_factory_recorded"] = "factory_recorded IS NOT NULL"
exercise["exercise_factory_rec_hour"] = "factory_rec_hour IS NOT NULL"
exercise["exercise_first_processed_date"] = "first_processed_date IS NOT NULL"


food = {}

food["food_food_id"] = "food_id IS NOT NULL"
food["food_device_id"] = "device_id IS NOT NULL"
food["food_upload_id"] = "upload_id IS NOT NULL"
food["food_user_recorded"] = "user_recorded IS NOT NULL"
food["food_user_rec_hour"] = "user_rec_hour IS NOT NULL"
food["food_factory_recorded"] = "factory_recorded IS NOT NULL"
food["food_factory_rec_hour"] = "factory_rec_hour IS NOT NULL"
food["food_meal_name"] = "meal_name IS NOT NULL"
food["food_first_processed_date"] = "first_processed_date IS NOT NULL"

ISF_glucose_alarm = {}

ISF_glucose_alarm["ISF_glucose_alarm_alarm_id"] = "alarm_id IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_device_id"] = "device_id IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_reader_uuid"] = "reader_uuid IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_firmware_version"] = "firmware_version IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_country"] = "country IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_upload_id"] = "upload_id IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_sensor_id"] = "sensor_id IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_sensor_no"] = "sensor_no IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_sensor_uid"] = "sensor_uid IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_user_recorded"] = "user_recorded IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_user_rec_hour"] = "user_rec_hour IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_factory_recorded"] = "factory_recorded IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_factory_rec_hour"] = "factory_rec_hour IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_fixed_low_is_cleared"] = "fixed_low_is_cleared IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_fixed_low_is_dismissed"] = "fixed_low_is_dismissed IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_fixed_low_is_user_cleared"] = "fixed_low_is_user_cleared IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_fixed_low_is_in_episode"] = "fixed_low_is_in_episode IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_fixed_low_is_presented"] = "fixed_low_is_presented IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_high_is_cleared"] = "high_is_cleared IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_high_is_user_cleared"] = "high_is_user_cleared IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_high_is_dismissed"] = "high_is_dismissed IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_high_is_in_episode"] = "high_is_in_episode IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_high_is_presented"] = "high_is_presented IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_low_is_cleared"] = "low_is_cleared IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_low_is_user_cleared"] = "low_is_user_cleared IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_low_is_dismissed"] = "low_is_dismissed IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_low_is_in_episode"] = "low_is_in_episode IS NOT NULL" 
ISF_glucose_alarm["ISF_glucose_alarm_low_is_presented"] = "low_is_presented IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_signal_loss_is_user_cleared"] = "signal_loss_is_user_cleared IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_signal_loss_is_in_episode"] = "signal_loss_is_in_episode IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_signal_loss_is_presented"] = "signal_loss_is_presented IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_signal_loss_is_auto_dismissed"] = "signal_loss_is_auto_dismissed IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_signal_loss_is_user_dismissed"] = "signal_loss_is_user_dismissed IS NOT NULL"
ISF_glucose_alarm["ISF_glucose_alarm_first_processed_date"] = "first_processed_date IS NOT NULL"

strip_glucose_reading = {}
strip_glucose_reading["strip_glucose_reading_strip_glucose_id"] = "strip_glucose_id IS NOT NULL"
strip_glucose_reading["strip_glucose_reading_device_id"] = "device_id IS NOT NULL"
strip_glucose_reading["strip_glucose_reading_firmware_version"] = "firmware_version IS NOT NULL"
strip_glucose_reading["strip_glucose_reading_upload_id"] = "upload_id IS NOT NULL"
strip_glucose_reading["strip_glucose_reading_value_mgdl"] = "value_mgdl IS NOT NULL"
strip_glucose_reading["strip_glucose_reading_user_recorded"] = "user_recorded IS NOT NULL"
strip_glucose_reading["strip_glucose_reading_user_rec_hour"] = "user_rec_hour IS NOT NULL"
strip_glucose_reading["strip_glucose_reading_factory_recorded"] = "factory_recorded IS NOT NULL"
strip_glucose_reading["strip_glucose_reading_factory_rec_hour"] = "factory_rec_hour IS NOT NULL"
strip_glucose_reading["strip_glucose_reading_first_processed_date"] = "first_processed_date IS NOT NULL"


blacklist = {}
blacklist["blacklist_reader_uuid"] = ""

whitelist = {}
whitelist["whitelist_firmware_version"] = "firmware_version IS NOT NULL"
whitelist["whitelist_system_type"] = "system_type IS NOT NULL"
whitelist["whitelist_country"] = "country IS NOT NULL"
whitelist["whitelist_included_in_reporting"] = "included_in_reporting IS NOT NULL"

sensor_wear_day = {}

sensor_wear_day["sensor_wear_day_sensor_wear_day_id"] = "sensor_wear_day_id IS NOT NULL"
sensor_wear_day["sensor_wear_day_sensor_id"] = "sensor_id IS NOT NULL"
sensor_wear_day["sensor_wear_day_sensor_no"] = "sensor_no IS NOT NULL"
sensor_wear_day["sensor_wear_day_sensor_uid"] = "sensor_uid IS NOT NULL"
sensor_wear_day["sensor_wear_day_wear_day"] = "wear_day IS NOT NULL"
sensor_wear_day["sensor_wear_day_wd_sched_reading_count"] = "wd_sched_reading_count IS NOT NULL"
sensor_wear_day["sensor_wear_day_wd_current_reading_count"] = "wd_current_reading_count IS NOT NULL"
sensor_wear_day["sensor_wear_day_time_in_target"] = "time_in_target IS NOT NULL"
sensor_wear_day["sensor_wear_day_time_above_target"] = "time_above_target IS NOT NULL"
sensor_wear_day["sensor_wear_day_time_below_target"] = "time_below_target IS NOT NULL"
sensor_wear_day["sensor_wear_day_percentile_10th"] = "percentile_10th IS NOT NULL"
sensor_wear_day["sensor_wear_day_percentile_25th"] = "percentile_25th IS NOT NULL"
sensor_wear_day["sensor_wear_day_percentile_50th"] = "percentile_50th IS NOT NULL"
sensor_wear_day["sensor_wear_day_percentile_75th"] = "percentile_75th IS NOT NULL"
sensor_wear_day["sensor_wear_day_percentile_90th"] = "percentile_90th IS NOT NULL"
sensor_wear_day["sensor_wear_day_first_processed_date"] = "first_processed_date IS NOT NULL"

ref_country = {}
ref_country["ref_country_country"] = "country IS NOT NULL"
ref_country["ref_country_name"] = "name IS NOT NULL"
ref_country["ref_country_included_in_reporting"] = "included_in_reporting IS NOT NULL"

upload = {}
upload["upload_upload_id"] = "upload_id IS NOT NULL"
upload["upload_upload_date"] = "upload_date IS NOT NULL"
upload["upload_country"] = "country IS NOT NULL"
upload["upload_reader_uuid"] = "reader_uuid IS NOT NULL"
upload["upload_firmware_version"] = "firmware_version IS NOT NULL"
upload["upload_account_id"] = "account_id IS NOT NULL"
upload["upload_first_processed_date"] = "first_processed_date IS NOT NULL"

alarm_setting_constrained_fields = [
    "alarm_setting_id","device_id","reader_uuid","firmware_version",
    "country","upload_id","sensor_id","sensor_no",
    "sensor_uid","user_recorded","user_rec_hour","factory_recorded","factory_rec_hour",
    "is_high_glucose_enabled","is_low_glucose_enabled","low_glucose_threshold_in_mgdl","high_glucose_threshold_in_mgdl",
    "first_processed_date"
]
alarm_setting = get_constraint("alarm_setting", alarm_setting_constrained_fields)

time_change_constrained_fields = [
    "time_change_id","device_id","reader_uuid","firmware_version",
    "country","upload_id","sensor_id","sensor_no",
    "sensor_uid","user_recorded","user_rec_hour","factory_recorded",
    "factory_rec_hour","first_processed_date"
]
time_change = get_constraint("time_change", time_change_constrained_fields)

skin_temp_constrained_fields = [
    "skin_temperature_id","device_id","reader_uuid","firmware_version",
    "country","upload_id","sensor_id","sensor_no",
    "sensor_uid","user_recorded","user_rec_hour","factory_recorded",
    "factory_rec_hour","skin_temperature_celsius","first_processed_date"
]
skin_temperature = get_constraint("skin_temperature", skin_temp_constrained_fields)