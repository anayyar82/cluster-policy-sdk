# Databricks notebook source
from pyspark.sql.functions import col, lit, from_unixtime, unix_timestamp, monotonically_increasing_id, hour, to_timestamp

import dlt
import bronze_schema
import gold_schema

from variables_orig import *
from data_quality import *
from data_quality_gold import *

# COMMAND ----------

# MAGIC %md # Bronze Table

# COMMAND ----------

#Creating original table
@dlt.table(temporary=temporary)
@dlt.expect_all_or_drop(food_input_rules)
def food_input():
    df = (spark.read
            .table(f"`{dmz_catalog}`.`{input_schema}`.`{food_table_name[:-1]}`")
            .where(col("uploaddate").between(start_date, end_date))
    )              
    return df.withColumn("date_", lit(snapshot_date))

@dlt.table(temporary=temporary)
def food_history():
    query = f"SHOW TABLES IN `{history_catalog}`.`{history_schema}` LIKE '{food_table_name[:-1]}'"
    result = spark.sql(query).collect()
    
    if result:
        return (spark.read
                .table(f'`{history_catalog}`.`{history_schema}`.`{food_table_name[:-1]}`')
        )
    else:
        return spark.createDataFrame([], schema=bronze_schema.food_schema)


@dlt.view()
def food_combined():
    return spark.sql("SELECT * from LIVE.food_input UNION SELECT * from LIVE.food_history;")

@dlt.view()
def food_dedup():
    df = spark.sql(f"SELECT * from LIVE.food_combined ORDER BY deviceuuid ASC, factoryrecorded ASC, uploadsequence ASC, date_ ASC;")
    return df.dropDuplicates(subset=['deviceUUID', 'factoryrecorded'])

@dlt.view()
#@dlt.table(temporary=temporary)
def food_blacklist():
    return spark.sql(f"""
            select 
                a.* 
            from live.food_dedup as a 
            LEFT Join live.bronze_blacklist_account as b 
            on a.accountid = b.accountid 
            where b.accountId is null
""")

@dlt.view(name=food_table_name + "BRONZE")
def food_threshold():
    return spark.sql("""SELECT a.* from live.food_blacklist as a WHERE a.accountid in (
        SELECT accountid from live.accounts_greater_than_threshold where accountid is not null
    )""")


#Update Food History
@dlt.table(
  name=food_table_name + "HISTORY_BRONZE",
  comment="combined food",
  temporary=temporary)
def food_update_history():
    df = spark.sql(f"select * from live.FOOD_BRONZE where date_ = '{snapshot_date}' ")
    df.write.mode("append").format("delta")\
        .option('nullValue', None)\
        .option("mergeSchema", "false")\
        .saveAsTable(f"`{marshall_catalog}`.`{history_schema}`.`{food_table_name[:-1]}`")

    
    return df



# COMMAND ----------

# MAGIC %md # Silver Table

# COMMAND ----------

@dlt.view()
def food_filtered():
    #Formating Time
    time_df = spark.sql(f"select  if  (instr(right(userRecorded,6), '+') > 0 or instr(right(userRecorded,6), '-') > 0 , substr(userRecorded,0,length(userRecorded)-6) , userRecorded) as userRecorded_modified,* from LIVE.{food_table_name}BRONZE")

    time_df = time_df.drop("userRecorded") \
                    .withColumnRenamed("userRecorded_modified", "userRecorded") \
                    .withColumn('userrecorded', to_timestamp(col('userRecorded'))) \
                    .withColumn('factoryrecorded', to_timestamp(col('factoryrecorded')))
    return time_df

@dlt.table(
  name=food_table_name + "SILVER",
  temporary = temporary)
def food_silver():
    new_df = spark.sql("SELECT * from LIVE.food_filtered;")
    new_df = new_df \
                        .withColumn("factoryrechour", hour(new_df.factoryrecorded)) \
                        .withColumn("userrechour", hour(new_df.userrecorded)) \
                        .withColumn("uploadSequence", col('uploadSequence').cast('long'))
    new_df = new_df.withColumnRenamed("deviceUUID", "reader_uuid") \
                                        .withColumnRenamed("deviceNationality", "country") \
                                        .withColumnRenamed("uploadSequence", "upload_id")    
    new_df.orderBy(new_df['reader_uuid'].asc(), new_df['factoryrecorded'].asc())
    
    return new_df


# COMMAND ----------

# MAGIC %md # Gold Table

# COMMAND ----------

# MAGIC %md ### FSL3 Table

# COMMAND ----------

@dlt.table(
  name=food_table_name + "GOLD",
  comment="gold food",
  schema=gold_schema.food_schema
)
#@dlt.expect_all_or_drop(food)
def food_gold():
    food_df = spark.sql("""
    select 
        d.device_id,
        s.sensor_id, 
        s.sensor_no, 
        s.sensor_uid, -- added sensor_uid from sensor table
        CAST(f.upload_id as BIGINT), 
        f.mealname as meal_name, 
        f.valuecarbs as value_carbs,
        cast(f.userrecorded as timestamp) as user_recorded, 
        cast(f.userrechour as smallint) as user_rec_hour, 
        cast(f.factoryrecorded as timestamp) as factory_recorded, 
        cast(f.factoryrechour as smallint) as factory_rec_hour, 
        f.firmwareversion as firmware_version, --added firmware_version from food table
        f.numberofservings as number_of_servings, -- added number of servings from food table
        cast(((int(unix_timestamp(f.factoryrecorded)/60) - int(unix_timestamp(s.first_sched_factory_reading)/60))/1440) + 1 as int) as wear_day,
        datediff(f.factoryrecorded, s.first_sched_factory_reading) + 1 as calendar_day, 
        useday.use_day as usage_day,
        datediff(f.factoryrecorded, d.first_sched_factory_reading) as ownership_day,
        f.reader_uuid, 
        f.country,
        cast(f.date_ as date) as first_processed_date
    from live.food_silver f
    inner join live.device_settings_silver d
    on f.reader_uuid = d.reader_uuid 
    left outer join live.sensor_silver s
    on s.device_id = d.device_id 
    and (unix_timestamp(f.factoryrecorded) between unix_timestamp(s.first_sched_factory_reading) and unix_timestamp(s.last_sched_factory_reading))
    left outer join live.useday_filtered as useday 
    on (f.reader_uuid = useday.reader_uuid and to_date(f.factoryrecorded) = to_date(useday.factoryrecorded))
    """)
    return food_df.withColumn("food_id", monotonically_increasing_id())

