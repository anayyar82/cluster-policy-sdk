# Databricks notebook source
from pyspark.sql.types import IntegerType
from pyspark.sql.functions import monotonically_increasing_id, hour, to_timestamp, when, col, row_number
from pyspark.sql import Window

import dlt
import bronze_schema
import gold_schema

from variables_orig import *
from data_quality import *
from data_quality_gold import *


# COMMAND ----------

# MAGIC %md # Silver Table

# COMMAND ----------

@dlt.table(temporary=temporary)
def scheduled_aggregated_sensor():
    return spark.sql("""
        select 
            reader_uuid, 
            sensor_number,
            row_number() over (partition by reader_uuid order by sensor_number asc) as reordered_sensor_number,
            first_sched_factory_reading, 
            last_sched_factory_reading, 
            first_sched_user_reading,
            last_sched_user_reading, 
            sched_reading_count,
            read_in_target, 
            read_below_target, 
            read_above_target,
            sensoruid as original_sensor_uid,
            sensoruidcorrected as sensor_uid
        from
            (
                select 
                    reader_uuid,
                    sensor_number,
                    last(sensoruid) as sensoruid,
                    last(sensoruidcorrected) as sensoruidcorrected,
                    min(factoryrecorded) as first_sched_factory_reading,
                    max(factoryrecorded) as last_sched_factory_reading,
                    min(userrecorded) as first_sched_user_reading,
                    max(userrecorded) as last_sched_user_reading,
                    count(*) as sched_reading_count, 
                    sum(read_in_target_flg) as read_in_target, 
                    sum(read_below_target_flg) as read_below_target,
                    sum(read_above_target_flg) as read_above_target
                from 
                    live.SCHEDULED_GLUCOSE_READING_SILVER 
                where sensor_number > 0 
                group by 1, 2
            )
    """)

#need to add computed calculations once we figure out the sensor start method
#@dlt.view()
@dlt.table(temporary=temporary)
def sensor_enriched():
    sensor = spark.sql("""
        select 
            device_id, 
            reader_uuid, 
            prelim_sensor_no, 
            sensor_no,
            first_sched_factory_reading,
            last_sched_factory_reading, 
            --need to add calculation
            first_sched_factory_reading as computed_first_sched_factory_recorded,
            first_sched_user_reading,
            last_sched_user_reading, 
            reader_nationality, 
            firmware as firmware_version,
            hours_operational,
            --need to add calculation here 
            hours_operational as computed_hours_operational, 
            irregular_sensor, 
            time_to_next_sensor_start/3600.0 as time_to_next_sensor_start , 
            sched_reading_count,
            read_in_target, 
            read_above_target, 
            read_below_target, 
            time_in_target,
            time_below_target, 
            time_above_target, 
            confirm_status,
            case 
                when sensor_no = max(case when confirm_status = 1 then sensor_no else 0 end) over (partition by device_id) 
                then true
                else false
            end as last_confirmed_sensor_ind, 
            sensor_uid, 
            original_sensor_uid,
            date_
            from (
                select 
                    device.device_id,
                    sched_glu_aggr.reader_uuid, 
                    sched_glu_aggr.sensor_number as prelim_sensor_no, 
                    sched_glu_aggr.reordered_sensor_number as sensor_no, 
                    sched_glu_aggr.first_sched_factory_reading, 
                    sched_glu_aggr.last_sched_factory_reading,
                    sched_glu_aggr.first_sched_user_reading, 
                    sched_glu_aggr.last_sched_user_reading, 
                    device.reader_nationality,
                    device.firmware,

                    ROUND((int((unix_timestamp(sched_glu_aggr.last_sched_factory_reading)/60)) - int((unix_timestamp(sched_glu_aggr.first_sched_factory_reading)/60)))/60.0, 5) as hours_operational,

                    case 
                        when (int(unix_timestamp(sched_glu_aggr.last_sched_factory_reading)/60) - int(unix_timestamp(sched_glu_aggr.first_sched_factory_reading)/60))/60.0 > 336 
                        then true
                        else false
                    end as irregular_sensor,

                    abs(((unix_timestamp(lead(sched_glu_aggr.first_sched_factory_reading, 1) over (partition by sched_glu_aggr.reader_uuid order by sched_glu_aggr.reader_uuid, sched_glu_aggr.reordered_sensor_number))) - (unix_timestamp(sched_glu_aggr.last_sched_factory_reading)))) as time_to_next_sensor_start,

                    sched_glu_aggr.sched_reading_count,  
                    sched_glu_aggr.read_in_target,  
                    sched_glu_aggr.read_below_target, 
                    sched_glu_aggr.read_above_target,
                    nvl(round(sched_glu_aggr.read_in_target/sched_glu_aggr.sched_reading_count, 5)*24,0) as time_in_target,
                    nvl(round(sched_glu_aggr.read_below_target/sched_glu_aggr.sched_reading_count, 5)*24,0) as time_below_target,
                    nvl(round(sched_glu_aggr.read_above_target/sched_glu_aggr.sched_reading_count, 5)*24,0) as time_above_target,
                    
                    case 
                        when sched_glu_aggr.reordered_sensor_number = device.sensor_count 
                        then 0 
                        else 1 
                    end as confirm_status, 
                    sensor_uid,
                    original_sensor_uid,
                    device.date_
                from 
                    LIVE.scheduled_aggregated_sensor sched_glu_aggr 
                    inner join LIVE.DEVICE_SETTINGS_SILVER device 
                    where sched_glu_aggr.reader_uuid = device.reader_uuid 
                    order by sched_glu_aggr.reader_uuid, sched_glu_aggr.reordered_sensor_number
            )
    """)
    
    return sensor.withColumn("sensor_id", monotonically_increasing_id())



# COMMAND ----------

@dlt.table(temporary=temporary)
def sensor_start_swap():
    joined_df = spark.sql("""
                WITH 
                sensor_enriched_with_prev AS (
                    SELECT
                        se.*,
                        LAG(se.last_sched_factory_reading) OVER (PARTITION BY se.reader_uuid ORDER BY se.first_sched_factory_reading) AS prev_last_sched_factory_reading
                    FROM
                        LIVE.sensor_enriched se
                ),
                sensorstart AS (
                    SELECT
                        accountid,
                        reader_uuid as readeruuid,
                        factoryrecorded,
                        userRecorded,
                        sensoruid
                    FROM
                        LIVE.generic_silver
                    WHERE
                        type = 'sensorstart'
                )
                SELECT
                    ss.*,
                    se.*
                FROM
                    sensorstart ss
                INNER JOIN
                    sensor_enriched_with_prev se
                ON
                    ss.readeruuid = se.reader_uuid
                                    """)


    condition = (joined_df.factoryrecorded < joined_df.first_sched_factory_reading) & ((joined_df.factoryrecorded > joined_df.prev_last_sched_factory_reading) | (joined_df.prev_last_sched_factory_reading.isNull()))

    # Replace first_sched_factory_reading if the condition is met
    newcol_df = (joined_df.withColumn("new_first_sched_factory_reading", when(condition, joined_df.factoryrecorded).otherwise(None))
                        .withColumn("new_sensor_uid", when(condition, joined_df.sensoruid).otherwise(None))
            )


    updated_df = newcol_df.dropna(subset=["new_first_sched_factory_reading"])
    updated_df = updated_df.select("device_id", "reader_uuid", "prelim_sensor_no", "sensor_no",
                                    "new_first_sched_factory_reading", "last_sched_factory_reading", "computed_first_sched_factory_recorded", "first_sched_user_reading", "last_sched_user_reading",
                                    "reader_nationality", "firmware_version", "hours_operational", "computed_hours_operational",
                                    "irregular_sensor", "time_to_next_sensor_start" , "sched_reading_count","read_in_target",
                                    "read_above_target", "read_below_target", "time_in_target","time_below_target", 
                                    "time_above_target", "confirm_status", "last_confirmed_sensor_ind", "new_sensor_uid", 
                                    "original_sensor_uid", "date_", "sensor_id")
    updated_df = updated_df.withColumnsRenamed({"new_first_sched_factory_reading": "first_sched_factory_reading",
                                                "new_sensor_uid": "sensor_uid"})

    return updated_df

@dlt.table(
  name=sensor_table_name + "SILVER",
  temporary=temporary)
def sensor_silver():
    df = spark.sql(f"""
        SELECT 
            sensor.*,
            sensor_start.producttype as product_type
        FROM (
        SELECT * from LIVE.sensor_enriched
        UNION
        SELECT * from LIVE.sensor_start_swap
        ORDER BY device_id, reader_uuid, sensor_id, first_sched_factory_reading
        ) as sensor
        left join (
            select 
                reader_uuid,  
                sensoruid, 
                producttype  
            from 
                LIVE.GENERIC_SILVER as generic
            where type ='sensorstart'  
            group by reader_uuid, sensoruid, producttype
        ) as sensor_start  
        on sensor.reader_uuid = sensor_start.reader_uuid
        and sensor.sensor_uid = sensor_start.sensoruid
        order by sensor.reader_uuid, sensor.sensor_no asc
    """)


    window = Window.partitionBy('reader_uuid', 'sensor_id').orderBy(col('first_sched_factory_reading').asc())
    df = df.withColumn("row_number", row_number().over(window)).filter(col("row_number") == 1).drop('row_number')
    return df.dropDuplicates(["device_id", "reader_uuid", "sensor_id", "last_sched_factory_reading"])

# COMMAND ----------

# MAGIC %md ### Useday

# COMMAND ----------

@dlt.view()
#@dlt.table(temporary=temporary)
def useday():
    return spark.sql("""
            select 
                reader_uuid, 
                factoryRecorded,
                row_number() over (partition by reader_uuid order by factoryRecorded asc) as use_day 
            from (
                select distinct 
                    reader_uuid, 
                    to_date(factoryRecorded) as factoryRecorded 
                from 
                    LIVE.SCHEDULED_GLUCOSE_READING_SILVER 
                where sensor_number > 0
            )
    """)

@dlt.view()
#@dlt.table(temporary=temporary)
def useday_filtered():
    return spark.sql("""
            select
                *
            from
                LIVE.useday
            where reader_uuid in (
                select reader_uuid from LIVE.DEVICE_SETTINGS_SILVER
            )
    """)

# COMMAND ----------

# MAGIC %md # Sensor Start and Sensor End
# MAGIC

# COMMAND ----------


@dlt.table(
  name="SENSOR_START_GOLD",
  comment="gold sensor start",
  schema=gold_schema.sensor_start_schema
)
#@dlt.expect_all_or_drop(sensor_start_exp)
def sensor_start():
  df = spark.sql(f"""
    SELECT
      sr.device_id,
      coalesce(g.reader_uuid, sr.reader_uuid) as reader_uuid,
      coalesce(g.firmwareversion, sr.firmware_version) as firmware_version,
      sr.sensor_id,
      sr.sensor_no as sensor_no,
      coalesce(g.sensoruid, sr.sensor_uid) as sensor_uid,
      coalesce(g.factoryRecorded, sr.first_sched_factory_reading) as factory_recorded,
      coalesce(g.userRecorded, sr.first_sched_user_reading) as user_recorded,
      CAST(g.puckgen as int) as puck_gen,
      CAST(g.wearduration as int) as expected_wear_duration,
      CAST(g.warmuptime as int) as warmup_time,
      g.producttype as product_type,
      g.highGlucoseThresholdInMgDl as upper_glucose_threshold,
      g.lowGlucoseThresholdInMgDl as lower_glucose_threshold,
      g.country,
      CASE
        WHEN g.sensoruid IS NULL 
        THEN 'computed' 
        ELSE 'actual'
      END as sensor_start_method,
      CAST(g.latejoined as boolean) as is_late_join,
      CAST(g.streaming as boolean) as is_streaming,
      cast(coalesce(g.date_, sr.date_) as DATE) as first_processed_date
    FROM LIVE.sensor_silver sr
    FULL OUTER JOIN
      (SELECT * FROM LIVE.{generic_table_name}SILVER g WHERE type = 'sensorstart') g
      on sr.reader_uuid = g.reader_uuid AND sr.sensor_uid = g.sensoruid
  """)

  return df.withColumn("sensor_start_id", monotonically_increasing_id())

  

@dlt.table(name="SENSOR_END_GOLD",
  comment="gold sensor_end",
  schema=gold_schema.sensor_end_schema
)
#@dlt.expect_all_or_drop(sensor_end_exp)
def sensor_end():
    sensor_end = spark.sql("""
      SELECT 
        sensor.device_id,
        sensor.reader_uuid,
        sensor.firmware_version as firmware_version,
        sensor.sensor_id,
        sensor.sensor_no,
        sensor.sensor_uid,
        g.factoryrecorded as factory_recorded, 
        g.userrecorded as user_recorded, 
        g.sensorexpired as sensor_expired_ind, 
        g.sensorterminated as sensor_terminated_ind, 
        CAST(sensor.date_ as DATE) as first_processed_date
      FROM 
        ( select 
          s.device_id, 
          s.reader_uuid, 
          s.firmware_version, 
          s.sensor_id,
          s.sensor_no, 
          s.sensor_uid, 
          s.reader_nationality as country, 
          s.date_
        from LIVE.SENSOR_SILVER s) sensor
        inner join LIVE.GENERIC_SILVER as g
          on g.reader_uuid = sensor.reader_uuid and g.sensoruid = sensor.sensor_uid
          WHERE g.sensorterminated is not null OR g.sensorexpired is not null""") 

    return sensor_end.withColumn("sensor_end_id", monotonically_increasing_id())

# COMMAND ----------

# MAGIC %md # Gold Table

# COMMAND ----------

@dlt.view()
#@dlt.table(temporary=temporary)
def sensor_data_sufficiency():
    return spark.sql(f"""
        SELECT
            SENSOR_ID,

            CASE
                WHEN SUM(CASE WHEN UNIQUE_DATES >= 5 AND READINGS_COUNT >= 10 THEN 1 ELSE 0 END) >= 20 
                THEN true
                ELSE false
            END as DATA_SUFFICIENCY_IND

        FROM(
            SELECT
                SENSOR_ID,
                COUNT(DISTINCT TO_DATE(FACTORY_RECORDED)) AS UNIQUE_DATES,
                COUNT(SENSOR_ID) AS READINGS_COUNT
            FROM 
                LIVE.scheduled_final
            GROUP BY SENSOR_ID, FACTORY_REC_HOUR
        ) SENS_DS
        GROUP BY SENSOR_ID
    """)

@dlt.table(
  name=sensor_table_name + "GOLD",
  schema=gold_schema.sensor_schema
)
def sensor_fsl3():
    return spark.sql(f"""
        select 
            sensor.sensor_id, 
            sensor.device_id, 
            sensor.reader_uuid, 
            sensor.sensor_no,
            sensor.first_sched_user_reading, 
            sensor.last_sched_user_reading,
            sensor.first_sched_factory_reading, 
            sensor.last_sched_factory_reading, 
            ROUND((int((unix_timestamp(sensor.last_sched_factory_reading)/60)) - int((unix_timestamp(sensor.first_sched_factory_reading)/60)))/60.0, 5) as hours_operational,
            sensor.computed_hours_operational as computed_hours_operational,
            sensor.first_sched_factory_reading as computed_first_sched_factory_reading,
            CAST(sensor.confirm_status as BOOLEAN), 
            abs(((unix_timestamp(lead(sensor.first_sched_factory_reading, 1) over (partition by sensor.reader_uuid order by sensor.reader_uuid, sensor.sensor_no))) - (unix_timestamp(sensor.last_sched_factory_reading)))) as time_to_next_sensor_start, 
            unsched.unsched_count as current_reading_count,
            -- nvl(round(unsched.unsched_count/(((cast(int((unix_timestamp(last_sched_factory_reading, 'MM/dd/yyyy HH:mm:ss')/60)) - int(unix_timestamp(first_sched_factory_reading, 'MM/dd/yyyy HH:mm:ss')/60)  as integer)/1440)+1)*1.0)), 0) as avg_scan_per_wear_day, -- Not in requirements, but kept for refrence of calculation
            CAST(sensor.last_confirmed_sensor_ind as BOOLEAN), 
            case 
                when (int(unix_timestamp(sensor.last_sched_factory_reading)/60) - int(unix_timestamp(sensor.first_sched_factory_reading)/60))/60.0 > 336 
                then true
                else false
            end as irregular_sensor,
            sensor.reader_nationality as country,
            sensor.firmware_version,
            CAST(sensor_data_sufficiency.data_sufficiency_ind as BOOLEAN) as data_sufficiency_ind, 
            sensor.sensor_uid,
            sensor.original_sensor_uid, 
            sensor.product_type,
            CAST(sensor_start.puck_gen as INTEGER) as puck_gen,
            sensor_start.factory_recorded as sensor_start_factory_reading,
            sensor_start.user_recorded as sensor_start_user_reading,
            generic_sensor_start.localization,
            generic_sensor_start.activationtype as activation_type,
            sensor_start.expected_wear_duration,
            sensor_start.warmup_time,
            CAST(sensor_start.upper_glucose_threshold as INTEGER),
            CAST(sensor_start.lower_glucose_threshold as INTEGER),
            sensor_start.sensor_start_method,
            CAST(sensor_start.is_streaming as BOOLEAN),
            sensor_start.is_late_join,
            sensor_end.factory_recorded as sensor_end_factory_reading,
            sensor_end.user_recorded as sensor_end_user_reading,
            CAST(sensor.date_ as DATE) as first_processed_date --change made june 5th2024 AB
        from
            LIVE.{sensor_table_name}SILVER as sensor
            inner join 
            LIVE.sensor_data_sufficiency as sensor_data_sufficiency 
                on sensor.sensor_id = sensor_data_sufficiency.sensor_id
        left outer join (
            select 
                unsched_glucose.device_id, 
                unsched_glucose.sensor_no, 
                count(*) as unsched_count 
            from 
                LIVE.current_prepared as unsched_glucose 
                group by unsched_glucose.device_id, sensor_no) unsched
                on sensor.device_id = unsched.device_id and sensor.sensor_no = unsched.sensor_no
        left outer join LIVE.GENERIC_SILVER generic_sensor_start
        on sensor.reader_uuid = generic_sensor_start.reader_uuid and sensor.sensor_uid = generic_sensor_start.sensoruid
        and generic_sensor_start.type = 'sensorstart'
        left outer join LIVE.SENSOR_START_GOLD sensor_start
        on generic_sensor_start.reader_uuid = sensor_start.reader_uuid and generic_sensor_start.sensoruid = sensor_start.sensor_uid
        left outer join (
            select 
                se.factory_recorded,
                se.user_recorded,
                se.device_id,
                se.sensor_no
            from
                LIVE.SENSOR_END_GOLD as se) sensor_end
            on sensor.device_id = sensor_end.device_id and sensor.sensor_no = sensor_end.sensor_no
    """)


@dlt.view()
def day_hour():
    day_hour =  [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23]
    day_hour_df = spark.createDataFrame(day_hour, IntegerType())
    return day_hour_df

# COMMAND ----------

# MAGIC %md
# MAGIC ###Sensor Day Hour

# COMMAND ----------

@dlt.view()
def sensor_day_hr_map():
    return spark.sql("""
        select 
            s.device_id as sd_device_id, 
            s.reader_nationality sd_reader_nationality, 
            s.sensor_id sd_sensor_id,
            s.sensor_no sd_sensor_no, 
            s.first_sched_factory_reading as sd_first_sched_factory_reading,
            s.first_sched_user_reading sd_first_sched_user_reading, 
            s.cal_days as sd_cal_days, 
            dh.value as hr
        from 
            LIVE.day_hour dh 
        CROSS JOIN (
            select 
                sensor.sensor_id, 
                sensor.sensor_no, 
                sensor.device_id, 
                sensor.reader_nationality,
                sensor.first_sched_factory_reading, 
                sensor.first_sched_user_reading,
                sg_sensor.sg_cal_days as cal_days 
            from (
                select 
                    sensor_id sg_sensor_id, 
                    COUNT(DISTINCT calendar_day) as sg_cal_days 
                from LIVE.scheduled_final ssg_sensor 
                where irregular_reading = 0 
                and first_last_calendar_day_ind = 0 
                and irregular_reading = 0 
                group by sensor_id
            ) sg_sensor
            inner join LIVE.SENSOR_SILVER sensor 
            on sg_sensor.sg_sensor_id = sensor.sensor_id
        ) s
    """) 

# COMMAND ----------

# MAGIC %md
# MAGIC ###Sensor Calendar Day Reads

# COMMAND ----------

@dlt.view()
def sensor_cal_day_reads():
    return spark.sql("""
        select 
            sg.sensor_id as sc_sensor_id, 
            sg.user_rec_hour as sc_user_rec_hour, 
            sg.reads as sc_reads, 
            sg.read_days as sc_read_days
        from (
            select 
                sensor_id, 
                user_rec_hour, 
                COUNT(sched_glucose_id) as reads, 
                COUNT(DISTINCT(calendar_day)) as read_days 
            from 
                LIVE.scheduled_final 
            where calendar_day > 0 
            and first_last_calendar_day_ind = 0 
            and irregular_reading = 0 
            GROUP BY sensor_id, user_rec_hour
        ) sg
    """)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Sensor_glycemic_metrics

# COMMAND ----------

#@dlt.view()
@dlt.table()
def scheduled_read_flags():
    return spark.sql(f""" 
        SELECT 
            *,
            CASE WHEN value_mgdl BETWEEN 70 AND 180 THEN 1 ELSE 0 END AS read_in_range_70_180,
            CASE WHEN value_mgdl < 45 THEN 1 ELSE 0 END AS read_below_45,
            CASE WHEN value_mgdl < 54 THEN 1 ELSE 0 END AS read_below_54,
            CASE WHEN value_mgdl < 70 THEN 1 ELSE 0 END AS read_below_70,
            CASE WHEN value_mgdl > 180 THEN 1 ELSE 0 END AS read_above_180,
            CASE WHEN value_mgdl > 250 THEN 1 ELSE 0 END AS read_above_250
        FROM LIVE.{scheduled_table_name}SILVER
    """)


@dlt.table()
def sensor_gly_agg_sched():
    return spark.sql("""
        SELECT
            sched.reader_uuid,
            sched.sensoruidcorrected,
            CAST(AVG(round(sched.value_mgdl,0)) AS FLOAT) as average_glucose,
            CAST(STDDEV(sched.value_mgdl) AS FLOAT) as std_glucose,
            sum(sched.read_in_range_70_180) as read_in_range_70_180,
            sum(sched.read_below_45) as read_below_45,
            sum(sched.read_below_54) as read_below_54,
            sum(sched.read_below_70) as read_below_70,
            sum(sched.read_above_180) as read_above_180,
            sum(sched.read_above_250) as read_above_250,
            CAST((AVG(sched.value_mgdl)+46.7) / 28.7 AS FLOAT) AS EA1C,
            count(*) as sched_reading_count,
            CAST(min(sched.date_) AS DATE) as first_processed_date
        FROM LIVE.scheduled_read_flags sched
        group by sched.reader_uuid, sched.sensoruidcorrected
    """)

@dlt.table()
def sensor_gly_agg_sensor():
    return spark.sql("""
        SELECT 
            sensor.sensor_id as sensor_id,
            sensor.original_sensor_uid,
            sensor.device_id as device_id,
            sensor.reader_uuid as reader_uuid,
            sensor.country as country,
            sensor.firmware_version as firmware_version,
            sensor.sensor_no as sensor_no,
            sensor.product_type as product_type,
            sensor.puck_gen as puck_gen,
            CAST(sensor.confirm_status as BOOLEAN) as confirm_status,
            sensor.last_confirmed_sensor_ind as last_confirmed_sensor_ind,
            sensor.irregular_sensor as irregular_sensor,
            sensor.data_sufficiency_ind as data_sufficiency_ind,
            sensor.current_reading_count as current_reading_count,
            sensor.hours_operational as hours_operational,
            sensor.hours_operational as computed_hours_operational,
            sensor.is_streaming as is_streaming
        FROM LIVE.sensor_gold sensor             
                     """)
    

@dlt.table(name="SENSOR_GLYCEMIC_METRICS_GOLD")
def sensor_glycemic_metrics():
    return spark.sql("""
        With calc as (
            SELECT 
                aggregate_data.*,
                coalesce(round(aggregate_data.read_in_range_70_180/aggregate_data.sched_reading_count, 5)*24, 0) as time_in_range_70_180,
                coalesce(round(aggregate_data.read_below_45/aggregate_data.sched_reading_count, 5)*24, 0) as time_below_45,
                coalesce(round(aggregate_data.read_below_54/aggregate_data.sched_reading_count, 5)*24, 0) as time_below_54,
                coalesce(round(aggregate_data.read_below_70/aggregate_data.sched_reading_count, 5)*24, 0) as time_below_70,
                coalesce(round(aggregate_data.read_above_180/aggregate_data.sched_reading_count, 5)*24, 0) as time_above_180,
                coalesce(round(aggregate_data.read_above_250/aggregate_data.sched_reading_count, 5)*24, 0) as time_above_250
            FROM
                LIVE.sensor_gly_agg_sched aggregate_data
            )
            SELECT
                    sensor.sensor_id as sensor_id,
                    sensor.device_id as device_id,
                    sched.reader_uuid as reader_uuid,
                    sensor.country as country,
                    sensor.firmware_version as firmware_version,
                    sched.sensoruidcorrected as sensor_uid,
                    sensor.sensor_no as sensor_no,
                    sensor.product_type as product_type,
                    sensor.puck_gen as puck_gen,
                    sensor.confirm_status,
                    sensor.last_confirmed_sensor_ind as last_confirmed_sensor_ind,
                    "None" as sensor_end_reason,
                    sensor.irregular_sensor as irregular_sensor,
                    sensor.data_sufficiency_ind as data_sufficiency_ind,
                    sched.sched_reading_count,
                    sensor.current_reading_count as current_reading_count,
                    sensor.hours_operational as hours_operational,
                    computed_hours_operational,
                    device.avg_scan_per_wear_day as avg_view_per_wear_day,
                    sched.average_glucose,
                    sched.std_glucose,
                    sched.read_in_range_70_180,
                    sched.read_below_45,
                    sched.read_below_54,
                    sched.read_below_70,
                    sched.read_above_180,
                    sched.read_above_250,
                    sched.EA1C,
                    sched.first_processed_date
            FROM
                LIVE.sensor_gly_agg_sensor sensor
            INNER JOIN
                calc sched
            ON sensor.reader_uuid = sched.reader_uuid
            AND sensor.original_sensor_uid = sched.sensoruidcorrected
            INNER JOIN LIVE.device_settings_silver device
            on device.reader_uuid = sensor.reader_uuid
            and device.device_id = sensor.device_id                  
                     """)

