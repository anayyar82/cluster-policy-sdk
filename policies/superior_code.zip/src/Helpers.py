# Databricks utils for getting runtime parameters
from databricks.sdk.runtime import *

# Basic Python modules
import sys
import json
import logging

import hashlib

# Boto3
import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

# datetime & datetime parsing
from datetime import datetime, timedelta
from dateutil.parser import isoparse

# Spark
from pyspark.context import SparkContext
from pyspark.sql import SparkSession, Row, SQLContext
from pyspark.sql.functions import col, when, concat, udf, count, shiftRight, from_json, split, lit
from pyspark.sql.types import StructType, StructField, StringType, TimestampType, ShortType, ByteType, IntegerType, LongType, FloatType
from pyspark.sql.utils import AnalysisException

# File path parsing
import re

# Threads
import concurrent.futures

"""
DeviceTypeIDs:

DeviceType (40066, 40067): LibreLink
DeviceType (40026, 40027): LDD
DeviceType (90001, 90002): ConnectedDevice
DeviceType (40068) : FSL3App
DeviceType (40031) : FSL3Reader
"""
device_type_set = (40067,40066,40068,40026,40027,40031,90001,90002)

"""
Bit Masks
"""
# Mask for getting sensoruid bits from RecordNumber
sensoruid_mask = 0xFFFFFFFFFFFF0000
lifecount_mask = 0x000000000000FFFF

"""
File Path Batch Parsing
"""
pattern = "\d{4}/\d+/\d+/[\d\-]+"
@udf
def extract_batch_udf(file_path):
    res = re.search(pattern, file_path)
    return None if not res else res.group()

"""
Job Parameter Function & Input Parameters
"""
# Function for getting job parameters
def get_job_parameter(param, default=None):
    try:
        param_val = dbutils.widgets.get(param)
    except Exception as e:
        if default is None:
            raise Exception(f'Missing Parameter: {param}')
        return default
    return param_val

yesterday_date = (datetime.utcnow() - timedelta(days=1))
LANDING_PATH = 'rwe-landing'
LOAD_DATE = get_job_parameter('load-date', yesterday_date.strftime('%Y/%-m/%-d'))
AWS_REGION = get_job_parameter('aws-region')
STATUS_TABLE = get_job_parameter('status-table')
SOURCE_BUCKETS_STR = get_job_parameter('source-buckets')
SOURCE_BUCKETS = SOURCE_BUCKETS_STR.split(',')
RWE_BUCKET = get_job_parameter('rwe-bucket')
RWE_USERS_PATH = get_job_parameter('rwe-users-path')
SUBMIT_JOB = get_job_parameter('submit-job')
PROCESSING_JOB = get_job_parameter('processing-job')
SNS_TOPIC = get_job_parameter('sns-topic')
BASE_TIMEOUT = int(get_job_parameter('base-timeout'))
PROCESSING_TIMEOUT = int(get_job_parameter('processing-timeout'))
DMZ_CATALOG = get_job_parameter('dmz-catalog')
MAX_JOB_THREADS = int(get_job_parameter('max-job-threads', 20))
PARQUET_WRITE_THREADS = int(get_job_parameter('parquet-write-threads', 10))
FSL1_FSL2_SCHEMA = get_job_parameter('fsl1&fsl2-schema')
FSL3_SCHEMA = get_job_parameter('fsl3-schema')
UNPROCESSED_PATH = f's3://{RWE_BUCKET}/rwe-quarantine/'

"""
Variables
"""
# Date format
date_string_format = 'yyyy-MM-dd'

# De-identification setup
MAX_ID = 8192
NUM_BITS = 128
BITS_PER_HEX = 4
NUM_HEX_CHARS = NUM_BITS // BITS_PER_HEX


"""
De-Identification
"""

# Read salts JSON
salts_list = spark.read.csv(f"s3://{RWE_BUCKET}/infrastructure/salts/salts.csv",header=True).collect()
salts_map = {int(r[0]) : r[1] for r in salts_list} # r[0]: id, r[1]: salt

"""
Classes
"""

"""
Class: SNSNotifier

Description: Used to connect to the SNS client and push notifications to the Cloud Support team regarding
job status (success/failure).
"""
class SNSNotifier:

    def __init__(self, aws_region, sns_topic, load_date):
        self.aws_region = aws_region
        self.sns_topic = sns_topic
        self.load_date = load_date
        self._get_client()
        
    def _get_client(self):
        try:
            self.sns_client = boto3.client('sns', self.aws_region)
        except ClientError as ce:
            print(f"Could not establish connection with boto3 sns client: {ce}")
            sys.exit(f"Could not establish connection with boto3 sns client")

    def notify_error(self, err):
        subject = f"Superior Processing Error - {self.load_date}"
        message_body = f"Date: {self.load_date}\n\n"
        message_body += err

        self.sns_client.publish(
            TopicArn=self.sns_topic, 
            Message=message_body,
            Subject=subject
        )
    
    def notify_success(self, context):
        subject = f"Superior Processing Success - {self.load_date}"
        message_body = f"Date: {self.load_date}\n\n"
        message_body += context

        self.sns_client.publish(
            TopicArn=self.sns_topic, 
            Message=message_body,
            Subject=subject
        )
    
    def notify_status(self, num_pending, num_processed, num_measurement, num_devices):
        subject = f"Superior Status {self.load_date}"
        message_body = f"Date: {self.load_date}\n"
        message_body += f"Processed Batches: {num_processed}\n"
        message_body += f"Pending Batches: {num_pending}\n"
        message_body += f"Unprocessed Measurements: {num_measurement}\n"
        message_body += f"Unprocessed Devices: {num_devices}\n"

        self.sns_client.publish(
            TopicArn=self.sns_topic, 
            Message=message_body,
            Subject=subject
        )

"""
Class: SuperiorProcessStatusHandler

Description: Used to read/write/update records in the DynamoDB Superior-Process-Status table. This table
contains information on the file processing statuses. The Ingestion job will create the Pending batches to process for
a particular LOAD_DATE, and keep track of the format (csv initially, then pqt). The Submit job will 
then find the Pending batches, and submit the Processing Job for each of those batches.
The Processing Job will update the Status to "Processed" upon job completion.

DynamoDB Table Columns:
Key, LoadDate, Created, Format, Status, Updated
"""
class SuperiorProcessStatusHandler:
    def __init__(self, aws_region, status_table, sns_topic, load_date, pending_batches=[]):
        # Create a connection with dynamodb client
        dynamodb = boto3.resource('dynamodb', region_name=aws_region)
        self.aws_region = aws_region
        self.status_table = dynamodb.Table(status_table)
        self.sns_topic = sns_topic
        self.load_date = load_date
        self.pending_batches = pending_batches

    def set_pending_batches(self, pending_batches):
        self.pending_batches = pending_batches    
    
    def populate_pending_batches(self, fmt):
        for batch in self.pending_batches:
            item = {
                'Key' : batch,
                'LoadDate' : self.load_date,
                'Created' : str(datetime.utcnow().isoformat()),
                'Format'  : fmt,
                'Status'  : 'Pending',
                'Updated' : None
            }
            try: 
                response = self.status_table.put_item(Item=item)
            except ClientError as ce:
                print(ce)
                SNSNotifier(self.aws_region, self.sns_topic, self.load_date).notify_error(ce)
                sys.exit(f"Error populating batch status: {batch}")
    
    def update_batch_format(self, batch, fmt):
        try:
            self.status_table.update_item(
                Key={
                    'Key' : batch,
                    'LoadDate' : self.load_date
                },
                UpdateExpression = 'SET #F = :format, #U = :updated',
                ExpressionAttributeNames={
                    '#F' : 'Format',
                    '#U' : 'Updated'
                },
                ExpressionAttributeValues={
                    ':format' : fmt,
                    ':updated' : str(datetime.utcnow().isoformat())
                }
            )
        except ClientError as ce:
            print(ce)
            SNSNotifier(self.aws_region, self.sns_topic, self.load_date).notify_error(ce)
            sys.exit(f"Error updating batch format: {batch}")

    def update_batch_status(self, batch, status):
        try:
            self.status_table.update_item(
                Key={
                    'Key' : batch,
                    'LoadDate' : self.load_date
                },
                UpdateExpression = 'SET #S = :status, #U = :updated',
                ExpressionAttributeNames={
                    '#S' : 'Status',
                    '#U' : 'Updated'
                },
                ExpressionAttributeValues={
                    ':status' : status,
                    ':updated' : str(datetime.utcnow().isoformat())
                }
            )
        except ClientError as ce:
            print(ce)
            SNSNotifier(self.aws_region, self.sns_topic, self.load_date).notify_error(ce)
            sys.exit(f"Error updating batch status: {batch}")
        
    def get_items_with_status(self, status, run_date):
        items = []
        response =  self.status_table.query(
                        IndexName='LoadDate-Status-index',
                        KeyConditionExpression=Key('LoadDate').eq(run_date) & Key('Status').eq(status)
                    )
        items += response['Items']
        while response.get('LastEvaluatedKey'):
            response = self.status_table.query(
                            IndexName='LoadDate-Status-index',
                            KeyConditionExpression=Key('LoadDate').eq(run_date) & Key('Status').eq(status),
                            ExclusiveStartKey=response['LastEvaluatedKey']
                            )
            items += response['Items']
        return items
    
class SourceMissingException(Exception):
    def __init__(self, msg):
        super().__init__(msg)

"""
UDFs
"""
# De-identification Function using SHA-256 implementation
@udf
def deid(input_data):
    if not input_data:
        return None
    # Obtain Salt for Input
    dataValues = [ord(c) for c in input_data]
    id = 0
    for dataValue in dataValues:
        id = id + dataValue
    #computing modulus for finding out the id of the salt
    mod_value = id % MAX_ID
    salt = salts_map.get(id, None)
    
    # Compute Hash
    hash_input_bytes = (input_data + salt).encode() # append salt to input and covert to bytes
    sha256 = hashlib.sha256() # hash obj
    sha256.update(hash_input_bytes) # feed input to hash obj
    return sha256.hexdigest()[:NUM_HEX_CHARS] # Only get 128 bits output (32 hex characters)

# Extract sensoruid from the RecordNumber field
@udf
def get_sensoruid(recordnumber):
    if not recordnumber:
        return None
    recordnumber = int(recordnumber)
    bit_r = '{:64b}'.format(recordnumber)   # Convert the record number to a 64bit number
    sliced_bit_r = bit_r[:48]    # Get the upper 48 bits of the record number
    try:
        return str(int(sliced_bit_r, 2))
    except ValueError as ve:
        print(ve)
        return None

# Extract sensoruid from the RecordNumber field (using the corrected method)
@udf
def get_sensoruid_corrected(recordnumber):
    if not recordnumber:
        return None
    recordnumber = int(recordnumber)
    return str((recordnumber & sensoruid_mask) >> 16)

# Extract lifecount from the RecordNumber
@udf
def get_lifecount(recordnumber):
    if not recordnumber:
        return None
    recordnumber = int(recordnumber)
    return str(recordnumber & lifecount_mask)

# Function for validating datetime data
@udf
def validate_iso(date):     # Is date a valid ISO date/time? Returns true if it is, false if it isn't
        try:
            valid_datetime = isoparse(date)
            return True
        except ValueError:
            return False     

"""
Helper Functions
""" 
# Function for pulling year, month, day columns out of uploaddate field
def extr_year_month_day(df):
    return df.withColumn("year", split(col("uploaddate"), '-').getItem(0)) \
        .withColumn("month", split(col("uploaddate"), '-').getItem(1)) \
        .withColumn("day", split(col("uploaddate"), '-').getItem(2))


"""
Input File Schemas
"""
device_schema = StructType([\
                    StructField("PatientID", StringType(), True), \
                    StructField("ID", StringType(), True), \
                    StructField("DeviceTypeID", IntegerType(), True), \
                    StructField("SerialNumber", StringType(), True), \
                    StructField("ModelName", StringType(), True),\
                    StructField("FirmwareVersion", StringType(), True), \
                    StructField("SystemTypeNum", ByteType(), True), \
                    StructField("DeviceTime", StringType(), True), \
                    StructField("Manufacturer", StringType(), True), \
                    StructField("Settings_ModelName", StringType(), True), \
                    StructField("LocalModelName", StringType(), True), \
                    StructField("Settings_SerialNumber", StringType(), True), \
                    StructField("HardwareRevision", StringType(), True), \
                    StructField("FirmwareRevision", StringType(), True), \
                    StructField("SoftwareRevision", StringType(), True), \
                    StructField("BLESoftwareRevision", StringType(), True), \
                    StructField("BLEProtocolRevision", StringType(), True), \
                    StructField("DefaultInsulinType", StringType(), True), \
                    StructField("DefaultInsulinBrand", StringType(), True), \
                    StructField("IsStreaming", StringType(), True)
                   ])

user_schema = StructType([\
                    StructField("ID", StringType(), True), \
                    StructField("Country", StringType(), True), \
                    StructField("DOB", StringType(), True), \
                    StructField("FirstName", StringType(), True), \
                    StructField("MiddleInitial", StringType(), True), \
                    StructField("LastName", StringType(), True), \
                    StructField("Email", StringType(), True)
                   ])
                   
measurement_schema = StructType([\
                    StructField("PatientID", StringType(), True), \
                    StructField("DeviceID", StringType(), True), \
                    StructField("Timestamp", StringType(), True), \
                    StructField("Type", ByteType(), True), \
                    StructField("SubType", ByteType(), True), \
                    StructField("FactoryTimestamp", StringType(), True), \
                    StructField("RecordNumber", StringType(), True),\
                    StructField("W1", ShortType(), True), \
                    StructField("W2", ShortType(), True), \
                    StructField("Created", TimestampType(), True),\
                    StructField("D", StringType(), True),\
                    StructField("ND", StringType(), True)
                   ])  

device_header = device_schema.fieldNames()
measurement_header = measurement_schema.fieldNames()